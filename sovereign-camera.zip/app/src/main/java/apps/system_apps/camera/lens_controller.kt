package apps.system_apps.camera

import android.util.Log
import androidx.camera.core.Camera
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraInfo
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.MeteringPointFactory
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.TimeUnit

sealed class LensType(val label: String, val zoomFactor: Float) {
    object ULTRA_WIDE : LensType("0.5x", 0.5f)
    object WIDE : LensType("1.0x", 1.0f)
    object TELEPHOTO : LensType("2.0x", 2.0f)
    object SUPER_ZOOM : LensType("5.0x", 5.0f)
}

class LensController {

    private val _isFrontCamera = MutableStateFlow(false)
    val isFrontCamera: StateFlow<Boolean> = _isFrontCamera.asStateFlow()

    private val _zoomRatio = MutableStateFlow(1.0f)
    val zoomRatio: StateFlow<Float> = _zoomRatio.asStateFlow()

    private val _minZoom = MutableStateFlow(0.5f)
    val minZoom: StateFlow<Float> = _minZoom.asStateFlow()

    private val _maxZoom = MutableStateFlow(10.0f)
    val maxZoom: StateFlow<Float> = _maxZoom.asStateFlow()

    private val _exposureCompensation = MutableStateFlow(0)
    val exposureCompensation: StateFlow<Int> = _exposureCompensation.asStateFlow()

    private val _focusPoint = MutableStateFlow<Pair<Float, Float>?>(null)
    val focusPoint: StateFlow<Pair<Float, Float>?> = _focusPoint.asStateFlow()

    private var activeCamera: Camera? = null

    fun bindCamera(camera: Camera) {
        this.activeCamera = camera
        camera.cameraInfo.zoomState.value?.let { state ->
            _zoomRatio.value = state.zoomRatio
            _minZoom.value = state.minZoomRatio
            _maxZoom.value = state.maxZoomRatio
        }
        _exposureCompensation.value = camera.cameraInfo.exposureState.exposureCompensationIndex
        Log.d(TAG, "LensController successfully bound to active hardware camera.")
    }

    fun unbindCamera() {
        this.activeCamera = null
        Log.d(TAG, "LensController unbound from hardware camera.")
    }

    fun toggleCameraFacing() {
        _isFrontCamera.value = !_isFrontCamera.value
        _zoomRatio.value = 1.0f // reset zoom on swap
        _focusPoint.value = null
        Log.d(TAG, "Camera swaped. Front facing camera = ${_isFrontCamera.value}")
    }

    fun setZoomScale(ratio: Float) {
        val clamped = ratio.coerceIn(_minZoom.value, _maxZoom.value)
        _zoomRatio.value = clamped
        activeCamera?.cameraControl?.setZoomRatio(clamped)?.addListener({
            Log.d(TAG, "Zoom ratio verified by hardware camera to: $clamped")
        }, { it.run() }) ?: Log.d(TAG, "Zoom set conceptually in simulation to: $clamped")
    }

    fun selectPresetLens(lensType: LensType) {
        setZoomScale(lensType.zoomFactor)
    }

    fun cycleZoomIn() {
        var curr = _zoomRatio.value
        curr = when {
            curr < 1.0f -> 1.0f
            curr < 2.0f -> 2.0f
            curr < 5.0f -> 5.0f
            curr < 10.0f -> 10.0f
            else -> 0.5f
        }
        setZoomScale(curr)
    }

    fun setExposure(value: Int) {
        val clamped = value.coerceIn(-4, 4)
        _exposureCompensation.value = clamped
        activeCamera?.cameraControl?.setExposureCompensationIndex(clamped)?.addListener({
            Log.d(TAG, "Exposure updated to hardware camera frame: $clamped")
        }, { it.run() }) ?: Log.d(TAG, "Exposure set conceptually in simulation to: $clamped")
    }

    fun triggerTapToFocus(x: Float, y: Float, width: Int, height: Int) {
        _focusPoint.value = Pair(x, y)
        Log.d(TAG, "Tap-to-Focus initiated at visual coordinate: ($x, $y)")

        val camera = activeCamera
        if (camera != null) {
            val factory: MeteringPointFactory = SurfaceOrientedMeteringPointFactory(width.toFloat(), height.toFloat())
            val focusPoint = factory.createPoint(x, y)
            val action = FocusMeteringAction.Builder(focusPoint)
                .setAutoCancelDuration(3, TimeUnit.SECONDS)
                .build()
            
            camera.cameraControl.startFocusAndMetering(action).addListener({
                Log.d(TAG, "Hardware Tap-to-Focus action finished successfully.")
            }, { it.run() })
        }
    }

    fun resetFocusPoint() {
        _focusPoint.value = null
    }

    companion object {
        private const val TAG = "LensController"
    }
}
