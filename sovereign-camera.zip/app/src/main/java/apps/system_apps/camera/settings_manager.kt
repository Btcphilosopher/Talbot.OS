package apps.system_apps.camera

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class CameraMode {
    PHOTO, VIDEO, PORTRAIT, PANORAMA
}

enum class FlashMode {
    OFF, ON, AUTO, TORCH
}

enum class GridMode {
    OFF, GRID_3X3, GOLDEN_RATIO
}

enum class TimerMode(val seconds: Int) {
    OFF(0), TIMER_3S(3), TIMER_10S(10)
}

enum class QualityMode {
    HIGH, STANDARD, ECO
}

class SettingsManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("sovereign_camera_prefs", Context.MODE_PRIVATE)

    // State flows representing actual settings reactive states
    private val _cameraMode = MutableStateFlow(getSavedCameraMode())
    val cameraMode: StateFlow<CameraMode> = _cameraMode.asStateFlow()

    private val _flashMode = MutableStateFlow(getSavedFlashMode())
    val flashMode: StateFlow<FlashMode> = _flashMode.asStateFlow()

    private val _gridMode = MutableStateFlow(getSavedGridMode())
    val gridMode: StateFlow<GridMode> = _gridMode.asStateFlow()

    private val _timerMode = MutableStateFlow(getSavedTimerMode())
    val timerMode: StateFlow<TimerMode> = _timerMode.asStateFlow()

    private val _isHdrEnabled = MutableStateFlow(prefs.getBoolean("hdr_enabled", true))
    val isHdrEnabled: StateFlow<Boolean> = _isHdrEnabled.asStateFlow()

    private val _qualityMode = MutableStateFlow(getSavedQualityMode())
    val qualityMode: StateFlow<QualityMode> = _qualityMode.asStateFlow()

    // Sovereign OS - Next Generation AI Assistive Features
    private val _aiSceneRecognitionEnabled = MutableStateFlow(prefs.getBoolean("ai_scene_enabled", true))
    val aiSceneRecognitionEnabled: StateFlow<Boolean> = _aiSceneRecognitionEnabled.asStateFlow()

    private val _ocrCaptureEnabled = MutableStateFlow(prefs.getBoolean("ocr_capture_enabled", false))
    val ocrCaptureEnabled: StateFlow<Boolean> = _ocrCaptureEnabled.asStateFlow()

    private val _documentScanEnabled = MutableStateFlow(prefs.getBoolean("doc_scan_enabled", false))
    val documentScanEnabled: StateFlow<Boolean> = _documentScanEnabled.asStateFlow()

    private val _objectDetectionEnabled = MutableStateFlow(prefs.getBoolean("object_detection_enabled", false))
    val objectDetectionEnabled: StateFlow<Boolean> = _objectDetectionEnabled.asStateFlow()

    // Pro Controls
    private val _isProModeEnabled = MutableStateFlow(prefs.getBoolean("pro_mode_enabled", false))
    val isProModeEnabled: StateFlow<Boolean> = _isProModeEnabled.asStateFlow()

    private val _iso = MutableStateFlow(prefs.getInt("pro_iso", 400))
    val iso: StateFlow<Int> = _iso.asStateFlow() // 100 to 3200

    private val _shutterSpeed = MutableStateFlow(prefs.getString("pro_shutter", "1/125") ?: "1/125")
    val shutterSpeed: StateFlow<String> = _shutterSpeed.asStateFlow()

    private val _whiteBalance = MutableStateFlow(prefs.getString("pro_wb", "AUTO") ?: "AUTO")
    val whiteBalance: StateFlow<String> = _whiteBalance.asStateFlow() // AUTO, SUNNY, CLOUDY, INCANDESCENT, FLUORESCENT

    fun setCameraMode(mode: CameraMode) {
        _cameraMode.value = mode
        prefs.edit().putString("camera_mode", mode.name).apply()
        Log.d(TAG, "Camera Mode set to ${mode.name}")
    }

    fun setFlashMode(mode: FlashMode) {
        _flashMode.value = mode
        prefs.edit().putString("flash_mode", mode.name).apply()
        Log.d(TAG, "Flash Mode set to ${mode.name}")
    }

    fun setGridMode(mode: GridMode) {
        _gridMode.value = mode
        prefs.edit().putString("grid_mode", mode.name).apply()
        Log.d(TAG, "Grid Mode set to ${mode.name}")
    }

    fun setTimerMode(mode: TimerMode) {
        _timerMode.value = mode
        prefs.edit().putString("timer_mode", mode.name).apply()
        Log.d(TAG, "Timer Mode set to ${mode.name}")
    }

    fun setHdrEnabled(enabled: Boolean) {
        _isHdrEnabled.value = enabled
        prefs.edit().putBoolean("hdr_enabled", enabled).apply()
        Log.d(TAG, "HDR Enabled set to $enabled")
    }

    fun setQualityMode(mode: QualityMode) {
        _qualityMode.value = mode
        prefs.edit().putString("quality_mode", mode.name).apply()
        Log.d(TAG, "Quality Mode set to ${mode.name}")
    }

    fun setAiSceneRecognitionEnabled(enabled: Boolean) {
        _aiSceneRecognitionEnabled.value = enabled
        prefs.edit().putBoolean("ai_scene_enabled", enabled).apply()
        Log.d(TAG, "AI Scene Recognition set to $enabled")
        if (enabled) {
            // Document/OCR are toggle-exclusive for better flow
            setDocumentScanEnabled(false)
            setOcrCaptureEnabled(false)
            setObjectDetectionEnabled(false)
        }
    }

    fun setOcrCaptureEnabled(enabled: Boolean) {
        _ocrCaptureEnabled.value = enabled
        prefs.edit().putBoolean("ocr_capture_enabled", enabled).apply()
        Log.d(TAG, "OCR Capture set to $enabled")
        if (enabled) {
            setDocumentScanEnabled(false)
            setAiSceneRecognitionEnabled(false)
            setObjectDetectionEnabled(false)
        }
    }

    fun setDocumentScanEnabled(enabled: Boolean) {
        _documentScanEnabled.value = enabled
        prefs.edit().putBoolean("doc_scan_enabled", enabled).apply()
        Log.d(TAG, "Document Scanning set to $enabled")
        if (enabled) {
            setOcrCaptureEnabled(false)
            setAiSceneRecognitionEnabled(false)
            setObjectDetectionEnabled(false)
        }
    }

    fun setObjectDetectionEnabled(enabled: Boolean) {
        _objectDetectionEnabled.value = enabled
        prefs.edit().putBoolean("object_detection_enabled", enabled).apply()
        Log.d(TAG, "Object Detection set to $enabled")
        if (enabled) {
            setOcrCaptureEnabled(false)
            setAiSceneRecognitionEnabled(false)
            setDocumentScanEnabled(false)
        }
    }

    fun setProModeEnabled(enabled: Boolean) {
        _isProModeEnabled.value = enabled
        prefs.edit().putBoolean("pro_mode_enabled", enabled).apply()
        Log.d(TAG, "Pro Mode set to $enabled")
    }

    fun setIso(value: Int) {
        _iso.value = value
        prefs.edit().putInt("pro_iso", value).apply()
    }

    fun setShutterSpeed(value: String) {
        _shutterSpeed.value = value
        prefs.edit().putString("pro_shutter", value).apply()
    }

    fun setWhiteBalance(value: String) {
        _whiteBalance.value = value
        prefs.edit().putString("pro_wb", value).apply()
    }

    // Helpers to retrieve stored items securely
    private fun getSavedCameraMode(): CameraMode {
        val name = prefs.getString("camera_mode", CameraMode.PHOTO.name)
        return try { CameraMode.valueOf(name!!) } catch (e: Exception) { CameraMode.PHOTO }
    }

    private fun getSavedFlashMode(): FlashMode {
        val name = prefs.getString("flash_mode", FlashMode.OFF.name)
        return try { FlashMode.valueOf(name!!) } catch (e: Exception) { FlashMode.OFF }
    }

    private fun getSavedGridMode(): GridMode {
        val name = prefs.getString("grid_mode", GridMode.OFF.name)
        return try { GridMode.valueOf(name!!) } catch (e: Exception) { GridMode.OFF }
    }

    private fun getSavedTimerMode(): TimerMode {
        val name = prefs.getString("timer_mode", TimerMode.OFF.name)
        return try { TimerMode.valueOf(name!!) } catch (e: Exception) { TimerMode.OFF }
    }

    private fun getSavedQualityMode(): QualityMode {
        val name = prefs.getString("quality_mode", QualityMode.STANDARD.name)
        return try { QualityMode.valueOf(name!!) } catch (e: Exception) { QualityMode.STANDARD }
    }

    companion object {
        private const val TAG = "SettingsManager"
    }
}
