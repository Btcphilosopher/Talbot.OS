package apps.system_apps.camera

import android.content.Context
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.util.Log
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File

class PhotoCapture(
    private val context: Context,
    private val imageProcessor: ImageProcessor,
    private val mainScope: CoroutineScope
) {
    private val _isCapturing = MutableStateFlow(false)
    val isCapturing: StateFlow<Boolean> = _isCapturing.asStateFlow()

    private val _timerCount = MutableStateFlow(0)
    val timerCount: StateFlow<Int> = _timerCount.asStateFlow()

    private val _pipelineProgress = MutableStateFlow(0f)
    val pipelineProgress: StateFlow<Float> = _pipelineProgress.asStateFlow()

    private var countdownJob: Job? = null

    /**
     * Executes photo taking process. Handles timers, count, shutter beeps, and saving.
     */
    fun capturePhoto(
        cameraMode: CameraMode,
        imageCapture: ImageCapture?,
        timerMode: TimerMode,
        isHdrEnabled: Boolean,
        isFrontCamera: Boolean,
        onSuccess: (Uri?) -> Unit,
        onFailure: (String) -> Unit
    ) {
        countdownJob?.cancel()
        _isCapturing.value = true
        _pipelineProgress.value = 0f

        val seconds = timerMode.seconds
        if (seconds > 0) {
            countdownJob = mainScope.launch {
                for (i in seconds downTo 1) {
                    _timerCount.value = i
                    playTimerBeep()
                    delay(1000)
                }
                _timerCount.value = 0
                executeCaptureUsecase(cameraMode, imageCapture, isHdrEnabled, isFrontCamera, onSuccess, onFailure)
            }
        } else {
            _timerCount.value = 0
            executeCaptureUsecase(cameraMode, imageCapture, isHdrEnabled, isFrontCamera, onSuccess, onFailure)
        }
    }

    private fun executeCaptureUsecase(
        mode: CameraMode,
        imageCapture: ImageCapture?,
        isHdrEnabled: Boolean,
        isFrontFacing: Boolean,
        onSuccess: (Uri?) -> Unit,
        onFailure: (String) -> Unit
    ) {
        playShutterSound()
        
        if (imageCapture == null) {
            // Emulate capture in simulation mode gracefully
            mainScope.launch(Dispatchers.Default) {
                simulateImageProcessing(mode, isHdrEnabled, isFrontFacing, onSuccess)
            }
            return
        }

        // Setup file temporary storage
        val tempFile = File(context.cacheDir, "temp_capture_${System.currentTimeMillis()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(tempFile).build()

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    mainScope.launch(Dispatchers.Default) {
                        try {
                            simulatePipelineProgress()
                            
                            val bytes = tempFile.readBytes()
                            val savedUri = imageProcessor.processAndSavePhoto(
                                bytes,
                                mode,
                                isHdrEnabled,
                                isFrontFacing
                            )
                            
                            // Delete cache file safely
                            tempFile.delete()
                            
                            mainScope.launch(Dispatchers.Main) {
                                _isCapturing.value = false
                                onSuccess(savedUri)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to parse captured temporary image", e)
                            mainScope.launch(Dispatchers.Main) {
                                _isCapturing.value = false
                                onFailure("Post-processing failed: ${e.localizedMessage}")
                            }
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e(TAG, "Hardware ImageCapture returned error", exception)
                    mainScope.launch(Dispatchers.Main) {
                        _isCapturing.value = false
                        onFailure("Hardware capture failed: ${exception.localizedMessage}")
                    }
                }
            }
        )
    }

    /**
     * Triggers dynamic pipeline progress for processing UI feed.
     */
    private suspend fun simulatePipelineProgress() {
        for (p in 1..10) {
            _pipelineProgress.value = p / 10f
            delay(120)
        }
    }

    /**
     * Mocks high fidelity image decoding and saving if camera hardware is offline inside emulation.
     */
    private suspend fun simulateImageProcessing(
        mode: CameraMode,
        isHdrEnabled: Boolean,
        isFrontFacing: Boolean,
        onSuccess: (Uri?) -> Unit
    ) {
        Log.d(TAG, "Executing Simulated Photo Capture flow (Simulated Sensor Output)")
        simulatePipelineProgress()

        // Generate a plain color mock bitmap with creative aesthetics (rich gradients/hues representing the captured frame)
        val width = 1080
        val height = 1920
        val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        
        // Let's draw a beautiful gradient representing Sovereign Lens capture landscape
        val paint = android.graphics.Paint()
        val gradient = android.graphics.LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            intArrayOf(
                android.graphics.Color.rgb(18, 24, 38), // twilight slate blue
                android.graphics.Color.rgb(44, 24, 52), // violet space contrast
                android.graphics.Color.rgb(12, 12, 14)  // deep pitch dark
            ),
            null,
            android.graphics.Shader.TileMode.CLAMP
        )
        paint.shader = gradient
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

        // Draw clean cosmic grid overlays or circles
        val sunPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.rgb(255, 126, 95)
            isAntiAlias = true
            style = android.graphics.Paint.Style.FILL
            if (mode == CameraMode.PORTRAIT) {
                // Blur effect color filters
                maskFilter = android.graphics.BlurMaskFilter(40f, android.graphics.BlurMaskFilter.Blur.NORMAL)
            }
        }
        canvas.drawCircle((width / 2).toFloat(), (height / 2.5).toFloat(), 220f, sunPaint)

        // Convert and output via processor helper
        val stream = ByteArrayOutputStream()
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, stream)
        val bytes = stream.toByteArray()

        val savedUri = imageProcessor.processAndSavePhoto(bytes, mode, isHdrEnabled, isFrontFacing)
        
        mainScope.launch(Dispatchers.Main) {
            _isCapturing.value = false
            onSuccess(savedUri)
        }
    }

    fun cancelCountdown() {
        countdownJob?.cancel()
        _timerCount.value = 0
        _isCapturing.value = false
        Log.d(TAG, "Timer countdown cancelled by the user.")
    }

    private fun playTimerBeep() {
        try {
            val notification: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = RingtoneManager.getRingtone(context, notification)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                r.volume = 0.5f
            }
            r.play()
        } catch (e: Exception) {
            Log.e(TAG, "Failed playing volume countdown tone beep", e)
        }
    }

    private fun playShutterSound() {
        try {
            val mp = MediaPlayer.create(context, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            mp?.start()
            mp?.setOnCompletionListener { it.release() }
        } catch (e: Exception) {
            Log.e(TAG, "Failed triggering camera shutter tone", e)
        }
    }

    companion object {
        private const val TAG = "PhotoCapture"
    }
}
