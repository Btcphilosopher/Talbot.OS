package apps.system_apps.camera

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

sealed class CameraSystemState {
    object INITIALIZING : CameraSystemState()
    object HARDWARE_ACTIVE : CameraSystemState()
    object SIMULATOR_ACTIVE : CameraSystemState()
    data class ERROR(val msg: String) : CameraSystemState()
}

class CameraManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    // Sub-Managers & Controllers
    val settings = SettingsManager(context)
    val lensController = LensController()
    val imageProcessor = ImageProcessor(context)
    val photoCapture = PhotoCapture(context, imageProcessor, scope)
    val videoCapture = VideoCapture(context, scope)

    // Camera Hardware Bindings
    private var cameraProvider: ProcessCameraProvider? = null
    private var previewUseCase: androidx.camera.core.Preview? = null
    private var imageCaptureUseCase: ImageCapture? = null
    private var boundCamera: Camera? = null

    // Reactive Status flows
    private val _systemState = MutableStateFlow<CameraSystemState>(CameraSystemState.INITIALIZING)
    val systemState: StateFlow<CameraSystemState> = _systemState.asStateFlow()

    private val _hasPermission = MutableStateFlow(false)
    val hasPermission: StateFlow<Boolean> = _hasPermission.asStateFlow()

    private val _lastCapturedUri = MutableStateFlow<Uri?>(null)
    val lastCapturedUri: StateFlow<Uri?> = _lastCapturedUri.asStateFlow()

    private val _shutterFlashActive = MutableStateFlow(false)
    val shutterFlashActive: StateFlow<Boolean> = _shutterFlashActive.asStateFlow()

    // Combined stream to determine if active simulation/live stream is showing
    val isHardwareActive: StateFlow<Boolean> = _systemState.combine(lensController.isFrontCamera) { state, _ ->
        state is CameraSystemState.HARDWARE_ACTIVE
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000), false)

    init {
        checkPrerequisitePermissions()
    }

    fun checkPrerequisitePermissions() {
        val cameraPermission = android.Manifest.permission.CAMERA
        val writePermission = android.Manifest.permission.WRITE_EXTERNAL_STORAGE
        val audioPermission = android.Manifest.permission.RECORD_AUDIO

        val cameraGranted = ContextCompat.checkSelfPermission(context, cameraPermission) == android.content.pm.PackageManager.PERMISSION_GRANTED
        _hasPermission.value = cameraGranted
        Log.d(TAG, "Permissions checked. Camera granted = $cameraGranted")
    }

    fun setPermissionGranted(granted: Boolean) {
        _hasPermission.value = granted
        if (granted) {
            _systemState.value = CameraSystemState.INITIALIZING
        } else {
            _systemState.value = CameraSystemState.SIMULATOR_ACTIVE
        }
    }

    /**
     * Initializes CameraX process provider or activates high-fidelity Simulator if hardware returns errors
     */
    fun initializeCameraX(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView
    ) {
        if (!_hasPermission.value) {
            Log.d(TAG, "Missing Camera Permissions. Booting Simulator Mode.")
            _systemState.value = CameraSystemState.SIMULATOR_ACTIVE
            return
        }

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()
                bindCameraUseCases(lifecycleOwner, previewView)
            } catch (e: Exception) {
                Log.e(TAG, "ProcessCameraProvider initialization failed. Falling back to Simulator.", e)
                _systemState.value = CameraSystemState.SIMULATOR_ACTIVE
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun bindCameraUseCases(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView
    ) {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        // Choose Lens selector state based on controller facing setting
        val facing = if (lensController.isFrontCamera.value) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        val selector = CameraSelector.Builder().requireLensFacing(facing).build()

        // Setup preview usecase
        previewUseCase = androidx.camera.core.Preview.Builder().build().apply {
            surfaceProvider = previewView.surfaceProvider
        }

        // Setup image take usecase
        imageCaptureUseCase = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setFlashMode(getHardwareFlashMode(settings.flashMode.value))
            .build()

        try {
            // Bind everything together
            boundCamera = provider.bindToLifecycle(
                lifecycleOwner,
                selector,
                previewUseCase,
                imageCaptureUseCase
            )
            
            // Link Lens controller zoom/focus hooks
            boundCamera?.let { lensController.bindCamera(it) }
            
            _systemState.value = CameraSystemState.HARDWARE_ACTIVE
            Log.d(TAG, "CameraX Hardware UseCases bound successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to bind CameraX UseCases: ${e.localizedMessage}. Entering beautiful simulation fallback.", e)
            lensController.unbindCamera()
            _systemState.value = CameraSystemState.SIMULATOR_ACTIVE
        }
    }

    /**
     * Maps virtual settings model flash modes to CameraX hardware flash integers
     */
    private fun getHardwareFlashMode(mode: FlashMode): Int {
        return when (mode) {
            FlashMode.ON -> ImageCapture.FLASH_MODE_ON
            FlashMode.AUTO -> ImageCapture.FLASH_MODE_AUTO
            else -> ImageCapture.FLASH_MODE_OFF
        }
    }

    /**
     * Swaps front/rear cameras
     */
    fun switchFacingCamera(lifecycleOwner: LifecycleOwner, previewView: PreviewView) {
        lensController.toggleCameraFacing()
        if (_systemState.value == CameraSystemState.HARDWARE_ACTIVE) {
            bindCameraUseCases(lifecycleOwner, previewView)
        } else {
            Log.d(TAG, "Mock Swapped facing in simulator mode: FrontFacing = ${lensController.isFrontCamera.value}")
        }
    }

    /**
     * Triggers photo capture sequence
     */
    fun performCapture() {
        if (photoCapture.isCapturing.value) return

        // Flash screen visual feedback trigger
        _shutterFlashActive.value = true
        scope.launch {
            delay(100)
            _shutterFlashActive.value = false
        }

        photoCapture.capturePhoto(
            cameraMode = settings.cameraMode.value,
            imageCapture = imageCaptureUseCase,
            timerMode = settings.timerMode.value,
            isHdrEnabled = settings.isHdrEnabled.value,
            isFrontCamera = lensController.isFrontCamera.value,
            onSuccess = { uri ->
                _lastCapturedUri.value = uri
                Log.d(TAG, "Captured! Photo stored path: $uri")
            },
            onFailure = { error ->
                Log.e(TAG, "Photo Capture Failed: $error")
            }
        )
    }

    /**
     * Video Recorder Actions
     */
    fun toggleVideoRecording() {
        if (videoCapture.isRecording.value) {
            videoCapture.stopRecording { uri ->
                _lastCapturedUri.value = uri
                Log.d(TAG, "Recorded! Video storage path: $uri")
            }
        } else {
            videoCapture.startRecording(
                onSuccess = { uri ->
                    _lastCapturedUri.value = uri
                },
                onFailure = { error ->
                    Log.e(TAG, "Video recording encounter errors: $error")
                }
            )
        }
    }

    fun pauseResumeVideo() = videoCapture.togglePauseResume()

    companion object {
        private const val TAG = "CameraManager"
    }
}
