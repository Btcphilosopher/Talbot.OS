package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = Color.White,
    secondary = Color(0xFF8E8E93),
    background = Color.Black,
    surface = Color(0xFF0F0F10),
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
  )

private val LightColorScheme = DarkColorScheme // Standardize on minimal dark for cinema camera

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  // Default to false for premium cinematic monochrome
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme // Keep dark mode active always for professional camera preview

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
