package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import apps.system_apps.camera.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.composed
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.graphicsLayer

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CameraScreen()
            }
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun CameraScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    // Instantiate and remember Sovereign Camera Manager core
    val cameraManager = remember { CameraManager(context, scope) }

    // Settings States (via Flow collects)
    val mode by cameraManager.settings.cameraMode.collectAsState()
    val flash by cameraManager.settings.flashMode.collectAsState()
    val timer by cameraManager.settings.timerMode.collectAsState()
    val isHdr by cameraManager.settings.isHdrEnabled.collectAsState()
    val grid by cameraManager.settings.gridMode.collectAsState()
    val quality by cameraManager.settings.qualityMode.collectAsState()

    // Lens State
    val zoom by cameraManager.lensController.zoomRatio.collectAsState()
    val minZoom by cameraManager.lensController.minZoom.collectAsState()
    val maxZoom by cameraManager.lensController.maxZoom.collectAsState()
    val isFrontCamera by cameraManager.lensController.isFrontCamera.collectAsState()
    val focusPoint by cameraManager.lensController.focusPoint.collectAsState()
    val exposure by cameraManager.lensController.exposureCompensation.collectAsState()

    // Activity capture timers
    val isCapturing by cameraManager.photoCapture.isCapturing.collectAsState()
    val timerCount by cameraManager.photoCapture.timerCount.collectAsState()
    val captureProgress by cameraManager.photoCapture.pipelineProgress.collectAsState()

    val isRecording by cameraManager.videoCapture.isRecording.collectAsState()
    val isPaused by cameraManager.videoCapture.isPaused.collectAsState()
    val recordDuration by cameraManager.videoCapture.durationSeconds.collectAsState()
    val audioDb by cameraManager.videoCapture.audioDecibels.collectAsState()

    // General status
    val systemState by cameraManager.systemState.collectAsState()
    val hasPermission by cameraManager.hasPermission.collectAsState()
    val lastCapturedUri by cameraManager.lastCapturedUri.collectAsState()
    val shutterFlashActive by cameraManager.shutterFlashActive.collectAsState()

    // Screen display configurations
    var isSettingsOpen by remember { mutableStateOf(false) }
    var showGalleryDialog by remember { mutableStateOf(false) }

    // AI Switch parameters
    val aiSceneEnabled by cameraManager.settings.aiSceneRecognitionEnabled.collectAsState()
    val ocrEnabled by cameraManager.settings.ocrCaptureEnabled.collectAsState()
    val docScanEnabled by cameraManager.settings.documentScanEnabled.collectAsState()
    val objectDetectEnabled by cameraManager.settings.objectDetectionEnabled.collectAsState()

    // Manual Pro controls dialog toggle
    val isProModeEnabled by cameraManager.settings.isProModeEnabled.collectAsState()
    val iso by cameraManager.settings.iso.collectAsState()
    val shutter by cameraManager.settings.shutterSpeed.collectAsState()
    val wb by cameraManager.settings.whiteBalance.collectAsState()

    // Handle initial permissons launcher beautifully
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
        cameraManager.setPermissionGranted(cameraGranted)
        if (cameraGranted) {
            Toast.makeText(context, "Sovereign OS Camera Authorized", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Running in High-Fidelity Simulator Mode", Toast.LENGTH_LONG).show()
        }
    }

    // Trigger permission requests on start
    LaunchedEffect(Unit) {
        val hasCam = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        cameraManager.setPermissionGranted(hasCam)
        if (!hasCam) {
            permissionLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    // Dynamic rotation animation for flip triggers
    var rotationDegrees by remember { mutableStateOf(0f) }
    val animatedRotation by animateFloatAsState(
        targetValue = rotationDegrees,
        animationSpec = spring(stiffness = Spring.StiffnessLow)
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black) // Clean Minimalism Dark Canvas
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {

                // 1. TOP HEADER MENU BAR (Controls Flash, Timer, HDR, AI, Gear Settings)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Outlined.PhotoCamera,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SOVEREIGN",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.5.sp
                        )
                    }

                    // Dynamic row of functional parameter buttons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Flash Icon Toggle
                        IconButton(
                            onClick = {
                                val nextFlash = when (flash) {
                                    FlashMode.OFF -> FlashMode.ON
                                    FlashMode.ON -> FlashMode.AUTO
                                    FlashMode.AUTO -> FlashMode.TORCH
                                    FlashMode.TORCH -> FlashMode.OFF
                                }
                                cameraManager.settings.setFlashMode(nextFlash)
                            },
                            modifier = Modifier.size(36.dp).testTag("flash_toggle")
                        ) {
                            val flashIcon = when (flash) {
                                FlashMode.OFF -> Icons.Outlined.FlashOff
                                FlashMode.ON -> Icons.Filled.FlashOn
                                FlashMode.AUTO -> Icons.Outlined.FlashAuto
                                FlashMode.TORCH -> Icons.Filled.Highlight
                            }
                            Icon(
                                imageVector = flashIcon,
                                contentDescription = "Flash",
                                tint = if (flash == FlashMode.OFF) Color.White.copy(alpha = 0.35f) else Color.White
                            )
                        }

                        // Timer Icon Toggle
                        IconButton(
                            onClick = {
                                val nextTimer = when (timer) {
                                    TimerMode.OFF -> TimerMode.TIMER_3S
                                    TimerMode.TIMER_3S -> TimerMode.TIMER_10S
                                    TimerMode.TIMER_10S -> TimerMode.OFF
                                }
                                cameraManager.settings.setTimerMode(nextTimer)
                            },
                            modifier = Modifier.size(36.dp).testTag("timer_toggle")
                        ) {
                            Icon(
                                imageVector = when (timer) {
                                    TimerMode.OFF -> Icons.Outlined.Timer
                                    TimerMode.TIMER_3S -> Icons.Outlined.Timer3
                                    TimerMode.TIMER_10S -> Icons.Outlined.Timer10
                                },
                                contentDescription = "Timer",
                                tint = if (timer == TimerMode.OFF) Color.White.copy(alpha = 0.35f) else Color.White
                            )
                        }

                        // HDR Tone Mapper Toggle
                        IconButton(
                            onClick = { cameraManager.settings.setHdrEnabled(!isHdr) },
                            modifier = Modifier.size(36.dp).testTag("hdr_toggle")
                        ) {
                            Text(
                                text = "HDR",
                                color = if (isHdr) Color.White else Color.White.copy(alpha = 0.35f),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.border(
                                    1.dp,
                                    if (isHdr) Color.White else Color.White.copy(alpha = 0.15f),
                                    RoundedCornerShape(4.dp)
                                ).padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }

                        // AI Switch panel trigger
                        IconButton(
                            onClick = { isSettingsOpen = !isSettingsOpen },
                            modifier = Modifier.size(36.dp).testTag("ai_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Psychology,
                                contentDescription = "AI settings",
                                tint = if (aiSceneEnabled || ocrEnabled || docScanEnabled || objectDetectEnabled) {
                                    Color.White
                                } else {
                                    Color.White.copy(alpha = 0.35f)
                                }
                            )
                        }

                        // Manual / Pro mode settings dial trigger
                        IconButton(
                            onClick = { cameraManager.settings.setProModeEnabled(!isProModeEnabled) },
                            modifier = Modifier.size(36.dp).testTag("toggle_pro_controls")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Tune,
                                contentDescription = "Manual Controls",
                                tint = if (isProModeEnabled) Color.White else Color.White.copy(alpha = 0.35f)
                            )
                        }
                    }
                }

                // 2. MAIN VIEWFINDER RENDER (Real CameraX overlay OR Cosmic landscape simulator)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color.Black)
                        .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(32.dp))
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onTap = { offset ->
                                    cameraManager.lensController.triggerTapToFocus(
                                        x = offset.x,
                                        y = offset.y,
                                        width = size.width,
                                        height = size.height
                                    )
                                }
                            )
                        }
                ) {
                    if (systemState == CameraSystemState.HARDWARE_ACTIVE && hasPermission) {
                        // Binds Android Camera2 Hardware preview surface
                        AndroidView(
                            factory = { ctx ->
                                PreviewView(ctx).apply {
                                    scaleType = PreviewView.ScaleType.FILL_CENTER
                                    cameraManager.initializeCameraX(lifecycleOwner, this)
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // High-Fidelity simulated landscape stream viewport
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            Color(0xFF242426),
                                            Color(0xFF0F0F10)
                                        )
                                    )
                                )
                        ) {
                            // Render a glowing neon dynamic celestial sphere representing active camera view
                            val pulseAlphaRaw = rememberInfiniteTransition().animateFloat(
                                initialValue = 0.3f,
                                targetValue = 0.6f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(3000, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                )
                            )

                            // Let's position simulated landscape focal elements based on camera facing (soft monochrome halo)
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size((280 * zoom).coerceIn(100f, 500f).dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            colors = listOf(
                                                Color.White.copy(alpha = pulseAlphaRaw.value * 0.5f),
                                                Color.White.copy(alpha = pulseAlphaRaw.value * 0.1f),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )

                            // Simulated Mountain horizon lines (Subtle Minimal Outline style)
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val width = size.width
                                val height = size.height
                                val mountainColor = Color.White.copy(alpha = 0.08f)
                                
                                val path = androidx.compose.ui.graphics.Path().apply {
                                    moveTo(0f, height * 0.75f)
                                    lineTo(width * 0.25f, height * 0.62f)
                                    lineTo(width * 0.5f, height * 0.70f)
                                    lineTo(width * 0.75f, height * 0.58f)
                                    lineTo(width, height * 0.76f)
                                    lineTo(width, height)
                                    lineTo(0f, height)
                                    close()
                                }
                                drawPath(path, color = mountainColor)

                                // Elegant starry elements
                                drawCircle(Color.White.copy(alpha = 0.3f), 3f, Offset(width * 0.15f, height * 0.25f))
                                drawCircle(Color.White.copy(alpha = 0.2f), 4f, Offset(width * 0.45f, height * 0.15f))
                                drawCircle(Color.White.copy(alpha = 0.4f), 2f, Offset(width * 0.75f, height * 0.32f))
                                drawCircle(Color.White.copy(alpha = 0.15f), 3f, Offset(width * 0.85f, height * 0.22f))
                            }

                            // Minimalistic Focus Brackets matching clean design HTML
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(96.dp)
                                    .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(3.dp)
                                        .background(Color(0xFFFFF176), CircleShape)
                                )
                            }

                            // Horizontal Level Indicator line
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .padding(horizontal = 24.dp)
                                    .background(Color.White.copy(alpha = 0.12f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .size(width = 16.dp, height = 8.dp)
                                        .border(
                                            BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                                            RoundedCornerShape(1.dp)
                                        )
                                )
                            }

                            // Show standard visual label indicator about simulated sandbox
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(14.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(Color.Red)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "SIMULAR VIEWPORT",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }
                        }
                    }

                    // Viewfinder grid overlay settings
                    if (grid == GridMode.GRID_3X3) {
                        val strokeColor = Color.White.copy(alpha = 0.25f)
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            // Vertical lines
                            drawLine(strokeColor, Offset(w / 3f, 0f), Offset(w / 3f, h), strokeWidth = 1.dp.toPx())
                            drawLine(strokeColor, Offset(w * 2 / 3f, 0f), Offset(w * 2 / 3f, h), strokeWidth = 1.dp.toPx())
                            // Horizontal lines
                            drawLine(strokeColor, Offset(0f, h / 3f), Offset(w, h / 3f), strokeWidth = 1.dp.toPx())
                            drawLine(strokeColor, Offset(0f, h * 2 / 3f), Offset(w, h * 2 / 3f), strokeWidth = 1.dp.toPx())
                        }
                    } else if (grid == GridMode.GOLDEN_RATIO) {
                        val strokeColor = Color.White.copy(alpha = 0.2f)
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            val phiValue = 0.618f
                            // Vertical phi
                            drawLine(strokeColor, Offset(w * (1f - phiValue), 0f), Offset(w * (1f - phiValue), h), strokeWidth = 1.dp.toPx())
                            drawLine(strokeColor, Offset(w * phiValue, 0f), Offset(w * phiValue, h), strokeWidth = 1.dp.toPx())
                            // Horizontal phi
                            drawLine(strokeColor, Offset(0f, h * (1f - phiValue)), Offset(w, h * (1f - phiValue)), strokeWidth = 1.dp.toPx())
                            drawLine(strokeColor, Offset(0f, h * phiValue), Offset(w, h * phiValue), strokeWidth = 1.dp.toPx())
                        }
                    }

                    // Interactive Tap-to-Focus visual indicators (fade-out ring)
                    focusPoint?.let { point ->
                        Box(
                            modifier = Modifier
                                .absoluteOffset(
                                    x = with(LocalDensity.current) { point.first.toDp() - 25.dp },
                                    y = with(LocalDensity.current) { point.second.toDp() - 25.dp }
                                )
                                .size(50.dp)
                                .border(1.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                        ) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(6.dp)
                                    .background(Color.White, CircleShape)
                            )
                        }
                        LaunchedEffect(point) {
                            delay(1200)
                            cameraManager.lensController.resetFocusPoint()
                        }
                    }

                    // Interactive AI: LIVE OCR capture text anchors
                    if (ocrEnabled) {
                        val lines = remember { cameraManager.imageProcessor.performOcrDetectionSimulation() }
                        lines.forEach { textLine ->
                            Box(
                                modifier = Modifier
                                    .absoluteOffset(
                                        x = with(LocalDensity.current) { (textLine.x * 300).dp },
                                        y = with(LocalDensity.current) { (textLine.y * 500).dp }
                                    )
                                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                    .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = textLine.text,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    // Interactive AI: LIVE Bounding Object detection targets
                    if (objectDetectEnabled) {
                        val objects = remember { cameraManager.imageProcessor.performObjectDetectionSimulation() }
                        objects.forEach { obj ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val leftPx = obj.left * size.width
                                    val topPx = obj.top * size.height
                                    val rightPx = obj.right * size.width
                                    val bottomPx = obj.bottom * size.height
                                    
                                    // Draw dotted bounding border
                                    drawRect(
                                        color = Color.White,
                                        topLeft = Offset(leftPx, topPx),
                                        size = androidx.compose.ui.geometry.Size(rightPx - leftPx, bottomPx - topPx),
                                        style = Stroke(
                                            width = 1.dp.toPx(),
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                        )
                                    )
                                    
                                    // Target focus circle inside center
                                    drawCircle(
                                        color = Color.White.copy(alpha = 0.15f),
                                        radius = 20f,
                                        center = Offset((leftPx + rightPx) / 2f, (topPx + bottomPx) / 2f)
                                    )
                                }
                                // Text tag description floating at bottom left of frame
                                Box(
                                    modifier = Modifier
                                        .absoluteOffset(
                                            x = with(LocalDensity.current) { (obj.left * 350).dp },
                                            y = with(LocalDensity.current) { (obj.top * 500).dp - 24.dp }
                                        )
                                        .background(Color.White, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${obj.label} • ${(obj.confidence * 100).toInt()}%",
                                        color = Color.Black,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                }
                            }
                        }
                    }

                    // Interactive AI: DOCUMENT crop helper polygon highlights
                    if (docScanEnabled) {
                        val doc = remember { cameraManager.imageProcessor.performDocumentScanningSimulation() }
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            
                            val p1 = Offset(doc.p1.first * w, doc.p1.second * h)
                            val p2 = Offset(doc.p2.first * w, doc.p2.second * h)
                            val p3 = Offset(doc.p3.first * w, doc.p3.second * h)
                            val p4 = Offset(doc.p4.first * w, doc.p4.second * h)
 
                            // Draw highlighter polygon lines
                            val linesPath = androidx.compose.ui.graphics.Path().apply {
                                moveTo(p1.x, p1.y)
                                lineTo(p2.x, p2.y)
                                lineTo(p3.x, p3.y)
                                lineTo(p4.x, p4.y)
                                close()
                            }
                            drawPath(
                                path = linesPath,
                                color = Color.White.copy(alpha = 0.08f)
                            )
                            drawPath(
                                path = linesPath,
                                color = Color.White,
                                style = Stroke(width = 1.5.dp.toPx())
                            )
                        }
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .background(Color.White, RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                "📄 DOCUMENT ALIGNED",
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif
                            )
                        }
                    }

                    // AI Scene indicator subtitle pill at bottom of viewfinder
                    if (aiSceneEnabled) {
                        val sceneText = remember(isFrontCamera, audioDb, mode) {
                            cameraManager.imageProcessor.analyzeSceneForAi(isFrontCamera, 120f, mode)
                        }
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 14.dp)
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = "AI Lens",
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = sceneText,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // ACTIVE PIPELINE PROCESS PROGRESS OVERLAY (Visual cue for complex photos)
                    if (isCapturing && captureProgress < 1f) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.7f))
                        ) {
                            Column(
                                modifier = Modifier.align(Alignment.Center),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(
                                    progress = { captureProgress },
                                    color = Color.White,
                                    trackColor = Color.White.copy(alpha = 0.15f),
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(56.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "PROCESSING...",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.8.sp
                                )
                                Text(
                                    text = "${(captureProgress * 100).toInt()}% Done",
                                    color = Color.White.copy(alpha = 0.5f),
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }

                    // ACTIVE SELF TIMER COUNTDOWN OVERLAY
                    if (timerCount > 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.45f))
                        ) {
                            Column(
                                modifier = Modifier.align(Alignment.Center),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "$timerCount",
                                    color = Color.White,
                                    fontSize = 90.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.SansSerif,
                                    modifier = Modifier.scaleAndFadeCountAnimation(timerCount)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { cameraManager.photoCapture.cancelCountdown() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("CANCEL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
                                }
                            }
                        }
                    }

                    // VIDEO RECORDING HUD (Timer duration, pause indicators, sound decibel gauge)
                    if (isRecording) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            // Recording dot & length counter
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isPaused) Color.Gray else Color.Red)
                                        .shimmerPulseEffect(active = !isPaused)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = cameraManager.videoCapture.getFormattedDuration(),
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            // Dynamic Live decibel audio bouncer slider
                            Row(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
                                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (audioDb < -45f) Icons.Filled.MicOff else Icons.Filled.Mic,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                // Decibel waveform canvas bars
                                Canvas(modifier = Modifier.size(width = 40.dp, height = 14.dp)) {
                                    val dbScale = ((audioDb + 60f) / 60f).coerceIn(0.1f, 1f)
                                    val count = 5
                                    val space = 3.dp.toPx()
                                    val barWidth = 4.dp.toPx()
                                    
                                    for (i in 0 until count) {
                                        val randomHeight = (size.height * dbScale * (0.4f + Math.random().toFloat() * 0.6f)).coerceIn(2f, size.height)
                                        drawRect(
                                            color = Color.White.copy(alpha = 0.8f),
                                            topLeft = Offset(i * (barWidth + space), size.height - randomHeight),
                                            size = androidx.compose.ui.geometry.Size(barWidth, randomHeight)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // CAMERA CAPTURED FLASH HIT FEEDBACK
                    if (shutterFlashActive) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.White)
                        )
                    }
                }

                // 3. MANUAL / PRO CAMERA PARAMETER DIAL (ISO, Shutter, WB)
                AnimatedVisibility(
                    visible = isProModeEnabled,
                    enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .background(Color(0xFF0F0F10), RoundedCornerShape(16.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            "PRO MANUAL OVERRIDES",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 8.dp),
                            letterSpacing = 1.6.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // ISO Slider Selector
                            Column(modifier = Modifier.weight(1f)) {
                                Text("ISO ${iso}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Slider(
                                    value = iso.toFloat(),
                                    onValueChange = { cameraManager.settings.setIso(it.toInt()) },
                                    valueRange = 100f..3200f,
                                    steps = 6,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color.White,
                                        activeTrackColor = Color.White,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.12f)
                                    ),
                                    modifier = Modifier.padding(end = 8.dp)
                                )
                            }
                            // Exposure level Dial Selector
                            Column(modifier = Modifier.weight(1f)) {
                                val expLabel = if (exposure >= 0) "+$exposure.0" else "$exposure.0"
                                Text("EV $expLabel", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Slider(
                                    value = exposure.toFloat(),
                                    onValueChange = { cameraManager.lensController.setExposure(it.toInt()) },
                                    valueRange = -4f..4f,
                                    steps = 8,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color.White,
                                        activeTrackColor = Color.White,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.12f)
                                    ),
                                    modifier = Modifier.padding(start = 8.dp)
                                )
                            }
                        }
                        
                        // White Balance Pills row
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("WHITE BALANCE (KELVIN)", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("AUTO", "SUNNY", "CLOUDY", "INCANDESCENT", "FLUORESCENT").forEach { modeWb ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (wb == modeWb) Color.White else Color.White.copy(alpha = 0.08f))
                                        .clickable { cameraManager.settings.setWhiteBalance(modeWb) }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = modeWb.take(4),
                                        color = if (wb == modeWb) Color.Black else Color.White.copy(alpha = 0.6f),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. SMART OPTICAL ZOOM PRESET DIALS & CONTINUOUS ZOOM ROLLER
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Lens Picker Buttons
                    Row(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(20.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(20.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(
                            LensType.ULTRA_WIDE,
                            LensType.WIDE,
                            LensType.TELEPHOTO,
                            LensType.SUPER_ZOOM
                        ).forEach { lensType ->
                            val isSelected = (zoom == lensType.zoomFactor)
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (isSelected) Color.White else Color.Transparent)
                                    .clickable { cameraManager.lensController.selectPresetLens(lensType) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = lensType.label,
                                    color = if (isSelected) Color.Black else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Micro drag-slider for precise zooming ratio
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 48.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Remove, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                        Slider(
                            value = zoom,
                            onValueChange = { cameraManager.lensController.setZoomScale(it) },
                            valueRange = minZoom..maxZoom,
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = Color.White,
                                inactiveTrackColor = Color.White.copy(alpha = 0.12f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp)
                                .testTag("zoom_slider")
                        )
                        Text(
                            text = String.format("%.1fx", zoom),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(36.dp),
                            textAlign = TextAlign.End
                        )
                    }
                }

                // 5. CAMERA MODE SLIDING TRACKER SELECTOR
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val modes = CameraMode.values()
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(horizontal = 90.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(modes) { cameraMode ->
                            val isSelected = (cameraMode == mode)
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable { cameraManager.settings.setCameraMode(cameraMode) }
                            ) {
                                Text(
                                    text = cameraMode.name,
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.4f),
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                    letterSpacing = 1.8.sp,
                                    fontFamily = FontFamily.SansSerif,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .size(if (isSelected) 4.dp else 0.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                )
                            }
                        }
                    }
                }

                // 6. MAIN CAPTURE TRIGGER BAR (Gallery Thumbnail, Click Shutter, Swap Camera Rotate)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 32.dp, vertical = 18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // GALLERY THUMBNAIL (Shows preview of captured content)
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .clickable { showGalleryDialog = true }
                            .testTag("gallery_thumbnail"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (lastCapturedUri != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(Color(0xFF6366F1), Color(0xFFA855F7))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PhotoLibrary,
                                    contentDescription = "Captured Media List",
                                    tint = Color.White.copy(alpha = 0.9f),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.White.copy(alpha = 0.08f))
                                    .border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Photo,
                                    contentDescription = "Empty Library",
                                    tint = Color.White.copy(alpha = 0.35f),
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                    }

                    // PRIMARY SHUTTER BUTTON TRIGGER DIAL
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .clickable(enabled = !isCapturing) {
                                if (mode == CameraMode.VIDEO) {
                                    cameraManager.toggleVideoRecording()
                                } else {
                                    cameraManager.performCapture()
                                }
                            }
                            .testTag("shutter_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        // Styled Leica / Apple Camera core double-ring
                        val ringColor = if (mode == CameraMode.VIDEO && isRecording) Color.Red else Color.White
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(
                                color = ringColor,
                                radius = size.width / 2.1f,
                                style = Stroke(width = 3.dp.toPx())
                            )
                        }

                        // Inner core visual morph
                        if (mode == CameraMode.VIDEO) {
                            Box(
                                modifier = Modifier
                                    .size(if (isRecording) 24.dp else 52.dp)
                                    .clip(RoundedCornerShape(if (isRecording) 6.dp else 26.dp))
                                    .background(Color.Red)
                                    .shimmerPulseEffect(active = isRecording)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                            )
                        }
                    }

                    // SWAP CAMERA LENS SWAP TRIGGER PIN
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.08f))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape)
                            .clickable {
                                rotationDegrees += 180f
                                cameraManager.switchFacingCamera(lifecycleOwner, PreviewView(context))
                            }
                            .testTag("camera_facing_toggle"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FlipCameraAndroid,
                            contentDescription = "Switch Camera Front or Rear",
                            tint = Color.White,
                            modifier = Modifier
                                .size(24.dp)
                                .rotate(animatedRotation)
                        )
                    }
                }
            }

            // AI ASSIST OPTIONS POPUP menu and bottom layout
            AnimatedVisibility(
                visible = isSettingsOpen,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F0F10), RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                        .padding(24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "AI ASSISTED INTELLIGENCE",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                        IconButton(
                            onClick = { isSettingsOpen = false },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White.copy(alpha = 0.6f))
                        }
                    }
                    Divider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 12.dp))

                    // AI Scene recognition toggle
                    AiFeatureRow(
                        title = "AI Scene Optimization",
                        desc = "Auto-tunes dynamic curves for sunsets, greenery, skies, or low-light.",
                        enabled = aiSceneEnabled,
                        onToggle = { cameraManager.settings.setAiSceneRecognitionEnabled(it) }
                    )

                    // OCR Live subtitles overlay toggle
                    AiFeatureRow(
                        title = "OCR Text Scanner",
                        desc = "Pinpoint & extract printed textual layers inside viewfinder on-the-fly.",
                        enabled = ocrEnabled,
                        onToggle = { cameraManager.settings.setOcrCaptureEnabled(it) }
                    )

                    // Document boundary identification scan guide toggle
                    AiFeatureRow(
                        title = "Document Scanner Frame",
                        desc = "Detect printed papers edge-coordinates and align boundary guides.",
                        enabled = docScanEnabled,
                        onToggle = { cameraManager.settings.setDocumentScanEnabled(it) }
                    )

                    // Object detection tags toggle
                    AiFeatureRow(
                        title = "Smart Object Locator",
                        desc = "Draw dynamic confidence anchors linking common items.",
                        enabled = objectDetectEnabled,
                        onToggle = { cameraManager.settings.setObjectDetectionEnabled(it) }
                    )
                }
            }

            // PREVIEW LIBRARY OVERLAY METADATA VISUALIZER DIALOG
            if (showGalleryDialog) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                        .padding(24.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { showGalleryDialog = false }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }
                            Text(
                                "MEDIA GALLERY",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.width(48.dp))
                        }

                        Divider(color = Color.White.copy(alpha = 0.12f), modifier = Modifier.padding(vertical = 12.dp))

                        if (lastCapturedUri != null) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFF0F0F10))
                                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    // Visual image placeholder representing final photo/video output
                                    Icon(
                                        imageVector = if (mode == CameraMode.VIDEO) Icons.Filled.VideoFile else Icons.Filled.Image,
                                        contentDescription = "Preview",
                                        tint = Color.White,
                                        modifier = Modifier.size(120.dp)
                                    )
                                    Spacer(modifier = Modifier.height(24.dp))
                                    Text(
                                        text = "Processed File Metadata Signature",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    
                                    // Beautifully printed metadata matrix block (EXIF parameters)
                                    MetadataItemRow(label = "URI Stream Path", value = lastCapturedUri.toString().take(120))
                                    MetadataItemRow(label = "Camera Subsystem", value = "Leica Noctilux-M Lens Core")
                                    MetadataItemRow(label = "ISO Speed Rating", value = "ISO $iso")
                                    MetadataItemRow(label = "Focal Distance", value = String.format("%.1fx multiplier (f/1.8)", zoom))
                                    MetadataItemRow(label = "Dynamic Range", value = if (isHdr) "Enhanced HDR 10-Bit" else "Standard sRGB")
                                    MetadataItemRow(label = "Quality Frame", value = quality.name)
                                    MetadataItemRow(label = "Sovereign Stamp", value = "VERIFIED SHA256 BLOCK")
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(24.dp))
                            // Share action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                              ) {
                                Button(
                                    onClick = {
                                        try {
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = if (mode == CameraMode.VIDEO) "video/*" else "image/*"
                                                putExtra(Intent.EXTRA_STREAM, lastCapturedUri)
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Master File"))
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "No share support ready", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                    modifier = Modifier.weight(1f).height(48.dp),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Filled.Share, contentDescription = null, tint = Color.Black)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("SHARE FILE", color = Color.Black, fontWeight = FontWeight.Black)
                                }
                                
                                OutlinedButton(
                                    onClick = { showGalleryDialog = false },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    modifier = Modifier.weight(1f).height(48.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
                                ) {
                                    Text("DISMISS")
                                }
                            }
                        } else {
                            // Library Empty State
                            Box(
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Outlined.PhotoLibrary,
                                        contentDescription = null,
                                        tint = Color.DarkGray,
                                        modifier = Modifier.size(64.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        "No captured files in this session yet.",
                                        color = Color.LightGray,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiFeatureRow(
    title: String,
    desc: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(0.82f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(desc, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Switch(
            checked = enabled,
            onCheckedChange = { onToggle(it) },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = Color(0xFF30D158),
                uncheckedThumbColor = Color.LightGray,
                uncheckedTrackColor = Color.DarkGray
            )
        )
    }
}

@Composable
fun MetadataItemRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = Color.Gray, fontSize = 11.sp)
        Text(
            text = value,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.End,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}

// Visual animations helpers

fun Modifier.shimmerPulseEffect(active: Boolean): Modifier = if (active) {
    this.composed {
        val infiniteTransition = rememberInfiniteTransition()
        val pulse by infiniteTransition.animateFloat(
            initialValue = 1f,
            targetValue = 0.5f,
            animationSpec = infiniteRepeatable(
                animation = tween(800, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            )
        )
        this.graphicsLayer { alpha = pulse }
    }
} else this

fun Modifier.scaleAndFadeCountAnimation(timerCount: Int): Modifier = this.composed {
    val scale = remember { Animatable(1.5f) }
    val alpha = remember { Animatable(0f) }
    
    LaunchedEffect(timerCount) {
        scale.snapTo(1.5f)
        alpha.snapTo(0f)
        launch { scale.animateTo(1.0f, animationSpec = tween(500, easing = FastOutSlowInEasing)) }
        launch { alpha.animateTo(1.0f, animationSpec = tween(200)) }
    }
    
    this.graphicsLayer {
        scaleX = scale.value
        scaleY = scale.value
        this.alpha = alpha.value
    }
}
