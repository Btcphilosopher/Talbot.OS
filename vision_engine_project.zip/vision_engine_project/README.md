# vision_engine

A computational photography laboratory for a hypothetical **2029-era
smartphone image sensor** — a full simulated pipeline from synthetic RAW
sensor data through HDR, denoising, colour science, computational zoom,
night photography and portrait processing, to a final photograph. There is
no real sensor and no real photo dataset anywhere in this repository:
everything downstream of the physically-modelled sensor simulator is
exercised against procedurally generated synthetic scenes, which is what
makes the whole thing runnable, testable and benchmarkable end to end
without external data.

```
NEXT-GEN SENSOR
       |
HIGH-DYNAMIC-RANGE RAW        (sensor/, raw/, calibration/, hdr/)
       |
AI ISP                        (denoise/, demosaic/, colour/, tone_mapping/)
       |
MULTI-FRAME ENGINE             (hdr/, night/, motion/)
       |
COMPUTATIONAL PHOTOGRAPHY      (super_resolution/, portrait/, scene/)
       |
COLOUR SCIENCE                 (colour/, tone_mapping/)
       |
SUPER RESOLUTION                (super_resolution/)
       |
SMARTPHONE CAMERA               (simulator/, pipeline/, api/)
```

The guiding principle: **don't simply capture more photons — extract more
information from every photon the sensor captures.**

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt        # core + accel + neural + api + dev, see pyproject.toml for extras
python examples/01_basic_capture.py    # the spec's basic capture example
python examples/02_capture_modes.py    # HDR / night / portrait / zoom, one call each
pytest                                  # 53 tests across every module
uvicorn vision_engine.api.app:app --reload   # the camera-processing API
```

`torch` and `numba` are optional (see `vision_engine/utils/optional_deps.py`)
-- every neural stage has a classical fallback and every hot loop runs as
plain NumPy if they aren't installed, so `pip install -e .` (core deps
only) is enough to run the whole pipeline; installing the `neural`/`accel`
extras just makes it faster/better, not different in kind.

## The core pipeline

```
RAW FRAME -> BLACK LEVEL/CALIBRATION -> DEFECT CORRECTION -> DENOISING
   -> DEMOSAIC -> COLOUR SCIENCE -> TONE MAPPING -> LOCAL CONTRAST
   -> SUPER RESOLUTION -> SHARPENING -> FINAL IMAGE
```

implemented end to end in `vision_engine/pipeline/pipeline.py`, with two
deliberate reorderings from that nominal sequence (denoise running after
demosaic, and tone mapping running before colour science) explained in
that file's module docstring — both are about giving each stage well-formed
input, not shortcuts.

```python
from vision_engine.sensor import Sensor, SensorConfig
from vision_engine.pipeline import Pipeline

camera = Sensor(SensorConfig(width=8192, height=6144, bit_depth=14))
raw = camera.capture(exposure=1 / 120, iso=400)

pipeline = Pipeline()
image = pipeline.process(raw)
image.save("photo.jpg")
```

## The high-level camera API

```python
from vision_engine.simulator import Camera
from vision_engine.sensor import SensorConfig

camera = Camera(SensorConfig(width=8192, height=6144, bit_depth=14))

result = camera.capture_hdr()          # -2/0/+2 EV bracket, motion-aware merge
result = camera.capture_night()        # up to 12-frame low-light fusion
result = camera.capture_portrait()     # segmentation + depth + synthetic bokeh
result = camera.computational_zoom(5.0)  # sensor crop -> digital -> multi-frame SR -> AI reconstruction
```

`Camera` *is* a `Sensor` (same constructor, same `capture`/`capture_burst`)
plus every computational photography engine wired up behind it and a
bundled `Pipeline`. Every `capture_*` call also runs **SMART EXPOSURE**
(`Camera.auto_expose`) by default: it meters the scene, then picks
ISO/shutter/HDR-bracket-vs-single-exposure/night-frame-count, prioritising
highlight protection while retaining shadow detail — see
`vision_engine/pipeline/smart_exposure.py`.

## Project structure

```
vision_engine/
├── sensor/            configurable virtual sensor: Bayer / Quad-Bayer / RGBW / Stacked-CMOS, physically-modelled noise
├── raw/                internal VRAW container + DNG/TIFF/PNG/JPEG export
├── calibration/        black level, defect correction, lens shading
├── hdr/                 multi-bracket alignment, motion-aware merge, highlight/shadow recovery
├── denoise/             classical / spatial / temporal / neural denoising + detail-preserving blending
├── demosaic/             pattern-agnostic + Malvar-He-Cutler demosaicing, Quad-Bayer binning, RGBW fusion
├── colour/               matrix -> white balance -> CCM -> tone curve -> gamut mapping
├── tone_mapping/         HDR dynamic-range compression (Reinhard/ACES/local) + local-contrast "clarity"
├── super_resolution/     computational zoom: crop -> digital -> computational -> multi-frame SR -> AI reconstruction
├── night/                 multi-frame low-light fusion
├── portrait/              segmentation, pseudo-depth, skin-aware smoothing, synthetic depth-of-field
├── motion/                 alignment, motion-mask ghost detection, coarse motion-region classification
├── scene/                  lightweight nearest-centroid scene classifier + per-scene pipeline presets
├── pipeline/               the orchestrator, smart exposure, sharpening, ProcessedImage
├── models/                  small PyTorch reference nets (DnCNN-style denoiser, ESPCN-style SR)
├── api/                     FastAPI camera-processing service
├── simulator/                Camera, procedural scene library, async real-time preview
├── benchmarks/                automated ResearchLab (PSNR/SSIM/latency comparisons)
├── visualisation/              Bayer/noise/HDR/depth/motion/histogram/tone-curve/RAW-vs-processed views
└── tests/                      53 tests across every module above
```

## Honest limitations

A research lab, not a shipped product — these are the known gaps,
documented rather than hidden:

- **Scene classification accuracy drops** once fed real pipeline output
  (post-demosaic/HDR/denoise) rather than the idealised scene-generator
  truth its reference centroids were built from (100% held-out accuracy
  on the latter, see `tests/test_night_portrait_scene.py` and
  `ResearchLab.benchmark_scene_classifier`) — the interface is what a
  trained on-device classifier would slot into unchanged.
- **Portrait depth/segmentation** are classical-CV heuristics (GrabCut +
  a saliency prior, a blur/distance pseudo-depth cue), explicitly a stand-in
  for a trained matting/monocular-depth model, documented in
  `vision_engine/portrait/portrait_engine.py`.
- **`RawFrame.to_dng`** writes a structurally-valid, honestly-labelled
  "simplified DNG" (TIFF/EP raw tags + a JSON metadata sidecar), not a full
  Adobe DNG-spec container (no opcode lists / per-illuminant calibration
  IFDs) — see `vision_engine/raw/converters.py`.
- **Multi-frame super-resolution quality is bounded by the synthetic
  burst generator**: procedurally-rendered low-resolution frames don't
  always carry genuine sub-Nyquist detail across shifts the way a real
  optical burst does, so shift-and-add SR can trail simple upscaling on
  some scenes in `ResearchLab.benchmark_super_resolution` — a real, visible
  finding from the benchmark tooling, not a hidden defect.

## A debugging story worth knowing about

Two of the trickiest bugs found while building this lab were both
instances of the same failure mode — **comparing frames that aren't on a
comparable scale** — and both are now regression-tested:

1. `Sensor.capture_burst`'s per-frame `scene_radiance` was being
   `dict.pop()`'d, so only the *first* frame of every burst used the
   intended scene and the rest silently fell back to the sensor's default
   test scene — invisible in single-frame tests, catastrophic for night
   mode and multi-frame SR (`tests/test_night_portrait_scene.py`).
2. HDR motion detection normalised each bracket frame's brightness by
   *that frame's own* 99th-percentile pixel — fine for a single frame, but
   across an exposure bracket, how far a highlight recovers differs *by
   design* between exposures, so this silently reintroduced the exact
   brightness mismatch radiance-normalisation was meant to remove and
   flagged perfectly static scenes as almost entirely "in motion"
   (`vision_engine/motion/motion_engine.py`'s `to_gray_u8`/`detect_motion_mask`,
   regression-tested in `tests/test_hdr_motion.py`).

## Training the reference neural models

```bash
python scripts/train_toy_models.py --steps 400
```

Trains `DenoiseNet` and `SuperResNet` briefly on synthetic noisy/clean
pairs generated by the sensor simulator + scene library, and saves
checkpoints to `assets/models/`. `vision_engine/denoise/neural.py` and
`vision_engine/super_resolution/zoom_engine.py` load them automatically if
present, and fall back to an untrained-but-safe identity network (or a
classical algorithm, if `torch` isn't installed at all) otherwise.

## License

MIT — see `LICENSE`.
