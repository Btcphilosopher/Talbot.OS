#!/usr/bin/env python3
"""Train the small reference models on purely synthetic data.

This is a *research-lab* training script -- a few hundred steps on
procedurally generated scenes, enough to produce genuinely useful (not
just identity) weights for the denoiser and super-resolution network so
the RESEARCH LAB's classical-vs-neural comparisons are meaningful. It is
not a production training pipeline (no val split tracking, no LR
schedule, no distributed data loading) -- see PERFORMANCE.md for how this
would scale towards one.

Usage: python scripts/train_toy_models.py [--steps 400] [--device cpu]
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import torch
from torch import nn

from vision_engine.models.denoise_net import DenoiseNet
from vision_engine.models.sr_net import SuperResNet
from vision_engine.simulator.scenes import GENERATORS, generate_scene

PATCH = 64
ASSETS = Path(__file__).resolve().parents[1] / "assets" / "models"


def random_clean_patch(rng: np.random.Generator) -> np.ndarray:
    kind = rng.choice(list(GENERATORS))
    h = w = PATCH * 2
    scene = generate_scene(kind, h, w, seed=int(rng.integers(0, 1_000_000)))
    y0 = int(rng.integers(0, h - PATCH))
    x0 = int(rng.integers(0, w - PATCH))
    patch = np.clip(scene[y0:y0 + PATCH, x0:x0 + PATCH], 0.0, 1.5)
    return patch.astype(np.float32)


def add_synthetic_noise(clean: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """A simplified sensor-like noise model (signal-dependent shot noise +
    read noise) at a randomised severity, for augmentation variety."""
    iso_factor = rng.uniform(0.5, 6.0)
    shot = rng.normal(0, np.sqrt(np.clip(clean, 0, None)) * 0.04 * iso_factor, size=clean.shape)
    read = rng.normal(0, 0.01 * iso_factor, size=clean.shape)
    return (clean + shot + read).astype(np.float32)


def train_denoiser(steps: int, device: str) -> None:
    model = DenoiseNet().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=2e-3)
    loss_fn = nn.L1Loss()
    rng = np.random.default_rng(0)

    t0 = time.time()
    for step in range(steps):
        batch_clean, batch_noisy = [], []
        for _ in range(16):
            clean = random_clean_patch(rng)
            noisy = add_synthetic_noise(clean, rng)
            batch_clean.append(clean)
            batch_noisy.append(noisy)
        clean_t = torch.from_numpy(np.stack(batch_clean)).permute(0, 3, 1, 2).to(device)
        noisy_t = torch.from_numpy(np.stack(batch_noisy)).permute(0, 3, 1, 2).to(device)

        opt.zero_grad()
        pred = model(noisy_t)
        loss = loss_fn(pred, clean_t)
        loss.backward()
        opt.step()

        if step % 50 == 0 or step == steps - 1:
            print(f"[denoiser] step {step:4d}/{steps}  L1={loss.item():.4f}  ({time.time()-t0:.1f}s)")

    ASSETS.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), ASSETS / "denoise_net.pt")
    print(f"saved {ASSETS / 'denoise_net.pt'}")


def train_super_res(steps: int, device: str, scale: int = 2) -> None:
    import torch.nn.functional as F

    model = SuperResNet(scale=scale).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=2e-3)
    loss_fn = nn.L1Loss()
    rng = np.random.default_rng(1)

    t0 = time.time()
    for step in range(steps):
        batch_hr, batch_lr = [], []
        for _ in range(12):
            hr = random_clean_patch(rng)
            batch_hr.append(hr)
        hr_t = torch.from_numpy(np.stack(batch_hr)).permute(0, 3, 1, 2).to(device)
        lr_t = F.interpolate(hr_t, scale_factor=1 / scale, mode="area")
        lr_t = F.interpolate(lr_t, size=hr_t.shape[-2:], mode="nearest")  # keep spatial dims, low detail
        lr_small = F.avg_pool2d(hr_t, kernel_size=scale)

        opt.zero_grad()
        pred = model(lr_small)
        loss = loss_fn(pred, hr_t)
        loss.backward()
        opt.step()

        if step % 50 == 0 or step == steps - 1:
            print(f"[sr]       step {step:4d}/{steps}  L1={loss.item():.4f}  ({time.time()-t0:.1f}s)")

    ASSETS.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), ASSETS / "sr_net.pt")
    print(f"saved {ASSETS / 'sr_net.pt'}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=400)
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()

    train_denoiser(args.steps, args.device)
    train_super_res(args.steps, args.device)
