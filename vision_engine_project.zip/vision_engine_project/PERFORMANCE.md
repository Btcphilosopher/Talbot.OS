# Performance architecture

> *"Don't simply capture more photons — extract more information from every
> photon the sensor captures."*

Every computationally expensive stage in `vision_engine` is written so it
can move down this ladder without changing its call site:

```
Python  ->  Numba (@njit)  ->  C/C++  ->  Rust  ->  GPU / NPU
```

## Where this shows up today

- **`vision_engine/utils/optional_deps.py`** — `@maybe_jit` JIT-compiles a
  function with `numba.njit` when numba is installed, and is a no-op
  decorator otherwise. Every hot per-pixel loop in the codebase (defect
  correction, guided filter, shift-and-add super-resolution splatting) is
  written as plain NumPy first and is a candidate for this decorator; the
  correctness never depends on whether it's applied.
- **`vision_engine/models/`** — the denoiser and super-resolution nets are
  PyTorch `nn.Module`s. `HAS_TORCH` in `optional_deps.py` gates every call
  site so the whole pipeline degrades to a classical algorithm rather than
  hard-failing when torch (or a GPU) isn't available — the same interface
  (`denoise_neural(rgb)`, `ai_reconstruct(image, scale)`) works with a CPU
  fallback, a local GPU, or eventually an on-device NPU delegate.
- **`vision_engine/utils/profiling.py`** — `Profiler`/`Profile` wrap every
  pipeline stage in a `with profiler.stage("name"):` block, so *any* stage
  swapped for a faster implementation immediately shows up in
  `ProcessedImage.profile.as_table()` without additional instrumentation.
  `gpu_utilisation()` reports CUDA memory/device info when available and
  `{"available": False}` everywhere else, so the benchmarking code never
  branches on whether a GPU is present.

## What to measure, and where

| Metric | How |
|---|---|
| RAW processing time | `Pipeline.process(raw).profile` — see the `calibration_defect_correction` / `demosaic` stage entries |
| HDR processing time | `HDREngine.merge_bracket` isn't auto-profiled (it's called before a `Pipeline`); wrap it in your own `Profiler.stage(...)` the same way `Pipeline._finish` does |
| AI inference time | `profile.stages` entries for `denoise` (when `DenoiseStrategy.NEURAL`/`AUTO` picks it) and `super_resolution` |
| Memory consumption | `StageRecord.peak_memory_mb` (via `tracemalloc`) on every stage; `vision_engine.utils.profiling.process_memory_mb()` for whole-process RSS |
| GPU utilisation | `vision_engine.utils.profiling.gpu_utilisation()` |
| Frames/sec | `Profile.fps` (`1 / total_seconds`); `RealtimePreview` additionally reports live `instantaneous_fps` per frame |

`vision_engine/benchmarks/research_lab.py` (`ResearchLab.benchmark_pipeline`)
automates running a scene through the pipeline N times and reporting
per-stage mean latency in the same table format.

## Known bottlenecks in this reference implementation

Being explicit about what's *not* yet fast, because "production-quality"
here means the architecture and correctness are solid, not that every
stage is optimal:

- **`super_resolution.multi_frame_super_resolve`** — a Python nested loop
  over the splat kernel radius per frame. Correct and legible; the first
  and most obvious `@maybe_jit` candidate in the codebase.
- **`calibration.correct_defects`** — falls back to a full-channel median
  blur per colour plane; fine at sensor-defect densities (~1e-5) but not
  written for pathologically defect-dense sensors.
- **Neural inference** — runs eagerly on CPU with no batching across
  pipeline stages; a production ISP would fuse denoise + SR into one
  scheduled NPU graph rather than two separate `torch` calls.

None of these affect correctness at any resolution -- only wall-clock time.
