import numpy as np

from vision_engine.night.night_engine import NightEngine
from vision_engine.portrait.portrait_engine import PortraitEngine
from vision_engine.scene.scene_classifier import classify
from vision_engine.scene.categories import SceneCategory
from vision_engine.sensor import Sensor, SensorArchitecture, SensorConfig
from vision_engine.simulator.scenes import generate_scene


def test_night_engine_reduces_noise_via_fusion():
    cfg = SensorConfig(width=128, height=96, architecture=SensorArchitecture.BAYER)
    sensor = Sensor(cfg)
    scene = generate_scene("night", 96, 128, seed=5)
    engine = NightEngine()
    result = engine.capture_and_merge(sensor, n_frames=8, exposure=1 / 15, iso=3200, scene_radiance=scene)
    assert result.n_frames == 8
    assert result.image.shape == (96, 128, 3)
    assert not np.isnan(result.image).any()
    assert result.confidence.mean() > 0.3  # most pixels got meaningful multi-frame averaging


def test_portrait_engine_segments_and_blurs():
    scene = np.clip(generate_scene("portrait", 128, 128, seed=6), 0, 1)
    result = PortraitEngine().process(scene)
    assert 0.0 < result.alpha_mask.mean() < 1.0  # a real subject/background split, not all-or-nothing
    assert result.image.shape == scene.shape


def test_scene_classifier_all_categories_recognisable():
    correct = 0
    for cat in SceneCategory:
        scene = np.clip(generate_scene(cat.value, 80, 96, seed=999), 0, 1)
        result = classify(scene)
        correct += int(result.category == cat)
    assert correct >= len(list(SceneCategory)) - 1  # allow at most one miss
