from fastapi.testclient import TestClient

from vision_engine.api.app import app

client = TestClient(app)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_scenes_and_architectures():
    assert client.get("/scenes").status_code == 200
    assert client.get("/architectures").status_code == 200


def test_capture_endpoint():
    r = client.post("/capture", json={"width": 96, "height": 64, "scene": "beach"})
    assert r.status_code == 200
    body = r.json()
    assert body["width"] == 96 and body["height"] == 64
    assert len(body["image_base64"]) > 100


def test_capture_hdr_endpoint():
    r = client.post("/capture/hdr", json={"width": 96, "height": 64, "scene": "sunset"})
    assert r.status_code == 200


def test_unknown_scene_returns_400():
    r = client.post("/capture", json={"width": 64, "height": 64, "scene": "not_a_scene"})
    assert r.status_code == 400
