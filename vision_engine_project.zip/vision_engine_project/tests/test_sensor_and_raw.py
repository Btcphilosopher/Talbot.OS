import numpy as np

from vision_engine.raw.raw_format import RawFrame


def test_capture_shapes(sensor):
    raw = sensor.capture(exposure=1 / 60, iso=200)
    assert raw.shape == (96, 128)
    assert raw.pixels.dtype in (np.uint16, np.uint32)
    assert raw.pixels.min() >= 0
    assert raw.pixels.max() <= (1 << raw.bit_depth) - 1


def test_capture_burst(sensor):
    frames = sensor.capture_burst(4, exposure=1 / 30, iso=400)
    assert len(frames) == 4
    assert all(f.shape == (96, 128) for f in frames)


def test_iso_increases_noise(sensor):
    # Physically meaningful comparison: hold *equivalent output brightness*
    # constant (as auto-exposure would) by shortening exposure as ISO rises,
    # then measure temporal noise (std across repeated captures of the same
    # static scene). At equal brightness, higher ISO means fewer photons
    # were actually collected before amplification -- so it should be
    # noisier. (Comparing raw std at a *fixed* exposure would conflate this
    # with simple over/under-exposure clipping, which swamps the effect.)
    base_iso, max_iso = sensor.config.base_iso, sensor.config.max_iso
    base_exposure = 1 / 60
    high_iso_exposure = base_exposure * (base_iso / max_iso)

    def temporal_std(iso, exposure, n=5):
        frames = [sensor.capture(exposure=exposure, iso=iso).normalised() for _ in range(n)]
        arr = np.stack(frames)
        assert 0.05 < arr.mean() < 0.95, "test scene not usefully exposed -- adjust reference brightness"
        return np.std(arr, axis=0).mean()

    low_noise = temporal_std(base_iso, base_exposure)
    high_noise = temporal_std(max_iso, high_iso_exposure)
    assert high_noise > low_noise


def test_vraw_roundtrip(tmp_path, sensor):
    raw = sensor.capture(exposure=1 / 60, iso=200)
    path = tmp_path / "frame.vraw"
    raw.save(str(path))
    loaded = RawFrame.load(str(path))
    assert np.array_equal(raw.pixels, loaded.pixels)
    assert loaded.iso == raw.iso
    assert loaded.exposure == raw.exposure
    assert loaded.sensor_params["architecture"] == raw.sensor_params["architecture"]


def test_export_formats(tmp_path, sensor):
    raw = sensor.capture(exposure=1 / 60, iso=200)
    raw.to_png(str(tmp_path / "out.png"))
    raw.to_jpeg(str(tmp_path / "out.jpg"))
    raw.to_tiff(str(tmp_path / "out.tiff"))
    raw.to_dng(str(tmp_path / "out.dng"))
    for name in ("out.png", "out.jpg", "out.tiff", "out.dng"):
        f = tmp_path / name
        assert f.exists() and f.stat().st_size > 0
