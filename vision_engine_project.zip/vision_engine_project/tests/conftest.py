import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from vision_engine.sensor import Sensor, SensorArchitecture, SensorConfig


@pytest.fixture(params=[SensorArchitecture.BAYER, SensorArchitecture.QUAD_BAYER,
                         SensorArchitecture.RGBW, SensorArchitecture.STACKED_CMOS])
def sensor(request) -> Sensor:
    return Sensor(SensorConfig(width=128, height=96, architecture=request.param))
