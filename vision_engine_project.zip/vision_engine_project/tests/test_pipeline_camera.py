import numpy as np

from vision_engine.pipeline.pipeline import Pipeline
from vision_engine.simulator.camera import Camera
from vision_engine.sensor import SensorArchitecture, SensorConfig
from vision_engine.simulator.scenes import generate_scene


def _camera():
    cfg = SensorConfig(width=160, height=120, architecture=SensorArchitecture.QUAD_BAYER)
    return Camera(cfg)


def test_basic_capture_and_process():
    camera = _camera()
    scene = generate_scene("landscape", 120, 160, seed=1)
    raw = camera.capture(exposure=1 / 120, iso=camera.config.base_iso, scene_radiance=scene)
    image = camera.pipeline.process(raw)
    assert image.rgb.shape == (120, 160, 3)
    assert image.to_uint8().dtype == np.uint8
    assert image.profile.total_seconds > 0


def test_capture_hdr():
    camera = _camera()
    scene = generate_scene("sunset", 120, 160, seed=2)
    image = camera.capture_hdr(scene_radiance=scene)
    assert image.rgb.shape == (120, 160, 3)


def test_capture_night():
    camera = _camera()
    scene = generate_scene("night", 120, 160, seed=3)
    image = camera.capture_night(scene_radiance=scene, n_frames=6)
    assert image.rgb.shape == (120, 160, 3)


def test_capture_portrait():
    camera = _camera()
    scene = generate_scene("portrait", 120, 160, seed=4)
    image = camera.capture_portrait(scene_radiance=scene)
    assert "portrait_alpha_mask" in image.metadata


def test_computational_zoom():
    camera = _camera()
    scene = generate_scene("macro", 120, 160, seed=5)
    image = camera.computational_zoom(5.0, scene_radiance=scene)
    assert image.rgb.shape[0] > 0 and image.rgb.shape[1] > 0


def test_save_to_jpeg(tmp_path):
    camera = _camera()
    scene = generate_scene("city", 120, 160, seed=6)
    raw = camera.capture(exposure=1 / 120, iso=100, scene_radiance=scene)
    image = camera.pipeline.process(raw)
    path = tmp_path / "photo.jpg"
    image.save(str(path))
    assert path.exists() and path.stat().st_size > 0


def test_scene_adaptive_toggle_changes_nothing_structurally():
    camera = _camera()
    camera.pipeline = Pipeline()
    camera.pipeline.config.scene_adaptive = False
    scene = generate_scene("food", 120, 160, seed=7)
    raw = camera.capture(exposure=1 / 120, iso=100, scene_radiance=scene)
    image = camera.pipeline.process(raw)
    assert image.scene_classification is None
