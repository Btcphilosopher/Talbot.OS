import numpy as np

from vision_engine.denoise.engine import DenoiseEngine, DenoiseStrategy
from vision_engine.simulator.scenes import generate_scene


def _noisy_clean_pair(seed=0):
    clean = np.clip(generate_scene("macro", 96, 96, seed=seed), 0, 1)
    rng = np.random.default_rng(seed)
    noisy = np.clip(clean + rng.normal(0, 0.05, clean.shape), 0, None).astype(np.float32)
    return clean, noisy


def test_denoise_improves_psnr():
    from skimage.metrics import peak_signal_noise_ratio

    clean, noisy = _noisy_clean_pair()
    engine = DenoiseEngine()
    result = engine.denoise(noisy, strategy=DenoiseStrategy.SPATIAL, preserve_detail=False)
    psnr_before = peak_signal_noise_ratio(clean, np.clip(noisy, 0, 1), data_range=1.0)
    psnr_after = peak_signal_noise_ratio(clean, np.clip(result.image, 0, 1), data_range=1.0)
    assert psnr_after > psnr_before


def test_detail_preservation_recovers_high_frequency():
    clean, noisy = _noisy_clean_pair()
    engine = DenoiseEngine()
    smoothed = engine.denoise(noisy, strategy=DenoiseStrategy.BILATERAL, preserve_detail=False).image
    detailed = engine.denoise(noisy, strategy=DenoiseStrategy.BILATERAL, preserve_detail=True).image
    # detail-preserving mode should retain more high-frequency energy than the raw smoothed output
    hf_smoothed = np.abs(np.diff(smoothed, axis=0)).mean()
    hf_detailed = np.abs(np.diff(detailed, axis=0)).mean()
    assert hf_detailed >= hf_smoothed


def test_compare_returns_sorted_by_psnr():
    clean, noisy = _noisy_clean_pair()
    rows = DenoiseEngine().compare(noisy, clean, strategies=[DenoiseStrategy.BILATERAL, DenoiseStrategy.SPATIAL])
    assert len(rows) == 2
    assert rows[0]["psnr"] >= rows[1]["psnr"]
