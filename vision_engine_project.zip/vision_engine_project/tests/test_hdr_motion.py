import numpy as np

from vision_engine.hdr.hdr_engine import HDREngine
from vision_engine.sensor import Sensor, SensorArchitecture, SensorConfig
from vision_engine.simulator.scenes import generate_scene, generate_scene_sequence


def test_hdr_static_scene_has_no_false_motion():
    cfg = SensorConfig(width=160, height=120, architecture=SensorArchitecture.BAYER)
    sensor = Sensor(cfg)
    scene = generate_scene("landscape", 120, 160, seed=42)
    evs = [-2, 0, 2]
    raws = [sensor.capture(exposure=(1 / 120) * (2.0 ** ev), iso=cfg.base_iso, scene_radiance=scene) for ev in evs]

    engine = HDREngine(reference_bracket=1)
    result = engine.merge_bracket(raws, evs)

    assert result.merged_radiance.shape == (120, 160, 3)
    assert not np.isnan(result.merged_radiance).any()
    # a fully static scene across brackets should show ~no flagged motion
    assert result.motion_mask.mean() < 0.05


def test_hdr_detects_real_subject_motion():
    cfg = SensorConfig(width=160, height=120, architecture=SensorArchitecture.BAYER)
    sensor = Sensor(cfg)
    seq = generate_scene_sequence("sport", 120, 160, n_frames=3, seed=7, camera_shake_px=0.5, subject_motion_px=15.0)
    evs = [-2, 0, 2]
    raws = [sensor.capture(exposure=(1 / 120) * (2.0 ** ev), iso=cfg.base_iso, scene_radiance=s)
            for ev, s in zip(evs, seq)]

    engine = HDREngine(reference_bracket=1)
    result = engine.merge_bracket(raws, evs)

    assert result.motion_mask.sum() > 0
    assert len(result.regions) > 0


def test_extended_range_preserved():
    """Highlights above 1.0 (recoverable dynamic range) should survive the merge."""
    cfg = SensorConfig(width=160, height=120, architecture=SensorArchitecture.BAYER)
    sensor = Sensor(cfg)
    scene = generate_scene("sunset", 120, 160, seed=3)
    evs = [-2, 0, 2]
    raws = [sensor.capture(exposure=(1 / 120) * (2.0 ** ev), iso=cfg.base_iso, scene_radiance=scene) for ev in evs]
    result = HDREngine(reference_bracket=1).merge_bracket(raws, evs)
    assert result.merged_radiance.max() > 1.0
