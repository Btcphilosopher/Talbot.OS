import numpy as np

from vision_engine.colour.colour_science import (
    CINEMATIC_PROFILE,
    apply_white_balance,
    auto_white_balance,
    gamut_map,
)
from vision_engine.tone_mapping.tone_mapping import aces_filmic, local_tone_map, reinhard


def test_white_balance_neutralises_colour_cast():
    grey_scene = np.full((32, 32, 3), 0.5, dtype=np.float32)
    cast = grey_scene * [1.4, 1.0, 0.7]  # warm cast
    wb = auto_white_balance(cast)
    corrected = apply_white_balance(cast, wb)
    assert np.allclose(corrected[..., 0], corrected[..., 2], atol=0.05)


def test_gamut_map_clips_to_unit_range():
    hot = np.array([[[2.0, 1.5, 0.2]]], dtype=np.float32)
    out = gamut_map(hot)
    assert out.max() <= 1.0001 and out.min() >= 0.0


def test_hdr_tone_map_reduces_dynamic_range():
    hdr = np.random.default_rng(0).uniform(0, 8, size=(32, 32, 3)).astype(np.float32)
    reinhard_out = reinhard(hdr)
    aces_out = aces_filmic(hdr)
    local_out = local_tone_map(hdr)
    for out in (reinhard_out, aces_out, local_out):
        assert out.max() <= hdr.max()


def test_colour_profile_end_to_end():
    rgb = np.clip(np.random.default_rng(1).uniform(0, 1.2, size=(16, 16, 3)).astype(np.float32), 0, None)
    out = CINEMATIC_PROFILE.process(rgb)
    assert out.shape == rgb.shape
    assert out.min() >= 0.0 and out.max() <= 1.0001
