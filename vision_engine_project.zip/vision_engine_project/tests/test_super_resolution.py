import numpy as np

from vision_engine.super_resolution.zoom_engine import ZoomEngine, ZoomTier
from vision_engine.simulator.scenes import generate_scene, generate_scene_sequence


def test_zoom_tiers_selected_correctly():
    scene = np.clip(generate_scene("macro", 96, 128, seed=1), 0, 1)
    burst = [np.clip(f, 0, 1) for f in generate_scene_sequence("macro", 96, 128, n_frames=4, seed=1)]
    engine = ZoomEngine()

    assert engine.compute_zoom(scene, 1.5).tier == ZoomTier.SENSOR_CROP
    assert engine.compute_zoom(scene, 2.5).tier == ZoomTier.DIGITAL
    assert engine.compute_zoom(scene, 4.0).tier == ZoomTier.COMPUTATIONAL
    assert engine.compute_zoom(scene, 6.0, burst=burst).tier == ZoomTier.MULTI_FRAME_SR
    assert engine.compute_zoom(scene, 12.0, burst=burst).tier == ZoomTier.AI_RECONSTRUCTION


def test_captured_information_fraction_decreases_with_zoom():
    scene = np.clip(generate_scene("macro", 96, 128, seed=1), 0, 1)
    burst = [np.clip(f, 0, 1) for f in generate_scene_sequence("macro", 96, 128, n_frames=4, seed=1)]
    engine = ZoomEngine()
    fractions = [engine.compute_zoom(scene, z, burst=burst).captured_information_fraction
                 for z in (1.5, 2.5, 4.0, 6.0, 12.0)]
    assert fractions == sorted(fractions, reverse=True)


def test_zoom_output_has_no_nans():
    scene = np.clip(generate_scene("landscape", 80, 96, seed=2), 0, 1)
    result = ZoomEngine().compute_zoom(scene, 2.0, output_size=(192, 160))
    assert result.image.shape == (160, 192, 3)
    assert not np.isnan(result.image).any()
