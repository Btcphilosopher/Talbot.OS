import numpy as np

from vision_engine.calibration.calibration import CalibrationProfile
from vision_engine.demosaic.demosaic import demosaic


def test_calibration_and_demosaic_roundtrip(sensor):
    raw = sensor.capture(exposure=1 / 60, iso=200)
    cal = CalibrationProfile.from_raw_frame(raw)
    mosaic = cal.apply(raw.pixels)
    assert mosaic.min() >= 0.0

    rgb = demosaic(mosaic, pattern=cal.cfa_pattern, architecture=sensor.config.architecture)
    assert rgb.shape == (96, 128, 3)
    assert not np.isnan(rgb).any()
    assert rgb.max() < 10.0  # sane range, no blow-ups


def test_defect_pixels_are_repaired():
    from vision_engine.calibration.calibration import correct_defects
    from vision_engine.sensor.cfa import CFAPattern

    mosaic = np.full((32, 32), 0.5, dtype=np.float32)
    defects = np.zeros((32, 32), dtype=bool)
    defects[10, 10] = True
    mosaic[10, 10] = 0.0  # simulate a dead pixel reading black

    repaired = correct_defects(mosaic, defects, CFAPattern.RGGB)
    assert repaired[10, 10] > 0.3  # pulled back towards neighbours, not left at 0
