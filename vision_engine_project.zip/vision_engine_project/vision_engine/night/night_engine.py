"""NIGHT PHOTOGRAPHY: multi-frame (up to ~12-frame) low-light capture engine.

    FRAME 1..N -> align -> motion-aware fuse -> denoise -> shadow-lift tone
    map -> colour correct for the (often mixed, dim, saturated) light
    source -> clean night photograph.

Averaging many aligned frames is the single biggest lever against shot
noise (an N-frame average reduces noise ~sqrt(N)) but is worthless -- worse
than worthless, it *ghosts* -- without the same motion-aware fusion the
HDR/denoise engines use, since a 12-frame, ~1-2 second-long capture is
exactly the timescale handheld shake and subject motion happen on.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from vision_engine.calibration.calibration import CalibrationProfile
from vision_engine.colour.colour_science import CINEMATIC_PROFILE, ColourProfile, apply_white_balance, auto_white_balance
from vision_engine.demosaic.demosaic import demosaic
from vision_engine.denoise.temporal import temporal_denoise
from vision_engine.denoise.engine import DenoiseEngine, DenoiseStrategy
from vision_engine.motion.motion_engine import analyse as analyse_motion


@dataclass
class NightResult:
    image: np.ndarray                 # display-referred linear RGB, pre colour-profile
    confidence: np.ndarray            # per-pixel effective-frame-count fraction from temporal fusion
    n_frames: int
    motion_regions: list = field(default_factory=list)
    raw_frames: list = field(default_factory=list)


class NightEngine:
    """Aligns, fuses and denoises a low-light burst into one clean photograph."""

    def __init__(self, reference_idx: int = 0) -> None:
        self.reference_idx = reference_idx
        self._denoiser = DenoiseEngine()

    def capture_and_merge(self, sensor, n_frames: int = 12, exposure: float = 1 / 15, iso: int = 3200,
                           scene_sequence: list[np.ndarray] | None = None,
                           scene_radiance: np.ndarray | None = None) -> NightResult:
        if scene_sequence is not None:
            raw_frames = [sensor.capture(exposure=exposure, iso=iso, scene_radiance=s) for s in scene_sequence]
        else:
            raw_frames = sensor.capture_burst(n_frames, exposure=exposure, iso=iso, scene_radiance=scene_radiance)

        demosaiced = []
        for rf in raw_frames:
            cal = CalibrationProfile.from_raw_frame(rf)
            mosaic = cal.apply(rf.pixels)
            rgb = demosaic(mosaic, pattern=cal.cfa_pattern, architecture=_architecture(rf))
            demosaiced.append(rgb)

        fused, confidence = temporal_denoise(demosaiced, reference_idx=self.reference_idx)

        motion = analyse_motion(demosaiced, reference_idx=self.reference_idx)

        # A residual noise-reduction pass: even after N-frame fusion, deep
        # shadows in a night scene are still noise-limited, so run the
        # detail-preserving denoiser once more on the fused result.
        denoised = self._denoiser.denoise(fused, strategy=DenoiseStrategy.AUTO, iso=iso, preserve_detail=True).image

        # Dynamic-range compression (shadow lift without blowing out any
        # genuinely bright light sources in frame) happens in the shared
        # Pipeline tail's TONE MAPPING stage, same as every other capture
        # mode -- this engine's job stops at a clean, fused, linear image.

        return NightResult(
            image=np.clip(denoised, 0.0, None),
            confidence=confidence,
            n_frames=len(raw_frames),
            motion_regions=motion.regions,
            raw_frames=raw_frames,
        )

    def render(self, result: NightResult, colour_profile: ColourProfile = CINEMATIC_PROFILE) -> np.ndarray:
        """Apply final colour science (robust AWB matters a lot at night, where
        mixed/coloured light sources routinely fool naive grey-world balancing)."""
        wb = auto_white_balance(result.image, percentile=85.0)
        return colour_profile.process(result.image, white_balance=wb)


def _architecture(raw_frame):
    from vision_engine.sensor.cfa import SensorArchitecture

    return SensorArchitecture(raw_frame.sensor_params.get("architecture", "bayer"))
