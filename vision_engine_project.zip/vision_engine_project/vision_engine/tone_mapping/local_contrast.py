"""LOCAL CONTRAST stage: a "clarity"-style mid-frequency contrast boost.

Distinct from :mod:`vision_engine.tone_mapping.tone_mapping`'s local
*tone mapping* (which compresses dynamic range while protecting detail),
this stage runs after colour rendering and enhances perceived micro-contrast
in the already-displayable image, the way a "Clarity"/"Structure" slider
does -- an unsharp mask on luminance with a large radius, applied in Lab
space so colour is untouched.
"""
from __future__ import annotations

import cv2
import numpy as np


def apply_local_contrast(rgb: np.ndarray, strength: float = 0.35, radius: int = 24) -> np.ndarray:
    rgb8 = np.clip(rgb * 255.0, 0, 255).astype(np.uint8)
    lab = cv2.cvtColor(rgb8, cv2.COLOR_RGB2LAB).astype(np.float32)
    L = lab[..., 0]

    blurred = cv2.GaussianBlur(L, (0, 0), sigmaX=radius)
    detail = L - blurred
    L_boosted = np.clip(L + strength * detail, 0, 255)

    lab[..., 0] = L_boosted
    out = cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2RGB)
    return out.astype(np.float32) / 255.0


def clahe_luminance(rgb: np.ndarray, clip_limit: float = 2.0, tile_grid: int = 8) -> np.ndarray:
    """Alternative local-contrast operator: CLAHE on the luminance channel."""
    rgb8 = np.clip(rgb * 255.0, 0, 255).astype(np.uint8)
    lab = cv2.cvtColor(rgb8, cv2.COLOR_RGB2LAB)
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(tile_grid, tile_grid))
    lab[..., 0] = clahe.apply(lab[..., 0])
    out = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
    return out.astype(np.float32) / 255.0
