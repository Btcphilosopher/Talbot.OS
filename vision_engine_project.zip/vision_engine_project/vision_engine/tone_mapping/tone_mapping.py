"""HDR dynamic-range compression: extended-range linear RGB -> displayable linear RGB.

This runs *before* :mod:`vision_engine.colour` in the pipeline (a deliberate
reordering from the CORE PIPELINE diagram's nominal COLOUR SCIENCE -> TONE
MAPPING sequence, documented in ``vision_engine/pipeline/pipeline.py``):
the HDR merge stage can produce linear values well above 1.0 for bright
highlights, and colour matrixing / white balance need bounded, sane inputs
to avoid amplifying those extremes into colour artefacts. So dynamic-range
compression happens first, and the COLOUR SCIENCE module's own "tone curve"
step is a much gentler *stylistic* S-curve applied after, on already
tamed data.
"""
from __future__ import annotations

import enum

import cv2
import numpy as np


class ToneMapMethod(str, enum.Enum):
    LINEAR = "linear"
    REINHARD = "reinhard"
    REINHARD_EXTENDED = "reinhard_extended"
    ACES = "aces"
    LOCAL = "local"  # Durand-style bilateral local tone mapping


def _luminance(rgb: np.ndarray) -> np.ndarray:
    return rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722


def reinhard(rgb: np.ndarray, white_point: float | None = None) -> np.ndarray:
    lum = _luminance(rgb)
    if white_point is None:
        white_point = max(float(np.percentile(lum, 99.5)), 1.0)
    lum_out = lum * (1.0 + lum / (white_point ** 2)) / (1.0 + lum)
    scale = np.divide(lum_out, lum, out=np.ones_like(lum), where=lum > 1e-6)
    return rgb * scale[..., None]


def aces_filmic(rgb: np.ndarray) -> np.ndarray:
    """Narkowicz's fitted ACES filmic curve -- a widely used compact HDR->SDR approximation."""
    a, b, c, d, e = 2.51, 0.03, 2.43, 0.59, 0.14
    x = rgb
    out = (x * (a * x + b)) / (x * (c * x + d) + e)
    return np.clip(out, 0.0, 1.0)


def local_tone_map(rgb: np.ndarray, contrast: float = 0.55, detail_boost: float = 1.15) -> np.ndarray:
    """Durand & Dorsey (2002)-style bilateral local tone mapping.

    Splits log-luminance into a large-scale base layer (edge-preserving
    bilateral filter) and a fine detail layer, compresses only the base
    layer's dynamic range, and recombines -- so a scene spanning many stops
    (sunlit sky + shadowed interior) can be brought into display range
    *without* crushing local micro-contrast/texture the way a purely
    global operator would.
    """
    lum = np.clip(_luminance(rgb), 1e-4, None)
    log_lum = np.log10(lum)

    base = cv2.bilateralFilter(log_lum.astype(np.float32), d=0, sigmaColor=0.4, sigmaSpace=max(rgb.shape[0], rgb.shape[1]) * 0.02)
    detail = log_lum - base

    base_range = base.max() - base.min()
    target_range = np.log10(5.0)  # compress base dynamic range down to ~5 stops-equivalent
    compression = target_range / max(base_range, 1e-4)
    compression = min(compression, 1.0) * contrast + (1 - contrast)

    log_out = (base - base.max()) * compression + base.max() * compression + detail * detail_boost
    lum_out = np.power(10.0, log_out)
    scale = np.divide(lum_out, lum, out=np.ones_like(lum), where=lum > 1e-6)
    return rgb * scale[..., None]


def tone_map(rgb: np.ndarray, method: ToneMapMethod | str = ToneMapMethod.LOCAL, **kwargs) -> np.ndarray:
    method = ToneMapMethod(method)
    if method == ToneMapMethod.LINEAR:
        return np.clip(rgb, 0.0, 1.0)
    if method in (ToneMapMethod.REINHARD, ToneMapMethod.REINHARD_EXTENDED):
        return reinhard(rgb, **kwargs)
    if method == ToneMapMethod.ACES:
        return aces_filmic(rgb)
    if method == ToneMapMethod.LOCAL:
        return local_tone_map(rgb, **kwargs)
    raise ValueError(method)
