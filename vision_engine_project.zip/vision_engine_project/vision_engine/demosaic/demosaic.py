"""CFA-aware demosaicing: mosaic -> full-resolution RGB.

Two algorithms are provided:

* :func:`bilinear_demosaic` -- a *generic, pattern-agnostic* normalised
  convolution interpolator. It builds a sparse "known samples" image per
  channel from the actual CFA sample positions (whatever they are -- Bayer,
  Quad-Bayer, RGBW, ...) and divides a smoothed version of it by a smoothed
  coverage mask. This correctly demosaics any tile in :mod:`vision_engine.sensor.cfa`
  without per-pattern-special-casing.
* :func:`malvar_demosaic` -- the higher-quality Malvar-He-Cutler
  gradient-corrected algorithm, implemented for standard 2x2 Bayer tiles
  (used after Quad-Bayer re-mosaicing, see :func:`bin_quad_bayer_to_bayer`).

:func:`demosaic` dispatches by sensor architecture, matching the CORE
PIPELINE's single DEMOSAIC stage while giving each sensor type the
treatment real ISPs give it (e.g. Quad-Bayer pixel-binning in low light for
better SNR, full-resolution remosaic in bright light for detail).
"""
from __future__ import annotations

import cv2
import numpy as np

from vision_engine.sensor.cfa import CFAPattern, SensorArchitecture, R, G, B, W, full_mask


def bilinear_demosaic(mosaic: np.ndarray, pattern: CFAPattern) -> np.ndarray:
    """Pattern-agnostic normalised-convolution demosaic. Returns HxWx3 RGB (W folded into luminance)."""
    h, w = mosaic.shape
    idx = full_mask(pattern, h, w)
    kernel = cv2.getGaussianKernel(5, 1.0)
    kernel = (kernel @ kernel.T).astype(np.float32)

    channels: dict[int, np.ndarray] = {}
    for c in np.unique(idx):
        known = (idx == c).astype(np.float32)
        sparse = mosaic * known
        num = cv2.filter2D(sparse, -1, kernel, borderType=cv2.BORDER_REFLECT)
        den = cv2.filter2D(known, -1, kernel, borderType=cv2.BORDER_REFLECT)
        channels[c] = np.divide(num, den, out=np.zeros_like(num), where=den > 1e-6)

    r = channels.get(R, channels.get(W, np.zeros((h, w), np.float32)))
    g = channels.get(G, r)
    b = channels.get(B, r)
    rgb = np.stack([r, g, b], axis=-1)

    if W in channels:
        rgb = rgbw_fuse(rgb, channels[W])
    return rgb.astype(np.float32)


_MALVAR_G_AT_RB = np.array([
    [0, 0, -1, 0, 0],
    [0, 0, 2, 0, 0],
    [-1, 2, 4, 2, -1],
    [0, 0, 2, 0, 0],
    [0, 0, -1, 0, 0],
], dtype=np.float32) / 8.0

_MALVAR_RB_AT_G_ROWBR = np.array([
    [0, 0, 0.5, 0, 0],
    [0, -1, 0, -1, 0],
    [-1, 4, 5, 4, -1],
    [0, -1, 0, -1, 0],
    [0, 0, 0.5, 0, 0],
], dtype=np.float32) / 8.0

_MALVAR_RB_AT_G_COLBR = _MALVAR_RB_AT_G_ROWBR.T

_MALVAR_RB_AT_BR = np.array([
    [0, 0, -1.5, 0, 0],
    [0, 2, 0, 2, 0],
    [-1.5, 0, 6, 0, -1.5],
    [0, 2, 0, 2, 0],
    [0, 0, -1.5, 0, 0],
], dtype=np.float32) / 8.0


def malvar_demosaic(mosaic: np.ndarray, pattern: CFAPattern) -> np.ndarray:
    """Malvar-He-Cutler gradient-corrected linear demosaic for a 2x2 Bayer tile."""
    if pattern not in (CFAPattern.RGGB, CFAPattern.BGGR, CFAPattern.GRBG, CFAPattern.GBRG):
        raise ValueError("malvar_demosaic only supports 2x2 Bayer patterns")

    h, w = mosaic.shape
    idx = full_mask(pattern, h, w)
    m = mosaic.astype(np.float32)

    conv = lambda k: cv2.filter2D(m, -1, k, borderType=cv2.BORDER_REFLECT)
    g_at_rb = conv(_MALVAR_G_AT_RB)
    rb_at_g_rowbr = conv(_MALVAR_RB_AT_G_ROWBR)
    rb_at_g_colbr = conv(_MALVAR_RB_AT_G_COLBR)
    rb_at_br = conv(_MALVAR_RB_AT_BR)

    r_mask, g_mask, b_mask = idx == R, idx == G, idx == B

    # Start each plane from the raw samples of its own colour, then fill in
    # the missing sites with the appropriate Malvar gradient-corrected estimate.
    R_full = np.where(r_mask, m, 0.0).astype(np.float32)
    G_full = np.where(g_mask, m, 0.0).astype(np.float32)
    B_full = np.where(b_mask, m, 0.0).astype(np.float32)

    R_full[g_mask] = _at_green(idx, rb_at_g_rowbr, rb_at_g_colbr, R)[g_mask]
    B_full[g_mask] = _at_green(idx, rb_at_g_rowbr, rb_at_g_colbr, B)[g_mask]
    R_full[b_mask] = rb_at_br[b_mask]   # R at a B site: diagonal-neighbour estimate
    B_full[r_mask] = rb_at_br[r_mask]   # B at an R site: diagonal-neighbour estimate
    G_full[r_mask] = g_at_rb[r_mask]
    G_full[b_mask] = g_at_rb[b_mask]

    rgb = np.stack([R_full, G_full, B_full], axis=-1)
    return np.clip(rgb, 0.0, None)


def _at_green(idx: np.ndarray, rowbr_result: np.ndarray, colbr_result: np.ndarray, target: int) -> np.ndarray:
    """Pick the row- or column-oriented Malvar kernel result depending on local neighbour orientation.

    At a green site, red is horizontally or vertically adjacent depending on
    which Bayer row we're in; we detect this from whether the pixel to the
    left/right is the target colour and select the matching kernel output.
    """
    h, w = idx.shape
    left = np.roll(idx, 1, axis=1)
    is_horizontal_neighbour = left == target
    return np.where(is_horizontal_neighbour, rowbr_result, colbr_result)


def bin_quad_bayer_to_bayer(mosaic: np.ndarray, pattern: CFAPattern) -> tuple[np.ndarray, CFAPattern]:
    """Average each 2x2 same-colour Quad-Bayer group -> standard half-resolution Bayer mosaic.

    This mirrors what a real Quad-Bayer sensor's on-chip binning mode does
    for normal-light photography: four same-colour photosites are summed
    for improved SNR and a standard-size Bayer frame is handed to the ISP.
    """
    h, w = mosaic.shape
    binned = mosaic.reshape(h // 2, 2, w // 2, 2).mean(axis=(1, 3))
    return binned.astype(np.float32), CFAPattern.RGGB


def rgbw_fuse(rgb: np.ndarray, w_channel: np.ndarray, low_light_boost: float = 1.0) -> np.ndarray:
    """Blend panchromatic W-channel luminance into RGB, most strongly in dark regions.

    The white subpixel gathers ~3x the photons of a colour-filtered one
    (no filter absorption), so next-gen RGBW sensors use it primarily to
    recover luminance detail/SNR in shadows while colour still comes from
    the R/G/B sites.
    """
    luminance_rgb = rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722
    darkness = np.clip(1.0 - luminance_rgb * 4.0, 0.0, 1.0) * low_light_boost
    scale = np.divide(w_channel, luminance_rgb, out=np.ones_like(w_channel), where=luminance_rgb > 1e-4)
    scale = 1.0 + darkness * (np.clip(scale, 0.5, 3.0) - 1.0)
    return rgb * scale[..., None]


def demosaic(raw_frame_or_mosaic, pattern: CFAPattern | None = None, architecture: SensorArchitecture | None = None,
             quality: str = "auto") -> np.ndarray:
    """Dispatch demosaicing by sensor architecture. Accepts either a RawFrame or a raw mosaic + pattern."""
    if hasattr(raw_frame_or_mosaic, "pixels"):
        raw_frame = raw_frame_or_mosaic
        mosaic = raw_frame.normalised()
        pattern = CFAPattern(raw_frame.sensor_params.get("cfa_pattern", "RGGB"))
        architecture = SensorArchitecture(raw_frame.sensor_params.get("architecture", "bayer"))
        iso = raw_frame.iso
    else:
        mosaic = raw_frame_or_mosaic
        pattern = pattern or CFAPattern.RGGB
        architecture = architecture or SensorArchitecture.BAYER
        iso = 100

    if architecture == SensorArchitecture.QUAD_BAYER:
        use_binning = quality == "auto" and iso > 400 or quality == "binned"
        if use_binning:
            binned, bayer_pattern = bin_quad_bayer_to_bayer(mosaic, pattern)
            rgb = malvar_demosaic(binned, bayer_pattern)
            return cv2.resize(rgb, (mosaic.shape[1], mosaic.shape[0]), interpolation=cv2.INTER_LINEAR)
        return bilinear_demosaic(mosaic, pattern)

    if architecture == SensorArchitecture.RGBW:
        return bilinear_demosaic(mosaic, pattern)

    if pattern in (CFAPattern.RGGB, CFAPattern.BGGR, CFAPattern.GRBG, CFAPattern.GBRG):
        return malvar_demosaic(mosaic, pattern)

    return bilinear_demosaic(mosaic, pattern)
