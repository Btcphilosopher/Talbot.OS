"""A small ESPCN-style (Shi et al. 2016) sub-pixel convolution super-resolution
network: a few conv layers at the input resolution, then a pixel-shuffle
upscale -- cheap enough to run on-device, which is the point of doing real
work in feature space before the (expensive) upscale rather than after.

Like :mod:`vision_engine.models.denoise_net`, this is a compact reference
architecture for the research lab, not a production model.
"""
from __future__ import annotations

from vision_engine.utils.optional_deps import HAS_TORCH

if HAS_TORCH:
    import torch
    from torch import nn

    class SuperResNet(nn.Module):
        def __init__(self, channels: int = 3, features: int = 48, scale: int = 2) -> None:
            super().__init__()
            self.scale = scale
            self.body = nn.Sequential(
                nn.Conv2d(channels, features, 5, padding=2), nn.ReLU(inplace=True),
                nn.Conv2d(features, features, 3, padding=1), nn.ReLU(inplace=True),
                nn.Conv2d(features, features // 2, 3, padding=1), nn.ReLU(inplace=True),
                nn.Conv2d(features // 2, channels * (scale ** 2), 3, padding=1),
            )
            self.shuffle = nn.PixelShuffle(scale)

        def forward(self, x: "torch.Tensor") -> "torch.Tensor":
            return self.shuffle(self.body(x))

else:  # pragma: no cover
    SuperResNet = None
