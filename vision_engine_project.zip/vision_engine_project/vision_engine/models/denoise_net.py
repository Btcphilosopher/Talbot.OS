"""A small DnCNN-style residual denoising network.

Deliberately compact (a handful of 3x3 conv layers, 32 channels) so it
trains in seconds on CPU from synthetic sensor-simulator data -- this is a
research-lab reference architecture, not a production model, and is meant
to be swapped for something bigger/pretrained without touching any of the
call sites in :mod:`vision_engine.denoise.neural`.

Residual formulation: the network predicts the *noise*, and the clean
estimate is ``input - predicted_noise``. This is easier to learn than
predicting the clean image directly (the "content" pathway is a no-op skip
connection) and, importantly, makes an *untrained* network a safe no-op
(zero-initialised final layer -> zero predicted noise -> identity output)
rather than actively harmful.
"""
from __future__ import annotations

from vision_engine.utils.optional_deps import HAS_TORCH

if HAS_TORCH:
    import torch
    from torch import nn

    class DenoiseNet(nn.Module):
        def __init__(self, channels: int = 3, features: int = 32, depth: int = 6) -> None:
            super().__init__()
            layers = [nn.Conv2d(channels, features, 3, padding=1), nn.ReLU(inplace=True)]
            for _ in range(depth - 2):
                layers += [
                    nn.Conv2d(features, features, 3, padding=1),
                    nn.BatchNorm2d(features),
                    nn.ReLU(inplace=True),
                ]
            self.body = nn.Sequential(*layers)
            self.out = nn.Conv2d(features, channels, 3, padding=1)
            nn.init.zeros_(self.out.weight)
            nn.init.zeros_(self.out.bias)

        def forward(self, x: "torch.Tensor") -> "torch.Tensor":
            noise = self.out(self.body(x))
            return x - noise

else:  # pragma: no cover - exercised only when torch truly is not installed
    DenoiseNet = None
