"""Motion estimation & motion-aware fusion, shared by the HDR, night and
denoise engines.

Provides:

* Global (camera-shake) and dense (per-pixel) motion estimation.
* Frame alignment (ECC affine registration, sub-pixel phase correlation).
* Motion-mask extraction for ghost-free multi-frame fusion.
* A lightweight moving-object classifier: real semantic detection (person /
  car / animal) needs a trained detector, which is out of scope for a
  synthetic-data research lab -- so this stage does genuine, useful motion
  segmentation (connected-component blob extraction on the residual-motion
  mask) and assigns a plausible *category label* from blob geometry
  (aspect ratio / size / motion coherence heuristics), clearly documented
  as a stand-in for a learned detector (e.g. a distilled YOLO/RT-DETR head)
  that would plug into the same :class:`MotionRegion` interface.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field

import cv2
import numpy as np


class MotionCategory(str, enum.Enum):
    CAMERA_MOVEMENT = "camera_movement"
    PERSON = "person"
    VEHICLE = "vehicle"
    ANIMAL = "animal"
    MOVING_BACKGROUND = "moving_background"
    UNKNOWN_OBJECT = "unknown_object"


@dataclass
class MotionRegion:
    bbox: tuple[int, int, int, int]  # x, y, w, h
    area: int
    category: MotionCategory
    confidence: float
    mean_flow: tuple[float, float]


@dataclass
class MotionAnalysis:
    global_shift: tuple[float, float]
    is_camera_moving: bool
    motion_mask: np.ndarray
    flow: np.ndarray | None
    regions: list[MotionRegion] = field(default_factory=list)


def luminance(frame: np.ndarray) -> np.ndarray:
    if frame.ndim == 3:
        return frame[..., 0] * 0.2126 + frame[..., 1] * 0.7152 + frame[..., 2] * 0.0722
    return frame


def to_gray_u8(frame: np.ndarray, percentile: float = 99.0, ref_value: float | None = None) -> np.ndarray:
    """Convert to an 8-bit grayscale proxy for registration/motion comparison.

    Normalises by a robust high percentile rather than the true max: a
    single frame can carry a handful of far-outlier highlight pixels (a
    clipped sun disc, a light bulb) whose value dividing by the *true* max
    would let rescale the entire frame's comparison range, producing
    spurious full-frame "motion" or a divergent alignment.

    Pass an explicit ``ref_value`` (rather than the default of each frame
    computing its own percentile) when comparing *multiple* frames against
    each other, e.g. across an HDR bracket: how well a highlight recovers
    differs *by design* between exposures (that's the point of bracketing),
    so each frame's own percentile is not the same physical brightness --
    using it as the normalisation denominator reintroduces exactly the
    brightness mismatch radiance-normalisation was meant to remove, making
    otherwise near-identical content appear to disagree. A shared
    ``ref_value`` (computed once, e.g. from the reference frame) keeps every
    frame on the same comparison scale.
    """
    gray = luminance(frame)
    ref = ref_value if ref_value is not None else float(np.percentile(gray, percentile))
    ref = max(ref, 1e-6)
    return np.clip(gray / ref * 255, 0, 255).astype(np.uint8)


def estimate_global_shift(ref: np.ndarray, moving: np.ndarray) -> tuple[float, float]:
    """Sub-pixel global translation via phase correlation."""
    a = np.float32(to_gray_u8(ref))
    b = np.float32(to_gray_u8(moving))
    window = cv2.createHanningWindow(a.shape[::-1], cv2.CV_32F)
    (dx, dy), _response = cv2.phaseCorrelate(a * window, b * window)
    return dx, dy


def _is_plausible_affine(warp: np.ndarray, shape: tuple[int, int], max_shift_frac: float = 0.25) -> bool:
    """Reject ECC solutions that have clearly diverged (degenerate/huge scale or shear,
    or translation far larger than a handheld-burst frame-to-frame shift could plausibly
    be). Low-texture content (e.g. a flat sky) gives ECC almost no gradient signal to
    lock onto, and it can converge to a nonsensical local optimum instead of identity."""
    a = warp[:2, :2]
    tx, ty = warp[0, 2], warp[1, 2]
    h, w = shape[:2]
    if not np.all(np.isfinite(warp)):
        return False
    scale_x, scale_y = np.hypot(a[0, 0], a[1, 0]), np.hypot(a[0, 1], a[1, 1])
    if not (0.85 <= scale_x <= 1.15 and 0.85 <= scale_y <= 1.15):
        return False
    if abs(tx) > max_shift_frac * w or abs(ty) > max_shift_frac * h:
        return False
    return True


def estimate_affine(ref: np.ndarray, moving: np.ndarray, max_iters: int = 80, eps: float = 1e-5,
                     registration_max_dim: int = 320) -> np.ndarray:
    """ECC-based affine registration, with a phase-correlation (translation-only)
    fallback when ECC fails to converge or diverges to an implausible transform --
    common on very low-texture or extremely noisy synthetic frames.

    Registration runs on a downsampled + blurred proxy (coarse-to-fine is
    standard practice in real burst-alignment ISPs): shot noise is
    proportionally worst in underexposed bracket/night frames, and both the
    blur and the reduced resolution suppress its influence on the ECC cost
    surface far more than they hurt accuracy, since true camera/subject
    motion has much lower spatial frequency than per-pixel sensor noise.
    Only the translation terms need rescaling back to full resolution;
    rotation/scale are resolution-invariant.
    """
    h, w = ref.shape[:2]
    scale = min(1.0, registration_max_dim / max(h, w))
    size = (max(8, int(w * scale)), max(8, int(h * scale)))

    def _proxy(frame: np.ndarray) -> np.ndarray:
        g = to_gray_u8(frame).astype(np.float32) / 255.0
        g = cv2.resize(g, size, interpolation=cv2.INTER_AREA)
        return cv2.GaussianBlur(g, (0, 0), 1.1)

    a, b = _proxy(ref), _proxy(moving)
    warp = np.eye(2, 3, dtype=np.float32)
    criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, max_iters, eps)
    try:
        _, warp = cv2.findTransformECC(a, b, warp, cv2.MOTION_AFFINE, criteria, None, 5)
    except cv2.error:
        warp = np.eye(2, 3, dtype=np.float32)

    warp[0, 2] /= scale
    warp[1, 2] /= scale

    if not _is_plausible_affine(warp, ref.shape):
        dx, dy = estimate_global_shift(ref, moving)
        warp = np.array([[1.0, 0.0, dx], [0.0, 1.0, dy]], dtype=np.float32)
    return warp


def warp_affine(frame: np.ndarray, warp: np.ndarray) -> np.ndarray:
    h, w = frame.shape[:2]
    return cv2.warpAffine(frame, warp, (w, h), flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP,
                           borderMode=cv2.BORDER_REFLECT)


def dense_optical_flow(ref: np.ndarray, moving: np.ndarray) -> np.ndarray:
    a, b = to_gray_u8(ref), to_gray_u8(moving)
    flow = cv2.calcOpticalFlowFarneback(a, b, None, 0.5, 3, 21, 3, 5, 1.2, 0)
    return flow


def estimate_warps(frames: list[np.ndarray], reference_idx: int = 0, method: str = "ecc") -> list[np.ndarray]:
    """Estimate the warp of every frame onto ``frames[reference_idx]`` without
    applying it -- lets callers register on one representation (e.g. an
    exposure/brightness-normalised proxy) and then apply the same warps to a
    *different* representation (e.g. the original display-referred frames),
    which matters whenever the frames being aligned are not directly
    comparable in brightness (HDR brackets) or need separate warp reuse.
    """
    ref = frames[reference_idx]
    warps = []
    for i, f in enumerate(frames):
        if i == reference_idx:
            warps.append(np.eye(2, 3, dtype=np.float32))
            continue
        warps.append(estimate_affine(ref, f) if method == "ecc" else np.eye(2, 3, dtype=np.float32))
    return warps


def apply_warps(frames: list[np.ndarray], warps: list[np.ndarray]) -> list[np.ndarray]:
    return [warp_affine(f, w) for f, w in zip(frames, warps)]


def align_frames(frames: list[np.ndarray], reference_idx: int = 0, method: str = "ecc") -> tuple[list[np.ndarray], list[np.ndarray]]:
    """Align every frame in ``frames`` onto ``frames[reference_idx]``.

    Returns (aligned_frames, warps) so callers can also warp any auxiliary
    per-frame data (e.g. confidence maps) consistently.
    """
    warps = estimate_warps(frames, reference_idx, method)
    aligned = apply_warps(frames, warps)
    return aligned, warps


def detect_motion_mask(aligned_frames: list[np.ndarray], reference_idx: int = 0, threshold: float = 0.06,
                        valid_masks: list[np.ndarray] | None = None) -> np.ndarray:
    """Residual-motion mask after alignment: True where content still disagrees
    across frames, i.e. genuine subject motion the global/affine alignment could
    not explain (as opposed to camera shake, which alignment already removed).

    ``valid_masks`` (one boolean array per frame, True = usable signal) lets
    callers exclude pixels that are expected to legitimately disagree for a
    non-motion reason -- most importantly, differently-clipped highlights/
    shadows across an HDR exposure bracket, which otherwise swamp the
    disagreement measure and would flag almost the whole frame as "moving"
    (see :mod:`vision_engine.hdr.hdr_engine`, which supplies clipping-based
    validity masks). Without it every frame contributes everywhere, which is
    correct for equal-exposure bursts (night mode, temporal denoise).
    """
    # Normalise every frame against the *reference frame's* brightness scale
    # (not each frame's own percentile -- see to_gray_u8's docstring): across
    # an HDR bracket, how far a highlight recovers legitimately differs by
    # exposure, and letting each frame set its own scale would reintroduce
    # the very brightness mismatch radiance-normalisation removed.
    shared_ref = float(np.percentile(luminance(aligned_frames[reference_idx]), 99.0))

    def _blurred_gray(frame: np.ndarray) -> np.ndarray:
        g = to_gray_u8(frame, ref_value=shared_ref).astype(np.float32) / 255.0
        # A small blur before differencing suppresses demosaic/shot-noise-level
        # disagreement (worst right at sharp clipping boundaries, where
        # Malvar's gradient-correction kernels can ring differently per
        # exposure) without hiding genuine, spatially-coherent subject motion.
        return cv2.GaussianBlur(g, (0, 0), 1.0)

    ref = aligned_frames[reference_idx]
    ref_gray = _blurred_gray(ref)
    if valid_masks is not None:
        erode_kernel = np.ones((5, 5), np.uint8)
        valid_masks = [cv2.erode(v.astype(np.uint8), erode_kernel).astype(bool) for v in valid_masks]
    ref_valid = valid_masks[reference_idx] if valid_masks is not None else np.ones(ref_gray.shape, dtype=bool)

    disagreement = np.zeros(ref_gray.shape, dtype=np.float32)
    weight = np.zeros(ref_gray.shape, dtype=np.float32)
    for i, f in enumerate(aligned_frames):
        if i == reference_idx:
            continue
        g = _blurred_gray(f)
        pair_valid = ref_valid & (valid_masks[i] if valid_masks is not None else True)
        disagreement += np.abs(g - ref_gray) * pair_valid
        weight += pair_valid
    disagreement = np.divide(disagreement, weight, out=np.zeros_like(disagreement), where=weight > 0)
    disagreement = cv2.medianBlur(disagreement.astype(np.float32), 5)
    mask = disagreement > threshold
    # A pixel with no mutually-valid comparison anywhere (clipped in every
    # frame) has no evidence either way -- treat as "not moving" rather than
    # defaulting True, since merge.py's own highlight/shadow recovery (not
    # this mask) is what handles universally-clipped pixels.
    mask &= weight > 0
    mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    return mask.astype(bool)


def _classify_blob(w: int, h: int, area: int, mean_flow: tuple[float, float], frame_area: int) -> tuple[MotionCategory, float]:
    aspect = h / max(w, 1)
    rel_area = area / max(frame_area, 1)
    speed = float(np.hypot(*mean_flow))
    if rel_area > 0.25:
        return MotionCategory.MOVING_BACKGROUND, 0.55
    if 1.6 <= aspect <= 4.5 and rel_area < 0.12:
        return MotionCategory.PERSON, 0.65
    if aspect <= 0.8 and rel_area > 0.01 and speed > 1.5:
        return MotionCategory.VEHICLE, 0.6
    if 0.8 < aspect < 1.6 and rel_area < 0.06:
        return MotionCategory.ANIMAL, 0.4
    return MotionCategory.UNKNOWN_OBJECT, 0.3


def find_motion_regions(motion_mask: np.ndarray, flow: np.ndarray | None = None, min_area: int = 40) -> list[MotionRegion]:
    num, labels, stats, _centroids = cv2.connectedComponentsWithStats(motion_mask.astype(np.uint8), connectivity=8)
    frame_area = motion_mask.shape[0] * motion_mask.shape[1]
    regions = []
    for label in range(1, num):
        x, y, w, h, area = stats[label]
        if area < min_area:
            continue
        if flow is not None:
            region_mask = labels == label
            mean_flow = (float(flow[..., 0][region_mask].mean()), float(flow[..., 1][region_mask].mean()))
        else:
            mean_flow = (0.0, 0.0)
        category, confidence = _classify_blob(w, h, area, mean_flow, frame_area)
        regions.append(MotionRegion(bbox=(x, y, w, h), area=int(area), category=category, confidence=confidence, mean_flow=mean_flow))
    return regions


def analyse(frames: list[np.ndarray], reference_idx: int = 0, camera_shake_threshold: float = 1.5,
            valid_masks: list[np.ndarray] | None = None, already_aligned: bool = False) -> MotionAnalysis:
    """Full motion analysis: global camera shift, subject-motion mask, and
    coarse per-region motion categorisation, in one call.

    ``valid_masks``: see :func:`detect_motion_mask` -- pass clipping-aware
    masks when comparing frames that are not directly comparable in
    brightness (an HDR bracket). ``already_aligned``: skip the internal ECC
    pass when the caller has already registered these frames itself (e.g.
    on a different, brightness-normalised proxy) and just wants motion/region
    analysis on the result.
    """
    ref = frames[reference_idx]
    other = frames[1 if reference_idx == 0 else 0]
    global_shift = estimate_global_shift(ref, other)
    is_camera_moving = float(np.hypot(*global_shift)) > camera_shake_threshold

    aligned = frames if already_aligned else align_frames(frames, reference_idx, method="ecc")[0]
    motion_mask = detect_motion_mask(aligned, reference_idx, valid_masks=valid_masks)
    flow = dense_optical_flow(ref, aligned[1 if reference_idx == 0 else 0]) if len(frames) > 1 else None
    regions = find_motion_regions(motion_mask, flow)

    return MotionAnalysis(
        global_shift=global_shift,
        is_camera_moving=is_camera_moving,
        motion_mask=motion_mask,
        flow=flow,
        regions=regions,
    )
