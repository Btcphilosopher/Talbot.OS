"""The pipeline's output type: a display-referred linear image plus the
diagnostic trail (profiling, scene classification, exposure plan, ...) that
made it, with `.save()` matching the spec's `image.save("photo.jpg")`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image as PILImage


def srgb_encode(linear: np.ndarray) -> np.ndarray:
    """IEC 61966-2-1 sRGB opto-electronic transfer function: linear-light -> display-encoded."""
    x = np.clip(linear, 0.0, 1.0)
    return np.where(x <= 0.0031308, x * 12.92, 1.055 * np.power(x, 1 / 2.4) - 0.055)


def srgb_decode(encoded: np.ndarray) -> np.ndarray:
    x = np.clip(encoded, 0.0, 1.0)
    return np.where(x <= 0.04045, x / 12.92, np.power((x + 0.055) / 1.055, 2.4))


@dataclass
class ProcessedImage:
    """Linear-light RGB in [0, 1]; call :meth:`to_uint8` / :meth:`save` for
    the sRGB-encoded, display-ready result."""

    rgb: np.ndarray
    profile: Any = None            # vision_engine.utils.profiling.Profile
    scene_classification: Any = None
    exposure_plan: Any = None
    metadata: dict = field(default_factory=dict)

    def to_uint8(self) -> np.ndarray:
        encoded = srgb_encode(np.clip(self.rgb, 0.0, 1.0))
        return np.clip(encoded * 255.0 + 0.5, 0, 255).astype(np.uint8)

    def to_pil(self) -> PILImage.Image:
        return PILImage.fromarray(self.to_uint8(), mode="RGB")

    def save(self, path: str, quality: int = 95) -> None:
        ext = Path(path).suffix.lower()
        img = self.to_pil()
        if ext in (".jpg", ".jpeg"):
            img.save(path, format="JPEG", quality=quality, subsampling=0)
        elif ext == ".png":
            img.save(path, format="PNG")
        elif ext in (".tif", ".tiff"):
            import cv2

            # Pillow's "I;16" mode is single-channel only; cv2 writes 16-bit
            # multi-channel TIFF directly.
            arr16 = np.clip(srgb_encode(np.clip(self.rgb, 0, 1)) * 65535.0, 0, 65535).astype(np.uint16)
            cv2.imwrite(path, cv2.cvtColor(arr16, cv2.COLOR_RGB2BGR))
        else:
            img.save(path)

    def summary(self) -> str:
        lines = [f"ProcessedImage {self.rgb.shape[1]}x{self.rgb.shape[0]}"]
        if self.scene_classification is not None:
            lines.append(f"  scene: {self.scene_classification.category.value} "
                          f"(confidence {self.scene_classification.confidence:.2f})")
        if self.exposure_plan is not None:
            lines.append(f"  exposure: {self.exposure_plan.rationale}")
        if self.profile is not None:
            lines.append(f"  total: {self.profile.total_seconds * 1000:.1f} ms "
                          f"({self.profile.fps:.1f} fps)")
        return "\n".join(lines)
