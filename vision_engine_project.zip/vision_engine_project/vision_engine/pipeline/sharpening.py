"""Final SHARPENING stage: an edge-protected unsharp mask.

Runs last in the CORE PIPELINE, after denoise/local-contrast/super-resolution
have already done the heavy lifting -- so this is deliberately restrained
(small radius, gain clamped, and skipped in already-noisy flat regions) to
add perceptual acutance without re-introducing the noise the denoise stage
just removed or ringing halos around strong edges.
"""
from __future__ import annotations

import cv2
import numpy as np


def unsharp_mask(rgb: np.ndarray, radius: float = 1.2, amount: float = 0.6, threshold: float = 0.015) -> np.ndarray:
    blurred = cv2.GaussianBlur(rgb, (0, 0), radius)
    high_freq = rgb - blurred
    # Only sharpen where the high-frequency energy exceeds a small noise
    # floor -- avoids amplifying residual sensor noise in flat regions.
    mag = np.abs(high_freq).max(axis=-1, keepdims=True)
    gate = np.clip((mag - threshold) / max(threshold, 1e-6), 0.0, 1.0)
    return rgb + high_freq * amount * gate
