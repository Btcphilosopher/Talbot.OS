"""The CORE PIPELINE, end to end:

    RAW FRAME -> BLACK LEVEL/CALIBRATION -> DEFECT CORRECTION -> DENOISING
    -> DEMOSAIC -> COLOUR SCIENCE -> TONE MAPPING -> LOCAL CONTRAST
    -> SUPER RESOLUTION -> SHARPENING -> FINAL IMAGE

Two deliberate reorderings from the diagram, both documented where they
happen and both about the same underlying issue -- operating on well-formed
data before less-robust stages touch it:

* DENOISING runs *after* DEMOSAIC, not before. CFA-aware raw-domain
  denoising is a legitimate real-ISP technique, but it roughly doubles the
  algorithmic surface of :mod:`vision_engine.denoise` for a lab whose
  synthetic noise is already well-modelled at the mosaic level via
  calibration; running the (stronger, better-tested) RGB-domain denoisers
  once, right after demosaic, is the pragmatic choice here.
* TONE MAPPING runs *before* COLOUR SCIENCE, not after -- see
  ``vision_engine/tone_mapping/tone_mapping.py`` for why (colour matrixing
  needs bounded input).

:class:`Pipeline` exposes both the single-RAW-frame entry point from the
spec (``pipeline.process(raw)``) and :meth:`finish_from_rgb`, the shared
tail (denoise -> tone map -> colour -> local contrast -> zoom -> sharpen)
that :mod:`vision_engine.simulator.camera`'s HDR/night/portrait capture
modes reuse after their own engines hand back a merged linear image, so
every capture mode ends up through the same colour/tone pipeline.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from vision_engine.calibration.calibration import CalibrationProfile
from vision_engine.colour.colour_science import CINEMATIC_PROFILE, ColourProfile
from vision_engine.demosaic.demosaic import demosaic
from vision_engine.denoise.engine import DenoiseEngine, DenoiseStrategy
from vision_engine.pipeline.image_result import ProcessedImage
from vision_engine.pipeline.sharpening import unsharp_mask
from vision_engine.tone_mapping.local_contrast import apply_local_contrast
from vision_engine.tone_mapping.tone_mapping import ToneMapMethod, tone_map
from vision_engine.utils.profiling import Profiler


@dataclass
class PipelineConfig:
    colour_profile: ColourProfile = None
    denoise_strategy: DenoiseStrategy = DenoiseStrategy.AUTO
    tone_map_method: ToneMapMethod = ToneMapMethod.LOCAL
    local_contrast_strength: float = 0.35
    sharpening_amount: float = 0.6
    scene_adaptive: bool = True
    zoom: float = 1.0

    def __post_init__(self):
        if self.colour_profile is None:
            self.colour_profile = CINEMATIC_PROFILE


class Pipeline:
    def __init__(self, config: PipelineConfig | None = None, **kwargs) -> None:
        self.config = config or PipelineConfig(**kwargs)
        self._denoiser = DenoiseEngine()

    # -- spec entry point: image = pipeline.process(raw) -----------------
    def process(self, raw_frame, burst: list | None = None) -> ProcessedImage:
        profiler = Profiler()

        with profiler.stage("calibration_defect_correction"):
            cal = CalibrationProfile.from_raw_frame(raw_frame)
            mosaic = cal.apply(raw_frame.pixels)

        with profiler.stage("demosaic"):
            rgb = demosaic(mosaic, pattern=cal.cfa_pattern, architecture=_architecture(raw_frame))

        preset = None
        if self.config.scene_adaptive:
            with profiler.stage("scene_analysis"):
                from vision_engine.scene.scene_classifier import classify
                from vision_engine.tone_mapping.tone_mapping import reinhard

                # Classify on a cheap tone-mapped preview, not the raw linear
                # buffer -- the classifier's reference centroids were built
                # from display-referred scene renders, and raw sensor-linear
                # data (especially HDR-extended range well above 1.0) has
                # very different statistics.
                classification = classify(reinhard(rgb))
                preset = classification.preset
        else:
            classification = None

        return self._finish(rgb, profiler, iso=raw_frame.iso, white_balance=raw_frame.white_balance,
                             preset=preset, scene_classification=classification, burst=burst,
                             raw_frame=raw_frame)

    # -- shared tail, reused by HDR / night / zoom capture modes ---------
    def finish_from_rgb(self, rgb: np.ndarray, iso: int | None = None, white_balance: dict | None = None,
                         already_denoised: bool = False, scene_classification=None, burst: list | None = None,
                         zoom: float | None = None, **extra_metadata) -> ProcessedImage:
        profiler = Profiler()
        preset = scene_classification.preset if (scene_classification and self.config.scene_adaptive) else None
        return self._finish(rgb, profiler, iso=iso, white_balance=white_balance, preset=preset,
                             scene_classification=scene_classification, already_denoised=already_denoised,
                             burst=burst, zoom=zoom, **extra_metadata)

    def _finish(self, rgb: np.ndarray, profiler: Profiler, iso=None, white_balance=None, preset=None,
                scene_classification=None, already_denoised=False, burst=None, raw_frame=None, zoom=None,
                **extra_metadata) -> ProcessedImage:
        cfg = self.config
        zoom = cfg.zoom if zoom is None else zoom

        if not already_denoised:
            with profiler.stage("denoise"):
                strategy = cfg.denoise_strategy
                rgb = self._denoiser.denoise(rgb, strategy=strategy, iso=iso, preserve_detail=True).image

        with profiler.stage("tone_mapping"):
            method = preset.tone_map_method if preset else cfg.tone_map_method
            rgb = tone_map(rgb, method=method)

        with profiler.stage("colour_science"):
            profile = cfg.colour_profile
            if preset:
                profile = ColourProfile(name=profile.name, ccm=profile.ccm, tone_curve=preset.tone_curve,
                                         saturation=preset.saturation, vibrance=preset.vibrance,
                                         white_balance_preset=profile.white_balance_preset)
            rgb = profile.process(rgb, white_balance=white_balance)

        with profiler.stage("local_contrast"):
            strength = preset.local_contrast_strength if preset else cfg.local_contrast_strength
            rgb = apply_local_contrast(np.clip(rgb, 0, 1), strength=strength)

        if zoom and zoom != 1.0:
            with profiler.stage("super_resolution"):
                from vision_engine.super_resolution.zoom_engine import ZoomEngine

                zoom_result = ZoomEngine().compute_zoom(rgb, zoom, burst=burst)
                rgb = zoom_result.image
                extra_metadata["zoom_result"] = zoom_result

        with profiler.stage("sharpening"):
            amount = preset.sharpening_strength if preset else cfg.sharpening_amount
            rgb = unsharp_mask(np.clip(rgb, 0, 1), amount=amount)

        return ProcessedImage(
            rgb=np.clip(rgb, 0.0, 1.0),
            profile=profiler.profile,
            scene_classification=scene_classification,
            metadata={"iso": iso, "raw_frame": raw_frame, **extra_metadata},
        )


def _architecture(raw_frame):
    from vision_engine.sensor.cfa import SensorArchitecture

    return SensorArchitecture(raw_frame.sensor_params.get("architecture", "bayer"))
