"""SMART EXPOSURE: analyses a metering capture and picks ISO / shutter speed
/ exposure bias / HDR bracket plan / burst frame count, prioritising
highlight protection while retaining shadow detail (never blow the sky to
save the foreground, and never crush the foreground to save the sky --
reach for HDR bracketing instead of a compromise single exposure).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class SceneMetering:
    mean_luminance: float
    dynamic_range_stops: float
    highlight_clip_fraction: float
    shadow_clip_fraction: float


@dataclass
class ExposurePlan:
    iso: int
    shutter_speed: float          # seconds
    exposure_bias_ev: float
    use_hdr: bool
    hdr_brackets_ev: list[float]
    use_night_mode: bool
    n_night_frames: int
    metering: SceneMetering = field(default=None)
    rationale: str = ""


def meter_scene(rgb: np.ndarray) -> SceneMetering:
    lum = np.clip(rgb.mean(axis=-1), 1e-4, None)
    mean_luminance = float(np.mean(lum))
    p2, p98 = np.percentile(lum, [2, 98])
    dynamic_range_stops = float(np.log2(max(p98, 1e-4) / max(p2, 1e-4)))
    highlight_clip_fraction = float((lum > 0.98).mean())
    shadow_clip_fraction = float((lum < 0.02).mean())
    return SceneMetering(mean_luminance, dynamic_range_stops, highlight_clip_fraction, shadow_clip_fraction)


# Handheld-shake-safe minimum shutter speed for a ~24mm-equivalent lens (with OIS assist).
_SAFE_MIN_SHUTTER = 1 / 30
_TARGET_MID_GREY = 0.32
# Night mode deliberately does *not* chase daylight mid-grey: a night photo
# that still looks like night (bright point lights standing out of a dark
# frame) is the goal, not a scene relit to look like midday -- so its
# metering target sits well below the daylight one; the NIGHT ENGINE's own
# multi-frame fusion and shadow-lift tone mapping do the rest of the work.
_NIGHT_TARGET_LUMINANCE = 0.10


def recommend_exposure(metering_rgb: np.ndarray, base_iso: int = 50, max_iso: int = 6400,
                        reference_shutter: float = 1 / 120, scene_max_iso: int | None = None,
                        exposure_bias_ev: float = 0.0) -> ExposurePlan:
    metering = meter_scene(metering_rgb)
    iso_ceiling = min(max_iso, scene_max_iso or max_iso)

    required_gain = _TARGET_MID_GREY / max(metering.mean_luminance, 1e-4)
    required_ev = float(np.log2(max(required_gain, 1e-6))) + exposure_bias_ev

    is_low_light = metering.mean_luminance < 0.04

    if is_low_light:
        night_gain = _NIGHT_TARGET_LUMINANCE / max(metering.mean_luminance, 1e-4)
        required_ev = float(np.log2(max(night_gain, 1e-6))) + exposure_bias_ev

        # Prefer gathering more real photons over amplifying too little
        # signal: lengthen the per-frame shutter first (up to a
        # burst-friendly ceiling that still fusable-many-frames without
        # excessive blur), and only reach for ISO once shutter alone can't
        # cover the required gain -- pushing ISO to its ceiling regardless
        # of how much is actually needed just clips a dim scene into
        # blown-out midtones (post-gain signal can exceed the sensor's full
        # well long before the ISO ceiling is reached).
        max_burst_shutter = 1 / 8
        shutter_stops_available = np.log2(max_burst_shutter / reference_shutter)
        if required_ev <= shutter_stops_available:
            shutter = reference_shutter * (2.0 ** required_ev)
            iso = base_iso
        else:
            shutter = max_burst_shutter
            remaining_ev = required_ev - shutter_stops_available
            iso = int(np.clip(base_iso * (2.0 ** remaining_ev), base_iso, iso_ceiling))
        n_frames = int(np.clip(round(8 + (0.04 - metering.mean_luminance) * 150), 6, 12))
        return ExposurePlan(
            iso=int(iso), shutter_speed=float(shutter), exposure_bias_ev=exposure_bias_ev,
            use_hdr=False, hdr_brackets_ev=[], use_night_mode=True, n_night_frames=n_frames,
            metering=metering,
            rationale=f"mean luminance {metering.mean_luminance:.3f} < 0.04 -> low-light: "
                       f"ISO {iso}, {n_frames}-frame night fusion instead of a single long exposure.",
        )

    needs_hdr = metering.dynamic_range_stops > 6.0 or (metering.highlight_clip_fraction > 0.02 and metering.shadow_clip_fraction > 0.02)

    # Prefer the lowest ISO that still reaches a handheld-safe shutter speed;
    # only raise ISO once shutter speed would otherwise dip below that floor
    # (protects sharpness first, since noise is fixable later and motion
    # blur is not).
    iso = base_iso
    shutter = reference_shutter * (2.0 ** required_ev)
    # _SAFE_MIN_SHUTTER (1/30s) is the *longest* exposure time handheld shake
    # tolerates -- a required shutter longer (numerically larger, in seconds)
    # than that means the scene is too dark for base ISO alone, and ISO must
    # rise to bring the required duration back down to something safe. A
    # required shutter *shorter* than this (bright scene) is never a problem.
    if shutter > _SAFE_MIN_SHUTTER:
        stops_short = np.log2(shutter / _SAFE_MIN_SHUTTER)
        iso = int(np.clip(base_iso * (2.0 ** stops_short), base_iso, iso_ceiling))
        shutter = _SAFE_MIN_SHUTTER
    shutter = float(np.clip(shutter, 1 / 8000, _SAFE_MIN_SHUTTER))

    if needs_hdr:
        # Highlight protection takes priority: bias the base exposure down
        # slightly and widen brackets when clipping is severe on both ends.
        spread = 3 if metering.dynamic_range_stops > 9 else 2
        brackets = [-float(spread), 0.0, float(spread)]
        rationale = (f"dynamic range {metering.dynamic_range_stops:.1f} stops "
                     f"(highlights clipped {metering.highlight_clip_fraction:.1%}, "
                     f"shadows clipped {metering.shadow_clip_fraction:.1%}) -> HDR bracket {brackets}.")
        return ExposurePlan(iso=iso, shutter_speed=float(shutter), exposure_bias_ev=exposure_bias_ev,
                             use_hdr=True, hdr_brackets_ev=brackets, use_night_mode=False, n_night_frames=0,
                             metering=metering, rationale=rationale)

    return ExposurePlan(iso=iso, shutter_speed=float(shutter), exposure_bias_ev=exposure_bias_ev,
                         use_hdr=False, hdr_brackets_ev=[], use_night_mode=False, n_night_frames=0,
                         metering=metering,
                         rationale=f"well-exposed, {metering.dynamic_range_stops:.1f} stops range -> single exposure, ISO {iso}.")
