"""Configurable colour pipeline: RAW RGB -> colour matrix -> WB -> CCM -> tone curve -> gamut mapping -> display RGB.

Everything here operates on linear-light float32 RGB arrays with the sensor
native primaries until :func:`apply_colour_matrix` moves them to a working
space, then display-referred beyond :func:`apply_tone_curve`.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field

import numpy as np


class WhiteBalancePreset(str, enum.Enum):
    AUTO = "auto"
    DAYLIGHT = "daylight"
    CLOUDY = "cloudy"
    SHADE = "shade"
    TUNGSTEN = "tungsten"
    FLUORESCENT = "fluorescent"
    CUSTOM = "custom"


# Approximate per-preset colour temperature and R/B channel gains relative to
# green, tuned for a pleasant (not strictly colorimetric) smartphone look.
_WB_PRESETS: dict[WhiteBalancePreset, dict] = {
    WhiteBalancePreset.DAYLIGHT: {"cct_k": 5500, "r_gain": 1.90, "g_gain": 1.00, "b_gain": 1.55},
    WhiteBalancePreset.CLOUDY: {"cct_k": 6500, "r_gain": 2.05, "g_gain": 1.00, "b_gain": 1.40},
    WhiteBalancePreset.SHADE: {"cct_k": 7500, "r_gain": 2.20, "g_gain": 1.00, "b_gain": 1.30},
    WhiteBalancePreset.TUNGSTEN: {"cct_k": 3200, "r_gain": 1.35, "g_gain": 1.00, "b_gain": 2.35},
    WhiteBalancePreset.FLUORESCENT: {"cct_k": 4000, "r_gain": 1.55, "g_gain": 1.00, "b_gain": 2.05},
}

# Sensor-native-RGB -> CIE-ish working RGB colour correction matrix. A single
# "default" CCM approximating a next-gen wide-gamut sensor's response; real
# products ship one per illuminant and interpolate, which CustomColourProfile
# below supports.
DEFAULT_CCM = np.array([
    [1.68, -0.55, -0.13],
    [-0.20, 1.45, -0.25],
    [0.02, -0.55, 1.53],
], dtype=np.float32)


def apply_white_balance(rgb: np.ndarray, gains: dict) -> np.ndarray:
    out = rgb.copy()
    out[..., 0] *= gains.get("r_gain", 1.0)
    out[..., 1] *= gains.get("g_gain", 1.0)
    out[..., 2] *= gains.get("b_gain", 1.0)
    return out


def auto_white_balance(rgb: np.ndarray, percentile: float = 90.0) -> dict:
    """Robust grey-world AWB: average only pixels below a bright-outlier percentile
    (excludes saturated highlights / strongly-coloured light sources that would bias grey-world)."""
    lum = rgb.mean(axis=-1)
    thresh = np.percentile(lum, percentile)
    mask = (lum > 1e-4) & (lum < thresh)
    if not mask.any():
        mask = lum > 1e-4
    means = rgb[mask].mean(axis=0) if mask.any() else rgb.reshape(-1, 3).mean(axis=0)
    means = np.clip(means, 1e-4, None)
    g_ref = means[1]
    return {"r_gain": float(g_ref / means[0]), "g_gain": 1.0, "b_gain": float(g_ref / means[2]), "cct_k": None}


def resolve_white_balance(preset: WhiteBalancePreset, rgb: np.ndarray | None = None, custom: dict | None = None) -> dict:
    if preset == WhiteBalancePreset.AUTO:
        if rgb is None:
            raise ValueError("AUTO white balance requires the rgb array")
        return auto_white_balance(rgb)
    if preset == WhiteBalancePreset.CUSTOM:
        return custom or {"r_gain": 1.0, "g_gain": 1.0, "b_gain": 1.0, "cct_k": 5500}
    return dict(_WB_PRESETS[preset])


def apply_colour_matrix(rgb: np.ndarray, ccm: np.ndarray = DEFAULT_CCM) -> np.ndarray:
    h, w, _ = rgb.shape
    flat = rgb.reshape(-1, 3)
    out = flat @ ccm.T
    return out.reshape(h, w, 3)


def apply_colour_correction(rgb: np.ndarray, saturation: float = 1.08, vibrance: float = 1.0) -> np.ndarray:
    """Global saturation/vibrance adjustment in a luma-preserving way."""
    lum = (rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722)[..., None]
    chroma = rgb - lum
    chroma_mag = np.linalg.norm(chroma, axis=-1, keepdims=True)
    vib_gain = 1.0 + (vibrance - 1.0) * np.exp(-2.0 * chroma_mag)
    return lum + chroma * saturation * vib_gain


class ToneCurveStyle(str, enum.Enum):
    NATURAL = "natural"
    CINEMATIC = "cinematic"
    FLAT = "flat"
    VIVID = "vivid"


def _filmic_curve(x: np.ndarray, shoulder: float, toe: float, contrast: float) -> np.ndarray:
    """A simple, stable filmic-style S-curve (smoothstep-based) with adjustable toe/shoulder/contrast."""
    x = np.clip(x, 0.0, None)
    compressed = x / (x + 1.0)  # Reinhard-style highlight compression -> [0, 1)
    t = np.clip(compressed, 0.0, 1.0)
    s_curve = t * t * (3 - 2 * t)  # smoothstep contrast
    s_curve = t + (s_curve - t) * contrast
    s_curve = np.clip(s_curve, 0.0, 1.0)
    s_curve = s_curve ** (1.0 - 0.15 * toe)
    s_curve = 1.0 - (1.0 - s_curve) ** (1.0 + 0.6 * shoulder)
    return np.clip(s_curve, 0.0, 1.0)


_CURVE_PARAMS = {
    ToneCurveStyle.NATURAL: dict(shoulder=0.35, toe=0.25, contrast=0.15),
    ToneCurveStyle.CINEMATIC: dict(shoulder=0.65, toe=0.45, contrast=0.30),
    ToneCurveStyle.FLAT: dict(shoulder=0.05, toe=0.05, contrast=0.0),
    ToneCurveStyle.VIVID: dict(shoulder=0.5, toe=0.2, contrast=0.5),
}


def apply_tone_curve(rgb: np.ndarray, style: ToneCurveStyle = ToneCurveStyle.CINEMATIC) -> np.ndarray:
    params = _CURVE_PARAMS[style]
    return _filmic_curve(rgb, **params)


def gamut_map(rgb: np.ndarray, target: str = "srgb") -> np.ndarray:
    """Soft-knee out-of-gamut compression: desaturate towards luminance before hard clipping.

    Prevents the harsh, hue-shifting hard clip that highlight-heavy scenes
    (sunsets, neon) would otherwise produce.
    """
    lum = (rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722)[..., None]
    excess = np.clip(rgb - 1.0, 0.0, None).max(axis=-1, keepdims=True)
    desat = np.clip(excess * 2.0, 0.0, 1.0)
    out = rgb * (1 - desat) + lum * desat
    return np.clip(out, 0.0, 1.0)


@dataclass
class ColourProfile:
    """A named, self-contained colour pipeline configuration."""

    name: str
    ccm: np.ndarray = field(default_factory=lambda: DEFAULT_CCM.copy())
    tone_curve: ToneCurveStyle = ToneCurveStyle.CINEMATIC
    saturation: float = 1.08
    vibrance: float = 1.05
    white_balance_preset: WhiteBalancePreset = WhiteBalancePreset.AUTO

    def process(self, raw_rgb: np.ndarray, white_balance: dict | None = None) -> np.ndarray:
        wb = white_balance or resolve_white_balance(self.white_balance_preset, raw_rgb)
        x = apply_white_balance(raw_rgb, wb)
        x = apply_colour_matrix(x, self.ccm)
        x = apply_colour_correction(x, self.saturation, self.vibrance)
        x = apply_tone_curve(x, self.tone_curve)
        x = gamut_map(x)
        return x


#: "Cinematic but natural" default -- gentle filmic roll-off, modest saturation lift.
CINEMATIC_PROFILE = ColourProfile(
    name="cinematic",
    tone_curve=ToneCurveStyle.CINEMATIC,
    saturation=1.10,
    vibrance=1.08,
)

NATURAL_PROFILE = ColourProfile(name="natural", tone_curve=ToneCurveStyle.NATURAL, saturation=1.0, vibrance=1.0)
FLAT_PROFILE = ColourProfile(name="flat_log", tone_curve=ToneCurveStyle.FLAT, saturation=0.95, vibrance=1.0)
VIVID_PROFILE = ColourProfile(name="vivid", tone_curve=ToneCurveStyle.VIVID, saturation=1.35, vibrance=1.25)

PROFILES = {p.name: p for p in (CINEMATIC_PROFILE, NATURAL_PROFILE, FLAT_PROFILE, VIVID_PROFILE)}
