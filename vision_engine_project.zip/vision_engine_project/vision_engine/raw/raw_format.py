"""VRAW: the engine's internal RAW image representation.

:class:`RawFrame` bundles the mosaic pixel data together with every piece
of metadata a real camera RAW (DNG-like) container carries: exposure,
ISO, white balance, sensor parameters, lens information, timestamp and
calibration data. It can be serialised to a compact ``.vraw`` container
(a zip of the pixel array + a JSON metadata sidecar) and converted to
interchange formats (DNG/TIFF/PNG/JPEG) via :mod:`vision_engine.raw.converters`.
"""
from __future__ import annotations

import io
import json
import time
import zipfile
from dataclasses import dataclass, field, asdict
from typing import Any

import numpy as np

VRAW_MAGIC = "VRAW1"


@dataclass
class RawFrame:
    pixels: np.ndarray                       # 2D mosaic, dtype uint16/uint32, ADU values
    exposure: float                          # seconds
    iso: int
    white_balance: dict[str, Any] = field(default_factory=dict)
    sensor_params: dict[str, Any] = field(default_factory=dict)
    lens_info: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    calibration_data: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    # -- convenience accessors --------------------------------------
    @property
    def shape(self) -> tuple[int, int]:
        return self.pixels.shape

    @property
    def bit_depth(self) -> int:
        return int(self.sensor_params.get("bit_depth", 14))

    def normalised(self) -> np.ndarray:
        """Mosaic scaled to float32 [0, 1] using calibration black/white levels."""
        bl = self.calibration_data.get("black_level", 0)
        wl = self.calibration_data.get("white_level", (1 << self.bit_depth) - 1)
        return np.clip((self.pixels.astype(np.float32) - bl) / max(wl - bl, 1), 0.0, None)

    def copy_with(self, **changes) -> "RawFrame":
        data = asdict(self)
        data["pixels"] = self.pixels  # asdict() would try (and fail) to deep-copy ndarray metadata oddly
        data.update(changes)
        return RawFrame(**data)

    # -- internal container (.vraw) ----------------------------------
    def save(self, path: str) -> None:
        meta = {
            "magic": VRAW_MAGIC,
            "exposure": self.exposure,
            "iso": self.iso,
            "white_balance": self.white_balance,
            "sensor_params": self.sensor_params,
            "lens_info": self.lens_info,
            "timestamp": self.timestamp,
            "calibration_data": self.calibration_data,
            "metadata": self.metadata,
            "dtype": str(self.pixels.dtype),
            "shape": list(self.pixels.shape),
        }
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("metadata.json", json.dumps(meta, indent=2, default=str))
            buf = io.BytesIO()
            np.save(buf, self.pixels)
            zf.writestr("pixels.npy", buf.getvalue())

    @classmethod
    def load(cls, path: str) -> "RawFrame":
        with zipfile.ZipFile(path, "r") as zf:
            meta = json.loads(zf.read("metadata.json"))
            pixels = np.load(io.BytesIO(zf.read("pixels.npy")))
        return cls(
            pixels=pixels,
            exposure=meta["exposure"],
            iso=meta["iso"],
            white_balance=meta["white_balance"],
            sensor_params=meta["sensor_params"],
            lens_info=meta["lens_info"],
            timestamp=meta["timestamp"],
            calibration_data=meta["calibration_data"],
            metadata=meta["metadata"],
        )

    # -- interchange format export -----------------------------------
    def to_png(self, path: str, pipeline=None) -> None:
        from vision_engine.raw import converters

        converters.export_processed(self, path, fmt="png", pipeline=pipeline)

    def to_jpeg(self, path: str, pipeline=None, quality: int = 92) -> None:
        from vision_engine.raw import converters

        converters.export_processed(self, path, fmt="jpeg", pipeline=pipeline, quality=quality)

    def to_tiff(self, path: str, pipeline=None, bit_depth: int = 16) -> None:
        from vision_engine.raw import converters

        converters.export_processed(self, path, fmt="tiff", pipeline=pipeline, bit_depth=bit_depth)

    def to_dng(self, path: str) -> None:
        from vision_engine.raw import converters

        converters.export_dng(self, path)
