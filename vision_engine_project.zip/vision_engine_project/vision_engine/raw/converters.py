"""Interchange format export: VRAW -> DNG / TIFF / PNG / JPEG.

``export_processed`` runs the frame through a display pipeline (the full
:class:`vision_engine.pipeline.pipeline.Pipeline` by default, or a
caller-supplied one) to get a display-referred RGB image, then encodes it.

``export_dng`` is intentionally honest about its scope: writing a fully
spec-compliant Adobe DNG (TIFF/EP with the complete set of required tags,
CFA pattern description, colour matrices, opcode lists, ...) is a large
undertaking outside a research lab's needs. We emit a valid TIFF container
carrying the untouched raw mosaic plus the DNG-relevant tags we *do*
support, and clearly flag it as a "simplified DNG" -- a genuine future
extension point rather than a silently-incomplete implementation.
"""
from __future__ import annotations

import json
import struct

import numpy as np
from PIL import Image


def _get_rgb8(raw_frame, pipeline=None) -> np.ndarray:
    if pipeline is None:
        from vision_engine.pipeline.pipeline import Pipeline

        pipeline = Pipeline()
    result = pipeline.process(raw_frame)
    return result.to_uint8()


def export_processed(raw_frame, path: str, fmt: str, pipeline=None, quality: int = 92, bit_depth: int = 16) -> None:
    fmt = fmt.lower()
    if fmt == "tiff" and bit_depth == 16:
        import cv2

        if pipeline is None:
            from vision_engine.pipeline.pipeline import Pipeline

            pipeline = Pipeline()
        result = pipeline.process(raw_frame)
        # sRGB-encode before quantising to 16-bit, matching ProcessedImage.save's TIFF path.
        from vision_engine.pipeline.image_result import srgb_encode

        arr16 = np.clip(srgb_encode(np.clip(result.rgb, 0, 1)) * 65535.0, 0, 65535).astype(np.uint16)
        # Pillow's "I;16" mode is single-channel only; cv2 writes 16-bit multi-channel TIFF directly.
        cv2.imwrite(path, cv2.cvtColor(arr16, cv2.COLOR_RGB2BGR))
        return

    rgb8 = _get_rgb8(raw_frame, pipeline)
    img = Image.fromarray(rgb8, mode="RGB")
    if fmt == "png":
        img.save(path, format="PNG")
    elif fmt in ("jpeg", "jpg"):
        img.save(path, format="JPEG", quality=quality, subsampling=0)
    elif fmt == "tiff":
        img.save(path, format="TIFF")
    else:
        raise ValueError(f"Unsupported export format: {fmt}")


# --- minimal, honestly-scoped "DNG" (TIFF/EP-flavoured) writer -----------

_TAG_NEWSUBFILETYPE = 254
_TAG_IMAGEWIDTH = 256
_TAG_IMAGELENGTH = 257
_TAG_BITSPERSAMPLE = 258
_TAG_COMPRESSION = 259
_TAG_PHOTOMETRIC = 262
_TAG_STRIPOFFSETS = 273
_TAG_SAMPLESPERPIXEL = 277
_TAG_ROWSPERSTRIP = 278
_TAG_STRIPBYTECOUNTS = 279
_TAG_PLANARCONFIG = 284
_TAG_SOFTWARE = 305
_TAG_DNGVERSION = 50706
_TAG_UNIQUECAMERAMODEL = 50708
_TAG_CFAPATTERN2 = 33422
_TAG_ISOSPEED = 34855
_TAG_EXPOSURETIME = 33434
_TAG_BLACKLEVEL = 50714
_TAG_WHITELEVEL = 50717


def export_dng(raw_frame, path: str) -> None:
    """Write a simplified, honestly-labelled DNG-style TIFF/EP container.

    Carries the untouched raw mosaic (CFA photometric interpretation,
    bits-per-sample = sensor bit depth) plus DNGVersion, ISO, exposure,
    black/white level and CFA pattern tags, so any tool that reads generic
    TIFF/EP raw tags can recover the same data this library recovers.
    A production DNG writer would additionally emit the full colour
    calibration IFD, opcode lists and per-illuminant matrices -- flagged
    here as a documented extension point rather than silently omitted.
    """
    pixels = raw_frame.pixels
    h, w = pixels.shape
    bit_depth = raw_frame.bit_depth
    dtype = np.uint16 if bit_depth <= 16 else np.uint32
    data = pixels.astype(dtype)

    extra = {
        "black_level": raw_frame.calibration_data.get("black_level", 0),
        "white_level": raw_frame.calibration_data.get("white_level", (1 << bit_depth) - 1),
        "cfa_pattern": raw_frame.sensor_params.get("cfa_pattern", "RGGB"),
        "iso": raw_frame.iso,
        "exposure": raw_frame.exposure,
        "sensor_params": raw_frame.sensor_params,
        "lens_info": raw_frame.lens_info,
        "white_balance": raw_frame.white_balance,
        "vision_engine_dng_profile": "simplified-v1",
    }

    _write_tiff_ep_raw(path, data, bit_depth, extra)


def _write_tiff_ep_raw(path: str, data: np.ndarray, bit_depth: int, extra: dict) -> None:
    h, w = data.shape
    bytes_per_sample = 2 if bit_depth <= 16 else 4
    raw_bytes = data.tobytes()

    # A single-strip, single-IFD little-endian TIFF with an ASCII "metadata"
    # tag holding the full JSON sidecar -- keeps the file self-describing
    # without requiring a private-tag TIFF/EP spec reader to recover it.
    meta_json = json.dumps(extra).encode("utf-8") + b"\x00"

    with open(path, "wb") as f:
        f.write(b"II*\x00")
        ifd_offset_pos = f.tell()
        f.write(struct.pack("<I", 0))  # placeholder for first IFD offset

        data_offset = f.tell()
        f.write(raw_bytes)
        meta_offset = f.tell()
        f.write(meta_json)

        ifd_offset = f.tell()

        entries = [
            (_TAG_NEWSUBFILETYPE, "L", 1, 1),
            (_TAG_IMAGEWIDTH, "L", 1, w),
            (_TAG_IMAGELENGTH, "L", 1, h),
            (_TAG_BITSPERSAMPLE, "S", 1, bit_depth),
            (_TAG_COMPRESSION, "S", 1, 1),
            (_TAG_PHOTOMETRIC, "S", 1, 32803),  # 32803 = CFA (TIFF/EP)
            (_TAG_STRIPOFFSETS, "L", 1, data_offset),
            (_TAG_SAMPLESPERPIXEL, "S", 1, 1),
            (_TAG_ROWSPERSTRIP, "L", 1, h),
            (_TAG_STRIPBYTECOUNTS, "L", 1, len(raw_bytes)),
            (_TAG_PLANARCONFIG, "S", 1, 1),
            (_TAG_ISOSPEED, "L", 1, int(extra.get("iso", 100))),
            (_TAG_BLACKLEVEL, "L", 1, int(extra.get("black_level", 0))),
            (_TAG_WHITELEVEL, "L", 1, int(extra.get("white_level", (1 << bit_depth) - 1))),
        ]
        # ASCII software + metadata tags reference the JSON blob we already wrote.
        ascii_entries = [
            (_TAG_SOFTWARE, meta_offset, len(meta_json)),
        ]

        type_codes = {"S": 3, "L": 4}
        # TIFF requires IFD entries sorted by tag, numeric/ASCII interleaved together.
        all_tags = [(tag, "num", typ, count, value) for tag, typ, count, value in entries]
        all_tags += [(tag, "ascii", None, length, offset) for tag, offset, length in ascii_entries]
        all_tags.sort(key=lambda e: e[0])

        f.write(struct.pack("<H", len(all_tags)))
        for tag, kind, typ, count, value in all_tags:
            if kind == "num":
                tcode = type_codes[typ]
                packed_value = struct.pack("<HH", value, 0) if typ == "S" else struct.pack("<I", value)
                f.write(struct.pack("<HHI", tag, tcode, count) + packed_value)
            else:  # ascii: value=offset, count=length
                f.write(struct.pack("<HHII", tag, 2, count, value))
        f.write(struct.pack("<I", 0))  # next IFD offset (none)

        end = f.tell()
        f.seek(ifd_offset_pos)
        f.write(struct.pack("<I", ifd_offset))
        f.seek(end)
