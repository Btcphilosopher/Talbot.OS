"""COMPUTATIONAL ZOOM ENGINE.

Combines sensor crop, digital interpolation, multi-frame super-resolution
and AI-assisted reconstruction behind one ``compute_zoom`` call, and -- the
spec's explicit requirement -- keeps track of how much of the output at
each zoom tier is *genuinely captured* information versus *interpolated*
or *generated*, exposed as ``ZoomResult.provenance`` (a 0..1 "captured
information fraction" plus a matching per-tier label) rather than quietly
blending the two together.

Tiers (matching the spec's worked example):

============  ================================  ==============================================
zoom          technique                          information source
============  ================================  ==============================================
1x            full sensor frame                  100% captured
1x - 2x       sensor crop (+ mild resize)         100% captured, reframed
2x - 3x       digital zoom (Lanczos resample)     100% captured, interpolated to output size
3x - 5x       computational (edge-directed +      100% captured; local-contrast/sharpening make
              local-contrast enhancement)         better *use* of it, still no new information
5x - 10x      multi-frame super-resolution        mostly captured -- sub-pixel shifts across a
                                                   burst genuinely add resolved detail beyond any
                                                   single frame, via shift-and-add accumulation
>=10x         AI-assisted reconstruction          partially generated -- a learned upsampler
                                                   plausibly hallucinates detail beyond what the
                                                   multi-frame result actually resolved
============  ================================  ==============================================
"""
from __future__ import annotations

import enum
from dataclasses import dataclass

import cv2
import numpy as np

from vision_engine.motion.motion_engine import estimate_global_shift


class ZoomTier(str, enum.Enum):
    SENSOR_CROP = "sensor_crop"
    DIGITAL = "digital"
    COMPUTATIONAL = "computational"
    MULTI_FRAME_SR = "multi_frame_sr"
    AI_RECONSTRUCTION = "ai_reconstruction"


@dataclass
class ZoomResult:
    image: np.ndarray
    zoom_factor: float
    tier: ZoomTier
    captured_information_fraction: float  # 1.0 = every output pixel traces to real photons
    notes: str


def _center_crop(image: np.ndarray, crop_factor: float) -> np.ndarray:
    h, w = image.shape[:2]
    ch, cw = int(h / crop_factor), int(w / crop_factor)
    y0, x0 = (h - ch) // 2, (w - cw) // 2
    return image[y0:y0 + ch, x0:x0 + cw]


def sensor_crop_zoom(image: np.ndarray, zoom_factor: float, output_size: tuple[int, int] | None = None) -> np.ndarray:
    """1x-2x: pure optical-equivalent crop, resized back up only enough to
    fill the requested output frame -- every output pixel is a real sample."""
    cropped = _center_crop(image, zoom_factor)
    if output_size is None:
        return cropped
    return cv2.resize(cropped, output_size, interpolation=cv2.INTER_LINEAR)


def digital_zoom(image: np.ndarray, zoom_factor: float, output_size: tuple[int, int]) -> np.ndarray:
    """2x-3x: crop further and Lanczos-resample up to the output size."""
    cropped = _center_crop(image, zoom_factor)
    return cv2.resize(cropped, output_size, interpolation=cv2.INTER_LANCZOS4)


def computational_zoom(image: np.ndarray, zoom_factor: float, output_size: tuple[int, int]) -> np.ndarray:
    """3x-5x: digital zoom followed by edge-directed local-contrast
    enhancement -- makes better perceptual use of the captured samples
    (sharper apparent detail) without inventing new spatial information."""
    from vision_engine.tone_mapping.local_contrast import apply_local_contrast

    base = digital_zoom(image, zoom_factor, output_size)
    return apply_local_contrast(np.clip(base, 0, 1), strength=0.5, radius=12)


def multi_frame_super_resolve(frames: list[np.ndarray], scale: int, reference_idx: int = 0) -> np.ndarray:
    """5x-8x: shift-and-add multi-frame super-resolution.

    Estimates each frame's *sub-pixel* global shift relative to the
    reference, then splats every frame onto a ``scale``x finer output grid
    at its true (fractional) offset and normalises by coverage. Because a
    handheld burst's frame-to-frame shifts are essentially never exact
    integer multiples of the sensor pitch, different frames sample
    different sub-pixel phases of the scene -- accumulating them genuinely
    resolves detail no single frame captured (the classic multi-image SR
    result), rather than just upscaling one frame.
    """
    h, w = frames[reference_idx].shape[:2]
    out_h, out_w = h * scale, w * scale
    channels = frames[0].shape[-1] if frames[0].ndim == 3 else 1

    accum = np.zeros((out_h, out_w, channels), dtype=np.float32)
    weight = np.zeros((out_h, out_w, 1), dtype=np.float32)
    ref = frames[reference_idx]

    kernel_radius = max(1, scale // 2)
    yy, xx = np.mgrid[-kernel_radius:kernel_radius + 1, -kernel_radius:kernel_radius + 1]
    splat_kernel = np.exp(-(xx ** 2 + yy ** 2) / (2 * (scale * 0.5) ** 2)).astype(np.float32)

    for f in frames:
        dx, dy = estimate_global_shift(ref, f) if f is not ref else (0.0, 0.0)
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        # Target position on the fine grid for every source pixel, at its true sub-pixel offset.
        ty = (gy - dy) * scale
        tx = (gx - dx) * scale
        ty_i = np.round(ty).astype(int)
        tx_i = np.round(tx).astype(int)
        valid = (ty_i >= 0) & (ty_i < out_h) & (tx_i >= 0) & (tx_i < out_w)
        for ky in range(-kernel_radius, kernel_radius + 1):
            for kx in range(-kernel_radius, kernel_radius + 1):
                wgt = splat_kernel[ky + kernel_radius, kx + kernel_radius]
                yidx = ty_i + ky
                xidx = tx_i + kx
                m = valid & (yidx >= 0) & (yidx < out_h) & (xidx >= 0) & (xidx < out_w)
                ys, xs = yidx[m], xidx[m]
                np.add.at(accum, (ys, xs), f[m] * wgt)
                np.add.at(weight, (ys, xs), wgt)

    result = accum / np.clip(weight, 1e-4, None)
    # Fill any still-uncovered fine-grid holes via simple resize fallback.
    hole = (weight[..., 0] < 1e-3)
    if hole.any():
        fallback = cv2.resize(ref, (out_w, out_h), interpolation=cv2.INTER_CUBIC)
        result[hole] = fallback[hole]
    return result.astype(np.float32)


def ai_reconstruct(image: np.ndarray, scale: int, checkpoint_path=None) -> np.ndarray:
    """>8x: neural upsampling -- may plausibly invent texture/edges beyond
    what any capture actually resolved. Falls back to Lanczos resampling
    (clearly the least "inventive" option) if torch isn't available."""
    from vision_engine.utils.optional_deps import HAS_TORCH

    if not HAS_TORCH:
        h, w = image.shape[:2]
        return cv2.resize(image, (w * scale, h * scale), interpolation=cv2.INTER_LANCZOS4)

    import torch

    from vision_engine.models.sr_net import SuperResNet

    model = SuperResNet(scale=scale if scale in (2, 3, 4) else 2)
    default_ckpt = __import__("pathlib").Path(__file__).resolve().parents[2] / "assets" / "models" / "sr_net.pt"
    ckpt = checkpoint_path or default_ckpt
    if ckpt and __import__("pathlib").Path(ckpt).exists() and model.scale == 2:
        model.load_state_dict(torch.load(ckpt, map_location="cpu"))
    model.eval()

    x = torch.from_numpy(np.clip(image, 0, None).transpose(2, 0, 1)).unsqueeze(0).float()
    with torch.no_grad():
        if model.scale != scale:
            # compose repeated 2x passes / a final resize to reach an arbitrary requested scale
            out = model(x)
            cur_scale = model.scale
            while cur_scale < scale:
                out = model(out)
                cur_scale *= model.scale
            out_np = out.squeeze(0).permute(1, 2, 0).numpy()
            h, w = image.shape[:2]
            return cv2.resize(out_np, (w * scale, h * scale), interpolation=cv2.INTER_CUBIC)
        out = model(x)
    return out.squeeze(0).permute(1, 2, 0).numpy()


_TIER_CAPTURE_FRACTION = {
    ZoomTier.SENSOR_CROP: 1.0,
    ZoomTier.DIGITAL: 1.0,
    ZoomTier.COMPUTATIONAL: 0.95,
    ZoomTier.MULTI_FRAME_SR: 0.8,
    ZoomTier.AI_RECONSTRUCTION: 0.35,
}


class ZoomEngine:
    """Computational zoom orchestrator: picks a tier by zoom factor and runs it."""

    def compute_zoom(self, image: np.ndarray, zoom_factor: float, burst: list[np.ndarray] | None = None,
                      output_size: tuple[int, int] | None = None) -> ZoomResult:
        h, w = image.shape[:2]
        output_size = output_size or (w, h)

        if zoom_factor <= 2.0:
            tier = ZoomTier.SENSOR_CROP
            out = sensor_crop_zoom(image, max(zoom_factor, 1.0), output_size)
            notes = "Pure sensor crop; every output pixel is a directly captured sample."
        elif zoom_factor <= 3.0:
            tier = ZoomTier.DIGITAL
            out = digital_zoom(image, zoom_factor, output_size)
            notes = "Lanczos-resampled crop; no new spatial information added."
        elif zoom_factor < 5.0:
            tier = ZoomTier.COMPUTATIONAL
            out = computational_zoom(image, zoom_factor, output_size)
            notes = "Digital zoom plus edge-aware local-contrast enhancement."
        elif zoom_factor < 10.0 and burst:
            tier = ZoomTier.MULTI_FRAME_SR
            scale = max(2, round(zoom_factor / 3))
            sr = multi_frame_super_resolve(burst, scale)
            out = cv2.resize(sr, output_size, interpolation=cv2.INTER_CUBIC)
            notes = f"Shift-and-add multi-frame super-resolution from {len(burst)} captures ({scale}x native SR grid)."
        else:
            tier = ZoomTier.AI_RECONSTRUCTION
            base = multi_frame_super_resolve(burst, 2) if burst and len(burst) > 1 else image
            reconstructed = ai_reconstruct(np.clip(base, 0, 1), scale=2)
            out = cv2.resize(reconstructed, output_size, interpolation=cv2.INTER_CUBIC)
            notes = "AI-assisted reconstruction: a learned upsampler extrapolates detail beyond what any capture resolved."

        return ZoomResult(
            image=np.clip(out, 0.0, None).astype(np.float32),
            zoom_factor=zoom_factor,
            tier=tier,
            captured_information_fraction=_TIER_CAPTURE_FRACTION[tier],
            notes=notes,
        )
