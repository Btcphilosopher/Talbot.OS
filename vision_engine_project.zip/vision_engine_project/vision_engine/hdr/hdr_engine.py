"""HDR ENGINE: multi-frame bracket capture -> aligned, motion-aware merge -> HDR RAW.

Implements the spec's HDR flow end to end:

    RAW FRAME -2 EV, 0 EV, +2 EV -> align -> intelligent merge
    (moving objects / ghosting / highlight recovery / shadow recovery / motion detection)
    -> high-dynamic-range RAW representation
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from vision_engine.calibration.calibration import CalibrationProfile
from vision_engine.demosaic.demosaic import demosaic
from vision_engine.hdr.merge import merge_exposures, normalise_to_radiance, recover_highlights, recover_shadows
from vision_engine.motion.motion_engine import analyse as analyse_motion
from vision_engine.motion.motion_engine import apply_warps, estimate_warps


@dataclass
class HDRResult:
    merged_radiance: np.ndarray          # extended-range linear RGB (values may exceed 1.0)
    per_frame_rgb: list[np.ndarray]
    evs: list[float]
    motion_mask: np.ndarray
    regions: list
    global_shifts: list[tuple[float, float]]
    reference_idx: int
    raw_frames: list = field(default_factory=list)


class HDREngine:
    """Aligns and merges an exposure bracket into a single HDR radiance map."""

    def __init__(self, reference_bracket: int = 1) -> None:
        self.reference_bracket = reference_bracket  # index of the "0 EV" frame within the bracket

    def merge_bracket(self, raw_frames: list, evs: list[float]) -> HDRResult:
        demosaiced = []
        for rf in raw_frames:
            cal = CalibrationProfile.from_raw_frame(rf)
            mosaic = cal.apply(rf.pixels)
            rgb = demosaic(mosaic, pattern=cal.cfa_pattern, architecture=_architecture(rf))
            demosaiced.append(np.clip(rgb, 0.0, 4.0))  # allow modest headroom above 1.0 pre-merge

        # Register on a common-brightness *radiance* proxy -- comparing brackets'
        # raw display-referred brightness directly would make every pixel look
        # like it "moved" simply because the exposures differ (see hdr_engine
        # module docstring / PERFORMANCE.md notes on this pitfall).
        radiance_proxies = [normalise_to_radiance(f, ev) for f, ev in zip(demosaiced, evs)]
        warps = estimate_warps(radiance_proxies, reference_idx=self.reference_bracket, method="ecc")
        aligned = apply_warps(demosaiced, warps)
        aligned_radiance = apply_warps(radiance_proxies, warps)

        # A pixel clipped near black or white in its *own* (display-referred,
        # not radiance-normalised) exposure carries no reliable information --
        # comparing it against another bracket frame there would flag ordinary
        # highlight/shadow clipping as "subject motion". Checked per-channel
        # (max/min across R,G,B), not on the channel *average*: a saturated
        # warm highlight can clip red alone while green/blue are still well
        # below white, and averaging would hide that clipping entirely.
        # Exclude those pixels from the ghost-detection comparison entirely
        # (merge.py's own highlight/shadow recovery handles them separately).
        valid_masks = [((f.min(axis=-1) > 0.02) & (f.max(axis=-1) < 0.98)) for f in aligned]

        motion = analyse_motion(aligned_radiance, reference_idx=self.reference_bracket,
                                 valid_masks=valid_masks, already_aligned=True)

        merged = merge_exposures(aligned, evs, motion_mask=motion.motion_mask, reference_idx=self.reference_bracket)

        lowest_ev_i = int(np.argmin(evs))
        highest_ev_i = int(np.argmax(evs))
        lowest_ev_radiance = aligned[lowest_ev_i] / (2.0 ** evs[lowest_ev_i])
        highest_ev_radiance = aligned[highest_ev_i] / (2.0 ** evs[highest_ev_i])
        merged = recover_highlights(merged, aligned[lowest_ev_i], lowest_ev_radiance)
        merged = recover_shadows(merged, aligned[highest_ev_i], highest_ev_radiance)

        return HDRResult(
            merged_radiance=merged,
            per_frame_rgb=aligned,
            evs=evs,
            motion_mask=motion.motion_mask,
            regions=motion.regions,
            global_shifts=[motion.global_shift],
            reference_idx=self.reference_bracket,
            raw_frames=raw_frames,
        )


def _architecture(raw_frame):
    from vision_engine.sensor.cfa import SensorArchitecture

    return SensorArchitecture(raw_frame.sensor_params.get("architecture", "bayer"))
