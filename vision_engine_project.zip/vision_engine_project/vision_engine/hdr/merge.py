"""Exposure-weighted, motion-aware multi-frame HDR merge.

Frames are expected already colour/exposure-normalised to a common linear
radiance scale (see :func:`normalise_to_radiance`) and spatially aligned
(see :mod:`vision_engine.motion`). Merging uses a Debevec/Mertens-style
"well-exposedness" weight -- each frame contributes most where *it* is best
exposed (mid-tones), and is down-weighted near its own clipped
highlights/crushed shadows -- combined with a hard override in
motion-affected regions so ghosting cannot occur: there, only the single
frame nearest the reference exposure contributes.
"""
from __future__ import annotations

import numpy as np


def normalise_to_radiance(rgb: np.ndarray, ev: float) -> np.ndarray:
    """Undo a frame's relative exposure so all bracket frames sit on one linear radiance scale."""
    return rgb / (2.0 ** ev)


def well_exposedness_weight(rgb01: np.ndarray, sigma: float = 0.22) -> np.ndarray:
    """Hat-shaped confidence weight: ~1 at mid-grey, ~0 near black/white clipping."""
    lum = np.clip(rgb01.mean(axis=-1), 0.0, 1.0)
    w = np.exp(-((lum - 0.5) ** 2) / (2 * sigma ** 2))
    # Hard-zero true clipping so a saturated pixel never contributes fake highlight detail,
    # and true black never contributes fake shadow detail.
    w = np.where(lum > 0.995, 0.0, w)
    w = np.where(lum < 0.004, 0.0, w)
    return w


def merge_exposures(
    frames_display: list[np.ndarray],
    evs: list[float],
    motion_mask: np.ndarray | None = None,
    reference_idx: int = 0,
) -> np.ndarray:
    """Merge aligned exposure-bracketed frames into one extended-range linear image.

    Parameters
    ----------
    frames_display: the *original-exposure* (not radiance-normalised) linear
        RGB frames in ~[0, 1], used only to compute well-exposedness weights.
    evs: exposure values (stops) relative to the reference frame, matching
        ``frames_display`` order.
    motion_mask: True where multi-frame content disagrees after alignment
        (i.e. real subject motion) -- there we fall back to the single
        reference-exposure frame instead of blending, to guarantee no ghosts.
    """
    radiance_frames = [normalise_to_radiance(f, ev) for f, ev in zip(frames_display, evs)]
    weights = [well_exposedness_weight(f) for f in frames_display]

    weight_stack = np.stack(weights, axis=0)  # (N, H, W)
    weight_sum = weight_stack.sum(axis=0, keepdims=True)
    weight_sum = np.where(weight_sum < 1e-6, 1.0, weight_sum)
    norm_weights = weight_stack / weight_sum

    merged = np.zeros_like(radiance_frames[0])
    for w, rf in zip(norm_weights, radiance_frames):
        merged += w[..., None] * rf

    if motion_mask is not None and motion_mask.any():
        reference_radiance = radiance_frames[reference_idx]
        merged = np.where(motion_mask[..., None], reference_radiance, merged)

    return merged.astype(np.float32)


def recover_highlights(merged: np.ndarray, clipped_frame: np.ndarray, lowest_ev_radiance: np.ndarray, threshold: float = 0.97) -> np.ndarray:
    """Where the merge result is still clipped (every bracket saturated there too),
    fall back as far as possible to the lowest-EV (darkest, least likely to clip) frame."""
    clipped = clipped_frame.mean(axis=-1) > threshold
    out = merged.copy()
    out[clipped] = lowest_ev_radiance[clipped]
    return out


def recover_shadows(merged: np.ndarray, dark_frame: np.ndarray, highest_ev_radiance: np.ndarray, threshold: float = 0.01) -> np.ndarray:
    """Where the merge result is still crushed black, fall back to the highest-EV
    (brightest, most shadow detail) frame's radiance estimate."""
    crushed = dark_frame.mean(axis=-1) < threshold
    out = merged.copy()
    out[crushed] = highest_ev_radiance[crushed]
    return out
