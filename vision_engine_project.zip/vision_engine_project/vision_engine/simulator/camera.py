"""The top-level camera API from the spec:

    camera = Sensor(width=8192, height=6144, bit_depth=14)
    raw = camera.capture(exposure=1/120, iso=400)
    image = pipeline.process(raw)
    image.save("photo.jpg")

    result = camera.capture_hdr()
    result = camera.capture_night()
    result = camera.capture_portrait()
    result = camera.computational_zoom(5.0)

:class:`Camera` *is* a :class:`~vision_engine.sensor.sensor.Sensor` (same
constructor, same ``capture``/``capture_burst``) plus every computational
photography engine wired up behind it and a bundled default
:class:`~vision_engine.pipeline.pipeline.Pipeline`, so ``camera.capture(...)``
alone reproduces the bare sensor example, while the ``capture_*`` methods
below are the "one call does the whole mode" convenience layer.
"""
from __future__ import annotations

import numpy as np

from vision_engine.calibration.calibration import CalibrationProfile
from vision_engine.demosaic.demosaic import demosaic
from vision_engine.hdr.hdr_engine import HDREngine
from vision_engine.night.night_engine import NightEngine
from vision_engine.pipeline.image_result import ProcessedImage
from vision_engine.pipeline.pipeline import Pipeline, PipelineConfig
from vision_engine.pipeline.smart_exposure import recommend_exposure
from vision_engine.portrait.portrait_engine import PortraitEngine
from vision_engine.scene.scene_classifier import classify as classify_scene
from vision_engine.tone_mapping.tone_mapping import reinhard as _reinhard_preview
from vision_engine.sensor.cfa import SensorArchitecture
from vision_engine.sensor.sensor import Sensor, SensorConfig


class Camera(Sensor):
    """A next-gen smartphone camera: sensor + full computational photography stack."""

    def __init__(self, config: SensorConfig | None = None, pipeline: Pipeline | None = None, **kwargs) -> None:
        super().__init__(config, **kwargs)
        self.pipeline = pipeline or Pipeline(PipelineConfig())
        self.hdr_engine = HDREngine()
        self.night_engine = NightEngine()
        self.portrait_engine = PortraitEngine()

    # -- SMART EXPOSURE: meter, then decide iso/shutter/HDR/night plan ----
    def auto_expose(self, scene_radiance: np.ndarray | None = None, exposure_bias_ev: float = 0.0):
        meter_raw = self.capture(exposure=1 / 120, iso=self.config.base_iso, scene_radiance=scene_radiance)
        meter_rgb = self._demosaic_raw(meter_raw)
        return recommend_exposure(meter_rgb, base_iso=self.config.base_iso, max_iso=self.config.max_iso,
                                   exposure_bias_ev=exposure_bias_ev)

    def _demosaic_raw(self, raw_frame) -> np.ndarray:
        cal = CalibrationProfile.from_raw_frame(raw_frame)
        mosaic = cal.apply(raw_frame.pixels)
        return demosaic(mosaic, pattern=cal.cfa_pattern, architecture=SensorArchitecture(raw_frame.sensor_params["architecture"]))

    # -- HDR ---------------------------------------------------------------
    def capture_hdr(self, scene_radiance: np.ndarray | None = None, exposure: float | None = None,
                     iso: int | None = None, brackets_ev: tuple[float, ...] = (-2.0, 0.0, 2.0),
                     auto_expose: bool = True, zoom: float = 1.0) -> ProcessedImage:
        if auto_expose and (exposure is None or iso is None):
            plan = self.auto_expose(scene_radiance)
            exposure = exposure or plan.shutter_speed
            iso = iso or plan.iso
            if plan.use_hdr:
                brackets_ev = tuple(plan.hdr_brackets_ev) or brackets_ev
        exposure = exposure or 1 / 120
        iso = iso or self.config.base_iso

        raw_frames = [self.capture(exposure=exposure * (2.0 ** ev), iso=iso, scene_radiance=scene_radiance)
                      for ev in brackets_ev]
        reference_idx = len(brackets_ev) // 2
        self.hdr_engine.reference_bracket = reference_idx
        result = self.hdr_engine.merge_bracket(raw_frames, list(brackets_ev))

        classification = classify_scene(_reinhard_preview(result.merged_radiance)) if self.pipeline.config.scene_adaptive else None
        return self.pipeline.finish_from_rgb(
            result.merged_radiance, iso=iso, white_balance=raw_frames[reference_idx].white_balance,
            scene_classification=classification, zoom=zoom, burst=result.per_frame_rgb,
            hdr_result=result,
        )

    # -- NIGHT ---------------------------------------------------------------
    def capture_night(self, scene_radiance: np.ndarray | None = None, n_frames: int = 12,
                       exposure: float | None = None, iso: int | None = None, auto_expose: bool = True,
                       zoom: float = 1.0) -> ProcessedImage:
        if auto_expose and (exposure is None or iso is None):
            plan = self.auto_expose(scene_radiance)
            exposure = exposure or plan.shutter_speed
            iso = iso or plan.iso
            n_frames = plan.n_night_frames or n_frames
        exposure = exposure or 1 / 15
        iso = iso or min(self.config.max_iso, 3200)

        result = self.night_engine.capture_and_merge(self, n_frames=n_frames, exposure=exposure, iso=iso,
                                                       scene_radiance=scene_radiance)
        classification = classify_scene(_reinhard_preview(result.image)) if self.pipeline.config.scene_adaptive else None
        return self.pipeline.finish_from_rgb(
            result.image, iso=iso, already_denoised=True, scene_classification=classification, zoom=zoom,
            night_result=result,
        )

    # -- PORTRAIT ---------------------------------------------------------------
    def capture_portrait(self, scene_radiance: np.ndarray | None = None, exposure: float | None = None,
                          iso: int | None = None, blur_strength: float = 14.0) -> ProcessedImage:
        exposure = exposure or 1 / 120
        iso = iso or self.config.base_iso
        raw = self.capture(exposure=exposure, iso=iso, scene_radiance=scene_radiance)
        base = self.pipeline.process(raw)

        portrait = self.portrait_engine.process(base.rgb, blur_strength=blur_strength)
        base.rgb = np.clip(portrait.image, 0.0, 1.0)
        base.metadata["portrait_alpha_mask"] = portrait.alpha_mask
        base.metadata["portrait_depth_map"] = portrait.depth_map
        base.metadata["portrait_skin_mask"] = portrait.skin_mask
        return base

    # -- COMPUTATIONAL ZOOM ---------------------------------------------------------------
    def computational_zoom(self, zoom_factor: float, scene_radiance: np.ndarray | None = None,
                            exposure: float | None = None, iso: int | None = None,
                            output_size: tuple[int, int] | None = None) -> ProcessedImage:
        exposure = exposure or 1 / 120
        iso = iso or self.config.base_iso

        needs_burst = zoom_factor > 3.0
        raw_frames = (self.capture_burst(6, exposure=exposure, iso=iso, scene_radiance=scene_radiance)
                      if needs_burst else [self.capture(exposure=exposure, iso=iso, scene_radiance=scene_radiance)])
        demosaiced = [self._demosaic_raw(rf) for rf in raw_frames]

        classification = classify_scene(_reinhard_preview(demosaiced[0])) if self.pipeline.config.scene_adaptive else None
        return self.pipeline.finish_from_rgb(
            demosaiced[0], iso=iso, white_balance=raw_frames[0].white_balance,
            scene_classification=classification, zoom=zoom_factor,
            burst=demosaiced if needs_burst else None,
        )
