"""REAL-TIME MODE: a simulated live camera preview.

    Sensor -> RAW -> ISP -> AI -> Preview

Continuously "captures" frames and runs a *lightweight* preview pipeline
(calibration + fast demosaic + a cheap tone curve -- explicitly skipping
the expensive multi-frame/neural stages a full-quality still capture uses)
to target smooth frame-rate live view, the way a real phone's viewfinder
runs a cut-down ISP path distinct from its shutter-press pipeline. Frame
production and processing run as separate asyncio tasks connected by a
bounded queue, so a slow consumer (e.g. a UI) naturally applies backpressure
by dropping frames rather than the whole preview stalling.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass

import numpy as np

from vision_engine.calibration.calibration import CalibrationProfile
from vision_engine.demosaic.demosaic import bilinear_demosaic
from vision_engine.pipeline.image_result import srgb_encode
from vision_engine.tone_mapping.tone_mapping import reinhard


@dataclass
class PreviewFrame:
    index: int
    rgb_uint8: np.ndarray
    capture_to_preview_ms: float
    instantaneous_fps: float


def fast_preview_isp(raw_frame) -> np.ndarray:
    """A cut-down ISP path: calibration + bilinear demosaic + global tone map
    + sRGB encode. No denoise, no local contrast, no super-resolution --
    this is what makes live view fast enough to be "real-time" instead of
    running the full still-capture Pipeline every frame."""
    cal = CalibrationProfile.from_raw_frame(raw_frame)
    mosaic = cal.apply(raw_frame.pixels, correct_shading=False)
    rgb = bilinear_demosaic(mosaic, cal.cfa_pattern)
    rgb = reinhard(rgb)
    return np.clip(srgb_encode(np.clip(rgb, 0, 1)) * 255, 0, 255).astype(np.uint8)


class RealtimePreview:
    """Drives a :class:`~vision_engine.sensor.sensor.Sensor` as a live preview stream."""

    def __init__(self, sensor, target_fps: float = 30.0, queue_size: int = 2,
                 scene_provider=None) -> None:
        self.sensor = sensor
        self.target_fps = target_fps
        self.queue: asyncio.Queue = asyncio.Queue(maxsize=queue_size)
        self.scene_provider = scene_provider  # optional callable(frame_index) -> scene_radiance
        self._last_time = time.perf_counter()
        self.frames_dropped = 0
        self.frames_produced = 0

    async def _produce(self, n_frames: int | None) -> None:
        frame_interval = 1.0 / self.target_fps
        i = 0
        while n_frames is None or i < n_frames:
            t0 = time.perf_counter()
            scene = self.scene_provider(i) if self.scene_provider else None
            raw = self.sensor.capture(exposure=min(1 / 60, frame_interval), iso=self.sensor.config.base_iso,
                                       scene_radiance=scene)
            self.frames_produced += 1
            try:
                self.queue.put_nowait((i, raw, t0))
            except asyncio.QueueFull:
                # Backpressure: drop the oldest queued frame rather than block
                # capture -- exactly what a real live-view pipeline does when
                # the ISP/display can't keep up.
                _ = self.queue.get_nowait()
                self.frames_dropped += 1
                self.queue.put_nowait((i, raw, t0))
            i += 1
            elapsed = time.perf_counter() - t0
            await asyncio.sleep(max(0.0, frame_interval - elapsed))
        await self.queue.put(None)  # sentinel: stream finished

    async def stream(self, n_frames: int | None = None):
        """Async generator of :class:`PreviewFrame`. Runs capture concurrently
        with ISP processing via an internal producer task."""
        producer = asyncio.create_task(self._produce(n_frames))
        try:
            while True:
                item = await self.queue.get()
                if item is None:
                    break
                index, raw, t_captured = item
                rgb8 = fast_preview_isp(raw)
                now = time.perf_counter()
                latency_ms = (now - t_captured) * 1000
                instantaneous_fps = 1.0 / max(now - self._last_time, 1e-6)
                self._last_time = now
                yield PreviewFrame(index=index, rgb_uint8=rgb8, capture_to_preview_ms=latency_ms,
                                    instantaneous_fps=instantaneous_fps)
        finally:
            producer.cancel()
            try:
                await producer
            except asyncio.CancelledError:
                pass
