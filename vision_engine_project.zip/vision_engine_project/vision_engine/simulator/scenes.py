"""Procedural synthetic scene library.

Generates linear-light HDR *radiance* images (float32, HxWx3, roughly
0..1 for mid-tones with highlights free to exceed 1.0) that stand in for
real-world photographs so the rest of the lab has something to shoot.
Since no camera roll is available, every scene category the SCENE ANALYSIS
module needs to recognise (landscape, portrait, night, food, sunset, city,
sport, document, macro, snow, beach) has a matching generator here, built
from primitive shapes, gradients and fractal noise texture -- enough
structure for alignment/denoising/HDR/SR algorithms to have real signal to
work with, without depending on any external image dataset.
"""
from __future__ import annotations

import numpy as np
import cv2


def fractal_noise(height: int, width: int, octaves: int = 5, seed: int | None = None, persistence: float = 0.55) -> np.ndarray:
    """Cheap fractal ("value") noise: sum of upsampled random grids at doubling
    frequency. Produces plausible natural texture (foliage, skin, fabric,
    ground) without any external asset dependency."""
    rng = np.random.default_rng(seed)
    out = np.zeros((height, width), dtype=np.float32)
    amplitude, total = 1.0, 0.0
    for o in range(octaves):
        gh, gw = max(2, height >> (octaves - o)), max(2, width >> (octaves - o))
        grid = rng.random((gh, gw)).astype(np.float32)
        upsampled = cv2.resize(grid, (width, height), interpolation=cv2.INTER_CUBIC)
        out += upsampled * amplitude
        total += amplitude
        amplitude *= persistence
    out /= total
    return (out - out.min()) / max(out.max() - out.min(), 1e-6)


def _vignette_gradient(height: int, width: int, top_colour, bottom_colour) -> np.ndarray:
    t = np.linspace(0, 1, height, dtype=np.float32)[:, None, None]
    grad = (1 - t) * np.array(top_colour, np.float32) + t * np.array(bottom_colour, np.float32)
    return np.repeat(grad, width, axis=1)


def _draw_sun(scene: np.ndarray, cx: int, cy: int, r: int, intensity: float, colour=(1.0, 0.85, 0.55)) -> None:
    yy, xx = np.ogrid[: scene.shape[0], : scene.shape[1]]
    d = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    core = np.clip(1.0 - d / r, 0, 1) ** 2
    halo = np.clip(1.0 - d / (r * 4), 0, 1) ** 3
    for c in range(3):
        scene[..., c] += (core * intensity + halo * intensity * 0.3) * colour[c]


def generate_landscape(h: int, w: int, seed: int | None = None) -> np.ndarray:
    scene = _vignette_gradient(h, w, (0.25, 0.45, 0.85), (0.35, 0.55, 0.35))
    horizon = int(h * 0.55)
    tex = fractal_noise(h, w, seed=seed)
    scene[horizon:, :, 1] += tex[horizon:] * 0.25
    scene[horizon:, :, 0] += tex[horizon:] * 0.12
    _draw_sun(scene, int(w * 0.75), int(h * 0.2), r=max(4, w // 22), intensity=6.0)
    return np.clip(scene, 0, None).astype(np.float32)


def _skyline_silhouette(h: int, w: int, seed: int | None = None) -> np.ndarray:
    """A smooth, large-scale boolean silhouette mask (treeline/skyline), not
    per-pixel speckle: a handful of very-low-resolution random cells,
    heavily blurred, so edges are broad and continuous like a real backlit
    horizon -- also far friendlier to demosaicing/HDR alignment at the
    near-black boundary than fine salt-and-pepper noise would be."""
    rng = np.random.default_rng(seed)
    coarse = rng.random((5, 9)).astype(np.float32)
    field = cv2.resize(coarse, (w, h), interpolation=cv2.INTER_CUBIC)
    field = cv2.GaussianBlur(field, (0, 0), sigmaX=w * 0.02)
    field = (field - field.min()) / max(field.max() - field.min(), 1e-6)
    return field > 0.5


def generate_sunset(h: int, w: int, seed: int | None = None) -> np.ndarray:
    scene = _vignette_gradient(h, w, (0.9, 0.35, 0.25), (0.15, 0.08, 0.2))
    _draw_sun(scene, w // 2, int(h * 0.55), r=max(6, w // 14), intensity=10.0, colour=(1.0, 0.55, 0.25))
    horizon = int(h * 0.6)
    silhouette = _skyline_silhouette(h, w, seed)
    scene[horizon:][silhouette[horizon:]] *= 0.05
    return np.clip(scene, 0, None).astype(np.float32)


def generate_city(h: int, w: int, seed: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    scene = _vignette_gradient(h, w, (0.35, 0.4, 0.55), (0.12, 0.12, 0.14))
    n_buildings = 14
    xs = np.linspace(0, w, n_buildings + 1).astype(int)
    for i in range(n_buildings):
        bw = xs[i + 1] - xs[i]
        bh = int(rng.uniform(0.25, 0.75) * h)
        colour = rng.uniform(0.05, 0.2, size=3)
        scene[h - bh :, xs[i] : xs[i + 1]] = colour
        # windows: sparse bright dots
        win_rows = rng.integers(h - bh + 4, h - 2, size=max(1, bh // 14))
        win_cols = rng.integers(xs[i] + 2, max(xs[i] + 3, xs[i + 1] - 2), size=len(win_rows))
        scene[win_rows, win_cols] = rng.uniform(0.8, 1.4, size=(len(win_rows), 3)) * [1.0, 0.85, 0.5]
    return np.clip(scene, 0, None).astype(np.float32)


def generate_portrait(h: int, w: int, seed: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    scene = _vignette_gradient(h, w, (0.2, 0.25, 0.3), (0.1, 0.12, 0.15))
    bg_tex = fractal_noise(h, w, octaves=4, seed=seed)
    scene += (bg_tex[..., None] * 0.08)
    cy, cx = int(h * 0.52), w // 2
    ry, rx = int(h * 0.32), int(w * 0.2)
    yy, xx = np.ogrid[:h, :w]
    face = ((yy - cy) / ry) ** 2 + ((xx - cx) / rx) ** 2 <= 1
    skin = np.array([0.85, 0.62, 0.5], np.float32)
    skin_tex = fractal_noise(h, w, octaves=6, seed=(seed or 0) + 1)
    scene[face] = skin * (0.9 + 0.2 * skin_tex[face, None]).reshape(-1, 1) * skin
    # simple eyes/mouth for a face-like target
    for ey in (-1, 1):
        eye_mask = ((yy - (cy - ry * 0.15)) / (ry * 0.08)) ** 2 + ((xx - (cx + ey * rx * 0.4)) / (rx * 0.12)) ** 2 <= 1
        scene[eye_mask] = [0.05, 0.05, 0.05]
    return np.clip(scene, 0, None).astype(np.float32)


def generate_night(h: int, w: int, seed: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    scene = np.full((h, w, 3), 0.006, dtype=np.float32)
    tex = fractal_noise(h, w, octaves=4, seed=seed)
    scene += tex[..., None] * 0.01
    n_lights = 10
    for _ in range(n_lights):
        cx, cy = rng.integers(0, w), rng.integers(0, h)
        colour = rng.choice([[1.0, 0.85, 0.5], [0.6, 0.8, 1.0], [1.0, 0.4, 0.3]])
        _draw_sun(scene, cx, cy, r=rng.integers(2, 6), intensity=rng.uniform(3, 9), colour=colour)
    return np.clip(scene, 0, None).astype(np.float32)


def generate_food(h: int, w: int, seed: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    scene = _vignette_gradient(h, w, (0.3, 0.22, 0.18), (0.15, 0.1, 0.08))
    cy, cx, r = h // 2, w // 2, min(h, w) // 3
    yy, xx = np.ogrid[:h, :w]
    plate = (yy - cy) ** 2 + (xx - cx) ** 2 <= r * r
    scene[plate] = [0.9, 0.88, 0.85]
    food_r = int(r * 0.7)
    food = (yy - cy) ** 2 + (xx - cx) ** 2 <= food_r * food_r
    tex = fractal_noise(h, w, octaves=5, seed=seed)
    warm = np.stack([0.75 + tex * 0.2, 0.35 + tex * 0.15, 0.15 + tex * 0.1], axis=-1)
    scene[food] = warm[food]
    return np.clip(scene, 0, None).astype(np.float32)


def generate_sport(h: int, w: int, seed: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    scene = _vignette_gradient(h, w, (0.5, 0.7, 0.9), (0.25, 0.55, 0.25))
    # a moving subject: an elongated blob (motion-blurred silhouette proxy)
    cy, cx = int(h * 0.6), int(w * 0.5)
    yy, xx = np.ogrid[:h, :w]
    body = ((yy - cy) / (h * 0.22)) ** 2 + ((xx - cx) / (w * 0.06)) ** 2 <= 1
    scene[body] = [0.9, 0.2, 0.2]
    return np.clip(scene, 0, None).astype(np.float32)


def generate_document(h: int, w: int, seed: int | None = None) -> np.ndarray:
    scene = np.full((h, w, 3), 0.92, dtype=np.float32)
    rng = np.random.default_rng(seed)
    n_lines = h // 24
    for i in range(n_lines):
        y = 20 + i * 24
        if y >= h - 4:
            break
        line_len = rng.integers(int(w * 0.3), int(w * 0.85))
        scene[y : y + 3, 20 : 20 + line_len] = 0.08
    return np.clip(scene, 0, None).astype(np.float32)


def generate_macro(h: int, w: int, seed: int | None = None) -> np.ndarray:
    tex = fractal_noise(h, w, octaves=7, seed=seed)
    scene = np.stack([0.2 + tex * 0.6, 0.55 + tex * 0.35, 0.15 + tex * 0.2], axis=-1)
    cy, cx, r = h // 2, w // 2, min(h, w) // 5
    yy, xx = np.ogrid[:h, :w]
    droplet = (yy - cy) ** 2 + (xx - cx) ** 2 <= r * r
    scene[droplet] += 0.5
    return np.clip(scene, 0, None).astype(np.float32)


def generate_snow(h: int, w: int, seed: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    scene = _vignette_gradient(h, w, (0.75, 0.8, 0.9), (0.85, 0.87, 0.9))
    tex = fractal_noise(h, w, octaves=5, seed=seed)
    scene += tex[..., None] * 0.05
    sparkle_y = rng.integers(0, h, size=int(h * w * 0.001))
    sparkle_x = rng.integers(0, w, size=len(sparkle_y))
    scene[sparkle_y, sparkle_x] = 1.6
    return np.clip(scene, 0, None).astype(np.float32)


def generate_beach(h: int, w: int, seed: int | None = None) -> np.ndarray:
    scene = _vignette_gradient(h, w, (0.5, 0.75, 0.95), (0.85, 0.8, 0.6))
    horizon = int(h * 0.45)
    scene[horizon : horizon + 3] = [0.9, 0.95, 1.0]
    tex = fractal_noise(h, w, octaves=4, seed=seed)
    scene[horizon:, :, 2] += tex[horizon:] * 0.15
    _draw_sun(scene, int(w * 0.2), int(h * 0.15), r=max(4, w // 26), intensity=5.0)
    return np.clip(scene, 0, None).astype(np.float32)


def generate_test_chart(h: int, w: int, seed: int | None = None) -> np.ndarray:
    """A high-frequency synthetic resolution/colour chart -- useful for SR / sharpening / denoise benchmarks."""
    scene = np.zeros((h, w, 3), dtype=np.float32)
    # colour checker-ish grid
    patch_colours = [
        (0.9, 0.2, 0.2), (0.2, 0.9, 0.2), (0.2, 0.2, 0.9), (0.9, 0.9, 0.2),
        (0.9, 0.2, 0.9), (0.2, 0.9, 0.9), (0.9, 0.9, 0.9), (0.1, 0.1, 0.1),
    ]
    ph, pw = h // 2, w // 4
    for i, colour in enumerate(patch_colours):
        r, c = i // 4, i % 4
        scene[r * ph : (r + 1) * ph, c * pw : (c + 1) * pw] = colour
    # overlay a fine grating in a strip for resolution/aliasing testing
    grating_h = h // 6
    xs = np.arange(w)
    grating = (np.sin(xs * np.pi / 2) > 0).astype(np.float32)
    scene[:grating_h, :, :] = grating[None, :, None]
    return np.clip(scene, 0, None).astype(np.float32)


GENERATORS = {
    "landscape": generate_landscape,
    "portrait": generate_portrait,
    "night": generate_night,
    "food": generate_food,
    "sunset": generate_sunset,
    "city": generate_city,
    "sport": generate_sport,
    "document": generate_document,
    "macro": generate_macro,
    "snow": generate_snow,
    "beach": generate_beach,
    "test_chart": generate_test_chart,
}


def generate_scene(kind: str, height: int, width: int, seed: int | None = None) -> np.ndarray:
    if kind not in GENERATORS:
        raise ValueError(f"Unknown scene kind '{kind}'. Available: {sorted(GENERATORS)}")
    return GENERATORS[kind](height, width, seed)


def generate_scene_sequence(kind: str, height: int, width: int, n_frames: int, seed: int | None = None,
                             camera_shake_px: float = 1.5, subject_motion_px: float = 0.0) -> list[np.ndarray]:
    """A burst of near-identical scenes with small sub-pixel camera-shake jitter
    (and, optionally, a drifting subject) -- for HDR/night/motion-engine testing."""
    base = generate_scene(kind, height, width, seed)
    rng = np.random.default_rng((seed or 0) + 777)
    frames = []
    for i in range(n_frames):
        dx, dy = rng.normal(0, camera_shake_px, size=2)
        M = np.array([[1, 0, dx], [0, 1, dy]], dtype=np.float32)
        shaken = cv2.warpAffine(base, M, (width, height), borderMode=cv2.BORDER_REFLECT)
        if subject_motion_px > 0:
            sx = subject_motion_px * i
            Ms = np.array([[1, 0, sx], [0, 1, 0]], dtype=np.float32)
            moving_part = cv2.warpAffine(base, Ms, (width, height), borderMode=cv2.BORDER_REFLECT)
            alpha = 0.4
            shaken = shaken * (1 - alpha) + moving_part * alpha
        frames.append(shaken.astype(np.float32))
    return frames
