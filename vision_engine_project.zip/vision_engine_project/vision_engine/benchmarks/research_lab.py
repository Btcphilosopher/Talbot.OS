"""RESEARCH LAB: an automated benchmarking harness for comparing algorithms
head-to-head -- the "Algorithm A / PSNR / SSIM / Latency" style comparison
from the spec, plus full-pipeline throughput and per-stage profiling.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from skimage.metrics import peak_signal_noise_ratio, structural_similarity


@dataclass
class BenchmarkRow:
    name: str
    psnr: float | None = None
    ssim: float | None = None
    latency_ms: float | None = None
    extra: dict = field(default_factory=dict)

    def __str__(self) -> str:
        parts = [self.name]
        if self.psnr is not None:
            parts.append(f"  PSNR: {self.psnr:.1f}")
        if self.ssim is not None:
            parts.append(f"  SSIM: {self.ssim:.2f}")
        if self.latency_ms is not None:
            parts.append(f"  Latency: {self.latency_ms:.0f}ms")
        for k, v in self.extra.items():
            parts.append(f"  {k}: {v}")
        return "\n".join(parts)


def format_report(rows: list[BenchmarkRow]) -> str:
    return "\n\n".join(str(r) for r in rows)


class ResearchLab:
    """Automated benchmarking across the denoise / SR / full-pipeline stack."""

    def benchmark_denoise(self, scene_kind: str = "macro", size: tuple[int, int] = (128, 128),
                           noise_std: float = 0.06, seed: int = 0) -> list[BenchmarkRow]:
        from vision_engine.denoise.engine import DenoiseEngine
        from vision_engine.simulator.scenes import generate_scene

        clean = np.clip(generate_scene(scene_kind, *size, seed=seed), 0, 1)
        rng = np.random.default_rng(seed)
        noisy = np.clip(clean + rng.normal(0, noise_std, clean.shape), 0, None).astype(np.float32)

        results = DenoiseEngine().compare(noisy, clean)
        return [BenchmarkRow(name=r["strategy"], psnr=r["psnr"], ssim=r["ssim"], latency_ms=r["latency_ms"])
                for r in results]

    def benchmark_super_resolution(self, scene_kind: str = "test_chart", size: tuple[int, int] = (96, 96),
                                    scale: int = 2, n_burst: int = 6, seed: int = 0) -> list[BenchmarkRow]:
        import time

        import cv2

        from vision_engine.super_resolution.zoom_engine import ai_reconstruct, multi_frame_super_resolve
        from vision_engine.simulator.scenes import generate_scene, generate_scene_sequence

        hr = np.clip(generate_scene(scene_kind, size[0] * scale, size[1] * scale, seed=seed), 0, 1)
        lr = cv2.resize(hr, (size[1], size[0]), interpolation=cv2.INTER_AREA)
        burst = generate_scene_sequence(scene_kind, size[0], size[1], n_frames=n_burst, seed=seed, camera_shake_px=1.0)
        burst = [np.clip(b, 0, 1) for b in burst]

        rows = []
        t0 = time.perf_counter()
        bicubic = cv2.resize(lr, (size[1] * scale, size[0] * scale), interpolation=cv2.INTER_CUBIC)
        rows.append(self._sr_row("bicubic", hr, bicubic, time.perf_counter() - t0))

        t0 = time.perf_counter()
        lanczos = cv2.resize(lr, (size[1] * scale, size[0] * scale), interpolation=cv2.INTER_LANCZOS4)
        rows.append(self._sr_row("lanczos", hr, lanczos, time.perf_counter() - t0))

        t0 = time.perf_counter()
        multi_frame = multi_frame_super_resolve(burst, scale)
        multi_frame = cv2.resize(multi_frame, (size[1] * scale, size[0] * scale))
        rows.append(self._sr_row("multi_frame_sr", hr, multi_frame, time.perf_counter() - t0))

        t0 = time.perf_counter()
        ai = ai_reconstruct(lr, scale=scale)
        rows.append(self._sr_row("ai_reconstruction", hr, ai, time.perf_counter() - t0))

        return rows

    @staticmethod
    def _sr_row(name: str, ref: np.ndarray, out: np.ndarray, elapsed_s: float) -> BenchmarkRow:
        out = np.clip(out, 0, 1)[: ref.shape[0], : ref.shape[1]]
        ref_c = ref[: out.shape[0], : out.shape[1]]
        psnr = peak_signal_noise_ratio(ref_c, out, data_range=1.0)
        ssim = structural_similarity(ref_c, out, channel_axis=-1, data_range=1.0)
        return BenchmarkRow(name=name, psnr=float(psnr), ssim=float(ssim), latency_ms=elapsed_s * 1000)

    def benchmark_pipeline(self, camera, scene_kind: str = "landscape", n_runs: int = 3) -> BenchmarkRow:
        from vision_engine.simulator.scenes import generate_scene

        scene = generate_scene(scene_kind, camera.config.height, camera.config.width, seed=0)
        stage_totals: dict[str, list[float]] = {}
        total_times = []
        for _ in range(n_runs):
            raw = camera.capture(exposure=1 / 120, iso=camera.config.base_iso, scene_radiance=scene)
            img = camera.pipeline.process(raw)
            total_times.append(img.profile.total_seconds * 1000)
            for stage in img.profile.stages:
                stage_totals.setdefault(stage.name, []).append(stage.seconds * 1000)

        extra = {f"{k}_ms": f"{np.mean(v):.1f}" for k, v in stage_totals.items()}
        return BenchmarkRow(name=f"pipeline[{scene_kind}]", latency_ms=float(np.mean(total_times)), extra=extra)

    def benchmark_scene_classifier(self, n_per_class: int = 3) -> BenchmarkRow:
        from vision_engine.scene.scene_classifier import classify
        from vision_engine.scene.categories import SceneCategory
        from vision_engine.simulator.scenes import generate_scene

        correct = 0
        total = 0
        for cat in SceneCategory:
            for seed in range(1000, 1000 + n_per_class):
                scene = np.clip(generate_scene(cat.value, 80, 96, seed=seed), 0, 1)
                result = classify(scene)
                total += 1
                correct += int(result.category == cat)
        accuracy = correct / total
        return BenchmarkRow(name="scene_classifier[held-out synthetic]", extra={"accuracy": f"{accuracy:.1%}", "n": total})
