"""SCENE ANALYSIS: a lightweight scene classifier over hand-crafted features.

No trained CNN/dataset is available in this lab, so classification uses a
small, interpretable feature vector (brightness/contrast/saturation/edge
statistics, warm-cool balance, sky/skin/flat-highlight fraction, ...) and
nearest-centroid matching -- explicitly the kind of model a real product
would replace with a distilled on-device classifier (e.g. a few-hundred-KB
MobileNet head) without changing the ``classify`` interface. The per-class
centroids are bootstrapped from :mod:`vision_engine.simulator.scenes`'s own
generators, since that is the only labelled data this lab has -- an
explicit, inspectable calibration step rather than a black box.
"""
from __future__ import annotations

import functools
from dataclasses import dataclass

import cv2
import numpy as np

from vision_engine.scene.categories import SceneCategory
from vision_engine.scene.pipeline_presets import PRESETS, PipelinePreset

FEATURE_NAMES = [
    "brightness", "brightness_std", "saturation", "warm_cool_balance",
    "edge_density", "high_freq_energy", "sky_fraction", "skin_fraction",
    "flat_highlight_fraction", "dark_with_points_score", "centre_bias_energy",
]


def extract_features(rgb: np.ndarray) -> np.ndarray:
    rgb = np.clip(rgb, 0.0, 4.0).astype(np.float32)
    h, w = rgb.shape[:2]
    img8 = np.clip(rgb * 255, 0, 255).astype(np.uint8)
    hsv = cv2.cvtColor(img8, cv2.COLOR_RGB2HSV).astype(np.float32)
    gray = cv2.cvtColor(img8, cv2.COLOR_RGB2GRAY).astype(np.float32)

    brightness = float(gray.mean() / 255.0)
    brightness_std = float(gray.std() / 255.0)
    saturation = float(hsv[..., 1].mean() / 255.0)

    r_mean, g_mean, b_mean = (rgb[..., i].mean() for i in range(3))
    warm_cool_balance = float((r_mean - b_mean) / max(r_mean + g_mean + b_mean, 1e-6))

    edges = cv2.Canny(img8, 50, 150)
    edge_density = float(edges.mean() / 255.0)

    lap = cv2.Laplacian(gray, cv2.CV_32F)
    high_freq_energy = float(np.abs(lap).mean() / 255.0)

    top_band = hsv[: h // 4]
    sky_fraction = float(((top_band[..., 0] > 90) & (top_band[..., 0] < 140) & (top_band[..., 2] > 90)).mean())

    ycrcb = cv2.cvtColor(img8, cv2.COLOR_RGB2YCrCb)
    skin_fraction = float(((ycrcb[..., 1] > 133) & (ycrcb[..., 1] < 178) & (ycrcb[..., 2] > 77) & (ycrcb[..., 2] < 133)).mean())

    flat_highlight_fraction = float((gray > 235).mean())

    dark_frac = float((gray < 20).mean())
    bright_point_frac = float((gray > 200).mean())
    dark_with_points_score = dark_frac * (0.02 + bright_point_frac) * 10.0

    cy0, cy1 = int(h * 0.25), int(h * 0.75)
    cx0, cx1 = int(w * 0.25), int(w * 0.75)
    centre_energy = float(np.abs(lap[cy0:cy1, cx0:cx1]).mean())
    outer_energy = float(np.abs(lap).mean()) + 1e-6
    centre_bias_energy = centre_energy / outer_energy

    return np.array([
        brightness, brightness_std, saturation, warm_cool_balance, edge_density,
        high_freq_energy, sky_fraction, skin_fraction, flat_highlight_fraction,
        dark_with_points_score, centre_bias_energy,
    ], dtype=np.float32)


@functools.lru_cache(maxsize=1)
def _reference_centroids() -> dict[SceneCategory, np.ndarray]:
    from vision_engine.simulator.scenes import generate_scene

    centroids = {}
    for cat in SceneCategory:
        vecs = [extract_features(np.clip(generate_scene(cat.value, 80, 96, seed=seed), 0, 1)) for seed in range(6)]
        centroids[cat] = np.mean(vecs, axis=0)
    return centroids


@functools.lru_cache(maxsize=1)
def _feature_scale() -> np.ndarray:
    centroids = np.stack(list(_reference_centroids().values()))
    scale = centroids.std(axis=0)
    return np.where(scale < 1e-4, 1.0, scale)


@dataclass
class SceneClassification:
    category: SceneCategory
    confidence: float
    scores: dict[str, float]
    preset: PipelinePreset


def classify(rgb: np.ndarray) -> SceneClassification:
    feats = extract_features(rgb)
    scale = _feature_scale()
    centroids = _reference_centroids()

    distances = {cat: float(np.linalg.norm((feats - c) / scale)) for cat, c in centroids.items()}
    similarities = {cat: 1.0 / (1.0 + d) for cat, d in distances.items()}
    total = sum(similarities.values())
    scores = {cat.value: sim / total for cat, sim in similarities.items()}

    best = max(scores, key=scores.get)
    best_cat = SceneCategory(best)
    return SceneClassification(category=best_cat, confidence=scores[best], scores=scores, preset=PRESETS[best_cat])
