import enum


class SceneCategory(str, enum.Enum):
    LANDSCAPE = "landscape"
    PORTRAIT = "portrait"
    NIGHT = "night"
    FOOD = "food"
    SUNSET = "sunset"
    CITY = "city"
    SPORT = "sport"
    DOCUMENT = "document"
    MACRO = "macro"
    SNOW = "snow"
    BEACH = "beach"
