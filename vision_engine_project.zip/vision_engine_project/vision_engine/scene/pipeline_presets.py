"""Per-scene-category pipeline adjustments -- the concrete "use scene
information to dynamically adjust the image pipeline" mechanism. Each
:class:`PipelinePreset` is a set of parameter overrides that
:mod:`vision_engine.pipeline.pipeline` reads when scene-adaptive mode is on.
"""
from __future__ import annotations

from dataclasses import dataclass

from vision_engine.colour.colour_science import ToneCurveStyle
from vision_engine.scene.categories import SceneCategory
from vision_engine.tone_mapping.tone_mapping import ToneMapMethod


@dataclass
class PipelinePreset:
    tone_curve: ToneCurveStyle = ToneCurveStyle.CINEMATIC
    tone_map_method: ToneMapMethod = ToneMapMethod.LOCAL
    saturation: float = 1.08
    vibrance: float = 1.05
    local_contrast_strength: float = 0.35
    sharpening_strength: float = 0.5
    prefer_hdr: bool = False
    prefer_night_mode: bool = False
    prefer_portrait_mode: bool = False
    exposure_bias_ev: float = 0.0
    max_iso: int = 1600
    denoise_bias: float = 0.5   # 0 = favour sharpness, 1 = favour noise reduction


PRESETS: dict[SceneCategory, PipelinePreset] = {
    SceneCategory.LANDSCAPE: PipelinePreset(tone_curve=ToneCurveStyle.VIVID, saturation=1.2, vibrance=1.15,
                                             local_contrast_strength=0.45, prefer_hdr=True, max_iso=200),
    SceneCategory.PORTRAIT: PipelinePreset(tone_curve=ToneCurveStyle.NATURAL, saturation=1.0, vibrance=1.0,
                                            local_contrast_strength=0.15, sharpening_strength=0.3,
                                            prefer_portrait_mode=True, max_iso=800),
    SceneCategory.NIGHT: PipelinePreset(tone_curve=ToneCurveStyle.CINEMATIC, saturation=0.95,
                                         local_contrast_strength=0.25, prefer_night_mode=True,
                                         denoise_bias=0.85, max_iso=6400),
    SceneCategory.FOOD: PipelinePreset(tone_curve=ToneCurveStyle.VIVID, saturation=1.3, vibrance=1.25,
                                        local_contrast_strength=0.5, sharpening_strength=0.7, max_iso=400),
    SceneCategory.SUNSET: PipelinePreset(tone_curve=ToneCurveStyle.CINEMATIC, saturation=1.25, vibrance=1.2,
                                          prefer_hdr=True, exposure_bias_ev=-0.3, max_iso=200),
    SceneCategory.CITY: PipelinePreset(tone_curve=ToneCurveStyle.VIVID, saturation=1.15,
                                        local_contrast_strength=0.5, prefer_hdr=True, max_iso=800),
    SceneCategory.SPORT: PipelinePreset(tone_curve=ToneCurveStyle.VIVID, saturation=1.1,
                                         sharpening_strength=0.8, exposure_bias_ev=0.0,
                                         denoise_bias=0.3, max_iso=3200),
    SceneCategory.DOCUMENT: PipelinePreset(tone_curve=ToneCurveStyle.FLAT, saturation=0.6, vibrance=0.9,
                                            local_contrast_strength=0.6, sharpening_strength=0.9,
                                            tone_map_method=ToneMapMethod.REINHARD, max_iso=400),
    SceneCategory.MACRO: PipelinePreset(tone_curve=ToneCurveStyle.NATURAL, saturation=1.15,
                                         sharpening_strength=0.9, local_contrast_strength=0.4,
                                         prefer_portrait_mode=True, max_iso=400),
    SceneCategory.SNOW: PipelinePreset(tone_curve=ToneCurveStyle.NATURAL, saturation=1.0,
                                        exposure_bias_ev=0.6, local_contrast_strength=0.3, max_iso=200),
    SceneCategory.BEACH: PipelinePreset(tone_curve=ToneCurveStyle.VIVID, saturation=1.15,
                                         exposure_bias_ev=0.3, prefer_hdr=True, max_iso=200),
}
