"""Graceful-degradation helpers for optional heavy dependencies.

The engine's guiding architectural principle is a *performance ladder*:

    Python -> Numba -> C/C++ -> Rust -> GPU/NPU

Every "AI" or hot-loop component is written first in pure NumPy/SciPy so the
lab always runs, then accelerated with Numba when available, and exposes a
neural implementation via PyTorch when *that* is available. None of these
are hard requirements: importing them lazily here means a machine with only
``numpy``/``opencv``/``scipy`` installed can still run the full pipeline --
just with the classical fallback at each stage instead of the learned one.
"""
from __future__ import annotations

import functools
import importlib
import logging
from typing import Any

logger = logging.getLogger("vision_engine")


@functools.lru_cache(maxsize=None)
def has_module(name: str) -> bool:
    try:
        importlib.import_module(name)
        return True
    except Exception:  # pragma: no cover - defensive, any import error counts
        return False


def optional_import(name: str) -> Any | None:
    """Import ``name`` and return the module, or ``None`` if unavailable."""
    if not has_module(name):
        return None
    return importlib.import_module(name)


HAS_TORCH = has_module("torch")
HAS_NUMBA = has_module("numba")

if not HAS_TORCH:
    logger.info(
        "torch not available -- neural stages (AI denoiser, AI super-resolution "
        "reconstruction) will run their classical fallback implementations."
    )
if not HAS_NUMBA:
    logger.info(
        "numba not available -- JIT-accelerated kernels will run as plain NumPy."
    )


def maybe_jit(*jit_args, **jit_kwargs):
    """Decorator: JIT-compile with numba.njit if numba is installed, else no-op.

    This is the concrete expression of the "Python -> Numba" rung of the
    performance ladder described in PERFORMANCE.md: every kernel decorated
    with @maybe_jit runs correctly either way, and simply gets faster once
    numba is on the machine.
    """

    def decorator(func):
        if HAS_NUMBA:
            numba = importlib.import_module("numba")
            return numba.njit(*jit_args, **jit_kwargs)(func)
        return func

    return decorator
