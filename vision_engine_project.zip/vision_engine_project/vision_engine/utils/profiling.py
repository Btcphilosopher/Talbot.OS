"""Lightweight profiling utilities used throughout the pipeline.

Every pipeline stage is wrapped with :class:`StageTimer` so a full capture
produces a :class:`Profile` report of per-stage latency, which the
benchmarks / research-lab and API layers surface as
``RAW processing time``, ``HDR processing time``, ``AI inference time``,
``frames/sec`` etc., as required by the PERFORMANCE section of the spec.
"""
from __future__ import annotations

import os
import time
import tracemalloc
from contextlib import contextmanager
from dataclasses import dataclass, field


@dataclass
class StageRecord:
    name: str
    seconds: float
    peak_memory_mb: float = 0.0
    meta: dict = field(default_factory=dict)


@dataclass
class Profile:
    """An ordered collection of stage timings for one capture/process call."""

    stages: list[StageRecord] = field(default_factory=list)

    def add(self, record: StageRecord) -> None:
        self.stages.append(record)

    @property
    def total_seconds(self) -> float:
        return sum(s.seconds for s in self.stages)

    @property
    def fps(self) -> float:
        return 1.0 / self.total_seconds if self.total_seconds > 0 else float("inf")

    def as_table(self) -> str:
        lines = [f"{'stage':<28}{'ms':>10}{'peak MB':>12}"]
        lines.append("-" * 50)
        for s in self.stages:
            lines.append(f"{s.name:<28}{s.seconds * 1000:>10.2f}{s.peak_memory_mb:>12.2f}")
        lines.append("-" * 50)
        lines.append(f"{'TOTAL':<28}{self.total_seconds * 1000:>10.2f}"
                      f"{'':>12}")
        lines.append(f"{'throughput':<28}{self.fps:>10.2f} fps")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "stages": [
                {"name": s.name, "ms": s.seconds * 1000, "peak_mb": s.peak_memory_mb, **s.meta}
                for s in self.stages
            ],
            "total_ms": self.total_seconds * 1000,
            "fps": self.fps,
        }


class Profiler:
    """Accumulates :class:`StageRecord` entries across a pipeline run.

    Usage::

        profiler = Profiler()
        with profiler.stage("denoise"):
            out = denoise(frame)
        print(profiler.profile.as_table())
    """

    def __init__(self, track_memory: bool = True) -> None:
        self.profile = Profile()
        self.track_memory = track_memory

    @contextmanager
    def stage(self, name: str, **meta):
        if self.track_memory and not tracemalloc.is_tracing():
            tracemalloc.start()
            started_tracing_here = True
        else:
            started_tracing_here = False

        t0 = time.perf_counter()
        try:
            yield
        finally:
            elapsed = time.perf_counter() - t0
            peak_mb = 0.0
            if self.track_memory:
                try:
                    _, peak = tracemalloc.get_traced_memory()
                    peak_mb = peak / (1024 * 1024)
                    tracemalloc.reset_peak()
                except Exception:
                    pass
            if started_tracing_here:
                tracemalloc.stop()
            self.profile.add(StageRecord(name=name, seconds=elapsed, peak_memory_mb=peak_mb, meta=meta))


def gpu_utilisation() -> dict:
    """Best-effort GPU utilisation snapshot.

    Returns ``{"available": False}`` on machines with no CUDA device (true
    for most CI / cloud dev containers) instead of raising -- the intent is
    that :mod:`vision_engine.benchmarks` can always call this safely and the
    real number appears automatically once the code runs on GPU-equipped
    hardware, per the "GPU / NPU" rung of the performance ladder.
    """
    try:
        import torch

        if torch.cuda.is_available():
            idx = torch.cuda.current_device()
            free, total = torch.cuda.mem_get_info(idx)
            return {
                "available": True,
                "device": torch.cuda.get_device_name(idx),
                "memory_used_mb": (total - free) / (1024 * 1024),
                "memory_total_mb": total / (1024 * 1024),
            }
    except Exception:
        pass
    return {"available": False}


def process_memory_mb() -> float:
    """Resident set size of the current process, in MB (best effort)."""
    try:
        import resource

        rss_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # Linux reports KB, macOS reports bytes.
        return rss_kb / 1024 if os.uname().sysname != "Darwin" else rss_kb / (1024 * 1024)
    except Exception:
        return 0.0
