"""Physically-motivated noise model for the synthetic sensor.

The model composes, in electron domain, the noise sources a real CMOS
smartphone sensor exhibits:

* **Photon shot noise**   -- Poisson-distributed, sqrt(signal) in electrons.
* **Read noise**          -- Gaussian, fixed per-pixel std in electrons.
* **Dark current noise**  -- Poisson, grows with exposure time and roughly
  doubles every ~6-7 degC (Arrhenius-like), included as extra electrons.
* **Fixed-pattern noise (FPN)**  -- per-pixel gain/offset non-uniformity,
  deterministic for a given sensor "serial number" (seed) so the same
  virtual sensor always shows the same defect/FPN structure across shots
  (needed for realistic multi-frame burst simulation).
* **Quantisation noise**  -- from the ADC's finite bit depth.

Everything is expressed relative to :class:`~vision_engine.sensor.sensor.SensorConfig`.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class NoiseParameters:
    full_well_capacity_e: float = 12000.0   # electrons at saturation
    read_noise_e: float = 1.8               # electrons RMS (next-gen stacked CMOS: sub-2e-)
    dark_current_e_per_s_at_25c: float = 8.0
    fpn_gain_std: float = 0.004             # 0.4% pixel response non-uniformity
    fpn_offset_std_e: float = 0.6           # dark-signal non-uniformity, electrons
    temperature_doubling_c: float = 6.5     # dark current doubles every N degC


def _fpn_maps(shape: tuple[int, int], seed: int, params: NoiseParameters) -> tuple[np.ndarray, np.ndarray]:
    """Deterministic per-sensor fixed pattern (gain, offset) maps."""
    rng = np.random.default_rng(seed)
    gain = 1.0 + rng.normal(0.0, params.fpn_gain_std, size=shape).astype(np.float32)
    offset = rng.normal(0.0, params.fpn_offset_std_e, size=shape).astype(np.float32)
    return gain, offset


def dark_current_electrons(exposure_s: float, temperature_c: float, params: NoiseParameters) -> float:
    doublings = (temperature_c - 25.0) / params.temperature_doubling_c
    rate = params.dark_current_e_per_s_at_25c * (2.0 ** doublings)
    return max(rate * exposure_s, 0.0)


def simulate_exposure(
    irradiance: np.ndarray,
    *,
    exposure_s: float,
    iso: int,
    base_iso: int,
    bit_depth: int,
    black_level: int,
    white_level: int,
    temperature_c: float,
    params: NoiseParameters,
    sensor_seed: int,
    rng: np.random.Generator | None = None,
) -> np.ndarray:
    """Turn a normalised [0, 1] mosaic ``irradiance`` map into a noisy raw ADU frame.

    Parameters mirror a real capture: exposing longer or with a scene that is
    brighter fills the full well further; higher ISO applies analogue gain
    (which amplifies signal *and* read noise together, the way it does on
    real silicon) rather than just brightening the digital result.
    """
    rng = rng or np.random.default_rng()
    gain_map, offset_map = _fpn_maps(irradiance.shape, sensor_seed, params)

    analogue_gain = iso / base_iso

    # Photons -> photoelectrons. This depends only on how much light actually
    # landed on the photosite (scene irradiance x exposure time, folded into
    # `irradiance` upstream) -- NOT on ISO. ISO is an amplifier-stage gain
    # applied to whatever charge was actually collected (see `post_gain_e`
    # below): it makes the readout brighter *and* proportionally noisier,
    # exactly like a real sensor's analogue gain stage, rather than silently
    # cancelling out of the exposure/brightness relationship.
    signal_e = irradiance.astype(np.float64) * params.full_well_capacity_e
    signal_e = signal_e * gain_map

    dark_e = dark_current_electrons(exposure_s, temperature_c, params)
    total_e = np.clip(signal_e + dark_e, 0.0, None)

    # Photon + dark shot noise: Poisson.
    noisy_e = rng.poisson(total_e).astype(np.float64)

    # Read noise: Gaussian, in electrons, independent of signal level.
    noisy_e += rng.normal(0.0, params.read_noise_e, size=irradiance.shape)
    noisy_e += offset_map

    # Apply analogue (ISO) gain -> post-gain electrons -> ADU via ADC.
    post_gain_e = np.clip(noisy_e, 0.0, None) * analogue_gain
    full_scale_e = params.full_well_capacity_e
    max_adu = (1 << bit_depth) - 1

    adu = post_gain_e / full_scale_e * (white_level - black_level) + black_level
    adu += rng.uniform(-0.5, 0.5, size=irradiance.shape)  # ADC quantisation dither
    adu = np.clip(np.round(adu), 0, max_adu)
    return adu.astype(np.uint16 if bit_depth <= 16 else np.uint32)


def dead_pixel_map(shape: tuple[int, int], seed: int, rate: float = 2e-5) -> np.ndarray:
    """Deterministic boolean map of stuck/dead pixels for a given sensor seed."""
    rng = np.random.default_rng(seed + 1)
    return rng.random(shape) < rate
