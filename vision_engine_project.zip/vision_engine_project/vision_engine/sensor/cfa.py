"""Colour filter array (CFA) definitions for the sensor architectures.

Each pattern is described as a small tile of channel indices
(0=R, 1=G, 2=B, 3=W) that repeats across the sensor. This is the single
source of truth consumed by the sensor simulator (to know which filter
sits over which photosite) and by :mod:`vision_engine.demosaic` (to know
how to reconstruct full-colour pixels from the mosaic).
"""
from __future__ import annotations

import enum

import numpy as np

R, G, B, W = 0, 1, 2, 3
CHANNEL_NAMES = {R: "R", G: "G", B: "B", W: "W"}


class SensorArchitecture(str, enum.Enum):
    BAYER = "bayer"
    QUAD_BAYER = "quad_bayer"
    RGBW = "rgbw"
    STACKED_CMOS = "stacked_cmos"  # Bayer CFA + dual-gain / dual-conversion readout


class CFAPattern(str, enum.Enum):
    RGGB = "RGGB"
    BGGR = "BGGR"
    GRBG = "GRBG"
    GBRG = "GBRG"
    QUAD_RGGB = "QUAD_RGGB"     # 4x4 tile, 2x2 same-colour groups (e.g. Samsung Tetracell / Sony Quad Bayer)
    RGBW_DIAG = "RGBW_DIAG"     # 2x2 tile: R, G, B, W (Panavision/Kodak-style RGBW)


_TILES: dict[CFAPattern, np.ndarray] = {
    CFAPattern.RGGB: np.array([[R, G], [G, B]], dtype=np.uint8),
    CFAPattern.BGGR: np.array([[B, G], [G, R]], dtype=np.uint8),
    CFAPattern.GRBG: np.array([[G, R], [B, G]], dtype=np.uint8),
    CFAPattern.GBRG: np.array([[G, B], [R, G]], dtype=np.uint8),
    CFAPattern.RGBW_DIAG: np.array([[R, G], [W, B]], dtype=np.uint8),
}

# Quad-Bayer: each "super-pixel" of the underlying Bayer pattern is expanded
# into a 2x2 block of identical colour, giving a 4x4 repeating tile.
_TILES[CFAPattern.QUAD_RGGB] = np.array(
    [
        [R, R, G, G],
        [R, R, G, G],
        [G, G, B, B],
        [G, G, B, B],
    ],
    dtype=np.uint8,
)


def architecture_default_pattern(architecture: SensorArchitecture) -> CFAPattern:
    return {
        SensorArchitecture.BAYER: CFAPattern.RGGB,
        SensorArchitecture.STACKED_CMOS: CFAPattern.RGGB,
        SensorArchitecture.QUAD_BAYER: CFAPattern.QUAD_RGGB,
        SensorArchitecture.RGBW: CFAPattern.RGBW_DIAG,
    }[architecture]


def tile(pattern: CFAPattern) -> np.ndarray:
    """The repeating channel-index tile for a pattern (values in {R,G,B,W})."""
    return _TILES[pattern]


def full_mask(pattern: CFAPattern, height: int, width: int) -> np.ndarray:
    """Tile ``pattern`` up to a full ``(height, width)`` channel-index map."""
    t = tile(pattern)
    th, tw = t.shape
    reps_y = -(-height // th)
    reps_x = -(-width // tw)
    full = np.tile(t, (reps_y, reps_x))
    return full[:height, :width]


def channel_masks(pattern: CFAPattern, height: int, width: int) -> dict[int, np.ndarray]:
    """Boolean occupancy mask per channel index present in ``pattern``."""
    fm = full_mask(pattern, height, width)
    return {c: (fm == c) for c in np.unique(tile(pattern))}
