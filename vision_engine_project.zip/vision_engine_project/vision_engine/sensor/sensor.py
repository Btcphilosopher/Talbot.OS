"""Configurable virtual smartphone image sensor.

Simulates the photon-to-ADU pipeline of a next-generation stacked-CMOS
smartphone sensor: it exposes a scene's linear radiance for a given
shutter/ISO pair, samples it through a colour filter array, and returns a
:class:`~vision_engine.raw.raw_format.RawFrame` carrying the noisy mosaic
plus everything downstream stages need (calibration data, lens info,
timestamps, ...).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import cv2
import numpy as np

from vision_engine.sensor.cfa import CFAPattern, SensorArchitecture, architecture_default_pattern, full_mask
from vision_engine.sensor.noise_model import NoiseParameters, dead_pixel_map, simulate_exposure


@dataclass
class LensInfo:
    focal_length_mm: float = 24.0          # 35mm-equivalent
    aperture_f: float = 1.8
    focus_distance_m: float = 1.5
    optical_image_stabilisation: bool = True
    element_count: int = 7


@dataclass
class SensorConfig:
    width: int = 4096
    height: int = 3072
    pixel_size_um: float = 0.7             # next-gen sub-micron stacked pixel
    bit_depth: int = 14
    architecture: SensorArchitecture = SensorArchitecture.QUAD_BAYER
    cfa_pattern: CFAPattern | None = None  # None -> architecture default
    base_iso: int = 50
    max_iso: int = 12800
    black_level: int = 64
    white_level: int | None = None         # None -> (2**bit_depth - 1)
    dynamic_range_stops: float = 14.0
    noise: NoiseParameters = field(default_factory=NoiseParameters)
    dual_gain_conversion: bool = False     # Stacked CMOS: on-chip dual-gain readout
    sensor_seed: int = 1234                # identifies this "physical" unit (FPN/defects)
    lens: LensInfo = field(default_factory=LensInfo)

    def __post_init__(self) -> None:
        if self.cfa_pattern is None:
            self.cfa_pattern = architecture_default_pattern(self.architecture)
        if self.white_level is None:
            self.white_level = (1 << self.bit_depth) - 1
        if self.architecture == SensorArchitecture.STACKED_CMOS:
            self.dual_gain_conversion = True

    def to_dict(self) -> dict:
        d = {
            "width": self.width,
            "height": self.height,
            "pixel_size_um": self.pixel_size_um,
            "bit_depth": self.bit_depth,
            "architecture": self.architecture.value,
            "cfa_pattern": self.cfa_pattern.value,
            "base_iso": self.base_iso,
            "max_iso": self.max_iso,
            "black_level": self.black_level,
            "white_level": self.white_level,
            "dynamic_range_stops": self.dynamic_range_stops,
            "dual_gain_conversion": self.dual_gain_conversion,
            "sensor_seed": self.sensor_seed,
            "lens": vars(self.lens),
        }
        return d


def _default_scene(height: int, width: int) -> np.ndarray:
    """A simple procedural HDR test scene used when no scene is supplied.

    Real callers (the :mod:`vision_engine.simulator` camera and its scene
    library) pass in richer procedurally generated scenes; this keeps
    :class:`Sensor` usable standalone with zero dependencies on the rest of
    the lab.
    """
    yy, xx = np.mgrid[0:height, 0:width].astype(np.float32)
    gradient = 0.05 + 0.9 * (yy / max(height - 1, 1))
    scene = np.stack([gradient, gradient * 0.95, gradient * 0.85], axis=-1)
    # A bright "sky" highlight patch to exercise highlight roll-off / HDR.
    cy, cx, r = height // 6, width // 2, min(height, width) // 8
    yy2, xx2 = np.ogrid[:height, :width]
    mask = (yy2 - cy) ** 2 + (xx2 - cx) ** 2 <= r * r
    scene[mask] += 8.0
    return scene.astype(np.float32)


def _sample_cfa(scene_rgb: np.ndarray, pattern: CFAPattern) -> np.ndarray:
    """Sample an RGB(+W) radiance image through the CFA to get a mosaic."""
    h, w = scene_rgb.shape[:2]
    idx = full_mask(pattern, h, w)
    mosaic = np.zeros((h, w), dtype=np.float32)
    # channel 3 (W, panchromatic) = luminance passthrough (no colour filter loss)
    luminance = scene_rgb[..., 0] * 0.2126 + scene_rgb[..., 1] * 0.7152 + scene_rgb[..., 2] * 0.0722
    for c in np.unique(idx):
        m = idx == c
        if c == 3:
            mosaic[m] = luminance[m]
        else:
            mosaic[m] = scene_rgb[..., c][m]
    return mosaic


class Sensor:
    """A configurable virtual smartphone image sensor.

    Example
    -------
    >>> sensor = Sensor(width=8192, height=6144, bit_depth=14)
    >>> raw = sensor.capture(exposure=1 / 120, iso=400)
    """

    def __init__(self, config: SensorConfig | None = None, **kwargs) -> None:
        self.config = config or SensorConfig(**kwargs)
        self._rng = np.random.default_rng(self.config.sensor_seed)
        self._dead_pixels = dead_pixel_map((self.config.height, self.config.width), self.config.sensor_seed)

    # -- public API -------------------------------------------------
    def capture(
        self,
        exposure: float = 1 / 120,
        iso: int | None = None,
        scene_radiance: np.ndarray | None = None,
        temperature: float = 28.0,
        white_balance: dict | None = None,
        rng: np.random.Generator | None = None,
    ):
        """Simulate one exposure. Returns a :class:`~vision_engine.raw.raw_format.RawFrame`."""
        from vision_engine.raw.raw_format import RawFrame  # local import: avoids cycle

        cfg = self.config
        iso = iso or cfg.base_iso
        iso = int(np.clip(iso, cfg.base_iso, cfg.max_iso))
        rng = rng or self._rng

        scene = scene_radiance if scene_radiance is not None else _default_scene(cfg.height, cfg.width)
        if scene.shape[:2] != (cfg.height, cfg.width):
            scene = cv2.resize(scene, (cfg.width, cfg.height), interpolation=cv2.INTER_AREA)

        mosaic_irradiance = _sample_cfa(scene, cfg.cfa_pattern)
        mosaic_irradiance *= exposure / (1 / 120)  # normalise exposure relative to a 1/120s reference

        adu = simulate_exposure(
            mosaic_irradiance,
            exposure_s=exposure,
            iso=iso,
            base_iso=cfg.base_iso,
            bit_depth=cfg.bit_depth,
            black_level=cfg.black_level,
            white_level=cfg.white_level,
            temperature_c=temperature,
            params=cfg.noise,
            sensor_seed=cfg.sensor_seed,
            rng=rng,
        )
        adu[self._dead_pixels] = cfg.black_level  # stuck-low defect

        metadata = {
            "capture_time": time.time(),
            "temperature_c": temperature,
            "engine": "vision_engine.sensor.Sensor",
        }
        return RawFrame(
            pixels=adu,
            exposure=exposure,
            iso=iso,
            white_balance=white_balance or {"r_gain": 1.0, "g_gain": 1.0, "b_gain": 1.0, "cct_k": 5500},
            sensor_params=cfg.to_dict(),
            lens_info=vars(cfg.lens),
            timestamp=metadata["capture_time"],
            calibration_data={
                "black_level": cfg.black_level,
                "white_level": cfg.white_level,
                "dead_pixel_map_seed": cfg.sensor_seed,
            },
            metadata=metadata,
        )

    def capture_burst(self, n: int, exposure: float = 1 / 60, iso: int | None = None, scene_sequence=None,
                       scene_radiance=None, **kwargs):
        """Capture ``n`` consecutive raw frames (for HDR / night / burst pipelines).

        Every frame in the burst shoots the *same* ``scene_radiance`` (a
        static scene, re-sampled with independent sensor noise each time --
        exactly what a handheld burst of a static/near-static subject is)
        unless a per-frame ``scene_sequence`` is supplied instead.
        """
        frames = []
        for i in range(n):
            scene = scene_sequence[i] if scene_sequence is not None else scene_radiance
            frames.append(self.capture(exposure=exposure, iso=iso, scene_radiance=scene, **kwargs))
        return frames
