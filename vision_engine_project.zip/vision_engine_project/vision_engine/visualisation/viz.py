"""VISUALISATION: render diagnostic views of every intermediate representation
the lab produces -- raw Bayer data, noise maps, HDR/exposure maps, depth
maps, motion vectors, tone curves, histograms -- plus a RAW-vs-processed
side-by-side. Everything renders to a numpy uint8 RGB array (via
:func:`_fig_to_array` for matplotlib-based plots) so callers can display it,
save it with OpenCV/Pillow, or embed it in the FastAPI layer uniformly.
"""
from __future__ import annotations

import io

import cv2
import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


def _fig_to_array(fig) -> np.ndarray:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    arr = cv2.imdecode(np.frombuffer(buf.read(), np.uint8), cv2.IMREAD_COLOR)
    return cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)


def _to_u8(rgb: np.ndarray) -> np.ndarray:
    return np.clip(rgb * 255.0, 0, 255).astype(np.uint8)


def visualise_bayer(mosaic: np.ndarray, pattern) -> np.ndarray:
    """False-colour rendering of the raw CFA mosaic -- each photosite tinted
    by the colour filter actually covering it, before any demosaicing."""
    from vision_engine.sensor.cfa import R, G, B, W, full_mask

    h, w = mosaic.shape
    idx = full_mask(pattern, h, w)
    norm = np.clip(mosaic / max(mosaic.max(), 1e-6), 0, 1)
    out = np.zeros((h, w, 3), dtype=np.float32)
    tint = {R: (1, 0.15, 0.15), G: (0.15, 1, 0.15), B: (0.15, 0.15, 1), W: (1, 1, 1)}
    for c, t in tint.items():
        m = idx == c
        for ch in range(3):
            out[..., ch][m] = norm[m] * t[ch]
    return _to_u8(out)


def visualise_noise_map(noisy: np.ndarray, denoised: np.ndarray) -> np.ndarray:
    """Heatmap of |noisy - denoised| -- what the denoiser judged to be noise."""
    diff = np.abs(noisy - denoised).mean(axis=-1)
    fig, ax = plt.subplots(figsize=(5, 4))
    im = ax.imshow(diff, cmap="inferno")
    ax.set_title("Estimated noise map (|noisy - denoised|)")
    ax.axis("off")
    fig.colorbar(im, ax=ax, fraction=0.046)
    return _fig_to_array(fig)


def visualise_exposure_map(frames_display: list[np.ndarray], evs: list[float]) -> np.ndarray:
    """Per-bracket well-exposedness weight maps used by the HDR merge."""
    from vision_engine.hdr.merge import well_exposedness_weight

    fig, axes = plt.subplots(1, len(frames_display), figsize=(4 * len(frames_display), 4))
    axes = np.atleast_1d(axes)
    for ax, f, ev in zip(axes, frames_display, evs):
        w = well_exposedness_weight(f)
        im = ax.imshow(w, cmap="viridis", vmin=0, vmax=1)
        ax.set_title(f"{ev:+.0f} EV weight")
        ax.axis("off")
    fig.colorbar(im, ax=axes[-1], fraction=0.046)
    return _fig_to_array(fig)


def visualise_hdr_map(merged_radiance: np.ndarray) -> np.ndarray:
    """Log-luminance map of the merged HDR radiance -- shows dynamic range recovered."""
    lum = np.clip(merged_radiance.mean(axis=-1), 1e-4, None)
    fig, ax = plt.subplots(figsize=(5, 4))
    im = ax.imshow(np.log2(lum), cmap="magma")
    ax.set_title("HDR merged radiance (log2 luminance)")
    ax.axis("off")
    fig.colorbar(im, ax=ax, fraction=0.046, label="stops")
    return _fig_to_array(fig)


def visualise_depth_map(depth: np.ndarray) -> np.ndarray:
    fig, ax = plt.subplots(figsize=(5, 4))
    im = ax.imshow(depth, cmap="viridis_r")
    ax.set_title("Depth map (near -> far)")
    ax.axis("off")
    fig.colorbar(im, ax=ax, fraction=0.046)
    return _fig_to_array(fig)


def visualise_motion_vectors(flow: np.ndarray, step: int = 12) -> np.ndarray:
    h, w = flow.shape[:2]
    fig, ax = plt.subplots(figsize=(5, 5 * h / w))
    yy, xx = np.mgrid[0:h:step, 0:w:step]
    ax.quiver(xx, yy, flow[::step, ::step, 0], -flow[::step, ::step, 1], color="crimson", angles="xy")
    ax.invert_yaxis()
    ax.set_title("Motion vectors (dense optical flow, subsampled)")
    ax.set_aspect("equal")
    ax.axis("off")
    return _fig_to_array(fig)


def visualise_tone_curve(style) -> np.ndarray:
    from vision_engine.colour.colour_science import apply_tone_curve

    x = np.linspace(0, 2.0, 400).astype(np.float32).reshape(1, -1, 1).repeat(3, axis=-1)
    y = apply_tone_curve(x, style)
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.plot(x[0, :, 0], y[0, :, 0], color="black", linewidth=2)
    ax.plot([0, 2], [0, 1], "--", color="grey", linewidth=1, label="linear reference")
    ax.set_xlabel("input (linear)")
    ax.set_ylabel("output (display)")
    ax.set_title(f"Tone curve: {style.value if hasattr(style, 'value') else style}")
    ax.legend()
    ax.grid(alpha=0.3)
    return _fig_to_array(fig)


def visualise_histogram(rgb: np.ndarray, bins: int = 128) -> np.ndarray:
    fig, ax = plt.subplots(figsize=(5, 4))
    for ch, colour in zip(range(3), ("red", "green", "blue")):
        hist, edges = np.histogram(rgb[..., ch].ravel(), bins=bins, range=(0, 1))
        ax.plot(edges[:-1], hist, color=colour, alpha=0.8, linewidth=1)
        ax.fill_between(edges[:-1], hist, color=colour, alpha=0.15)
    ax.set_title("RGB histogram")
    ax.set_xlabel("normalised value")
    ax.set_yticks([])
    return _fig_to_array(fig)


def side_by_side(raw_preview: np.ndarray, processed: np.ndarray, labels: tuple[str, str] = ("RAW", "PROCESSED")) -> np.ndarray:
    """Concatenate a quick RAW preview and the final processed image, labelled."""
    h = max(raw_preview.shape[0], processed.shape[0])

    def _prep(img):
        img8 = _to_u8(img) if img.dtype != np.uint8 else img
        if img8.shape[0] != h:
            scale = h / img8.shape[0]
            img8 = cv2.resize(img8, (int(img8.shape[1] * scale), h))
        return img8

    left, right = _prep(raw_preview), _prep(processed)
    gap = np.full((h, 6, 3), 255, dtype=np.uint8)
    combined = np.concatenate([left, gap, right], axis=1)
    combined = cv2.copyMakeBorder(combined, 30, 0, 0, 0, cv2.BORDER_CONSTANT, value=(255, 255, 255))
    cv2.putText(combined, labels[0], (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1, cv2.LINE_AA)
    cv2.putText(combined, labels[1], (left.shape[1] + 16, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1, cv2.LINE_AA)
    return combined


def raw_quick_preview(mosaic: np.ndarray, pattern) -> np.ndarray:
    """Fast (non-Malvar) demosaic purely for RAW-vs-processed visual comparison."""
    from vision_engine.demosaic.demosaic import bilinear_demosaic

    rgb = bilinear_demosaic(mosaic, pattern)
    return _to_u8(np.clip(rgb, 0, 1))
