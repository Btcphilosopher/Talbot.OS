"""vision_engine: a computational photography laboratory for a hypothetical
2029-era smartphone image sensor.

See README.md for the full tour. The two most common entry points:

    from vision_engine.sensor import Sensor, SensorConfig
    from vision_engine.pipeline import Pipeline

    from vision_engine.simulator import Camera   # sensor + every capture mode + a Pipeline, wired up
"""

__version__ = "0.1.0"
