"""COMPUTATIONAL PORTRAIT ENGINE: subject segmentation, depth estimation,
background separation, skin-aware processing, synthetic depth-of-field.

Segmentation and depth here are classical-CV heuristics (GrabCut seeded
from a centre-weighted saliency prior, and a blur/contrast-based pseudo-
depth cue) rather than a trained matting/depth network -- clearly flagged
as the extension point a real product would fill with an on-device
segmentation and monocular-depth model. The *interface*
(:class:`PortraitResult` with a soft alpha mask and a depth map) is what a
learned model would also produce, so swapping the implementation later
does not touch any call site.

The one hard rule, honoured throughout: skin processing and bokeh
compositing must not restructure the face -- no local warping, no feature
resizing -- only tonal smoothing and background blur, so identity is
preserved.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class PortraitResult:
    image: np.ndarray
    alpha_mask: np.ndarray       # soft 0..1 foreground/subject mask
    depth_map: np.ndarray        # 0 (near) .. 1 (far) pseudo-depth
    skin_mask: np.ndarray


def estimate_saliency_prior(rgb: np.ndarray) -> np.ndarray:
    """A cheap centre-bias + local-contrast saliency map, used only to seed
    GrabCut (a real product would seed from a face detector's bbox)."""
    h, w = rgb.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cy, cx = h / 2, w / 2
    centre_bias = 1.0 - np.clip(np.hypot((yy - cy) / (h / 2), (xx - cx) / (w / 2)), 0, 1)
    gray = cv2.cvtColor(np.clip(rgb * 255, 0, 255).astype(np.uint8), cv2.COLOR_RGB2GRAY)
    local_contrast = cv2.Laplacian(gray, cv2.CV_32F)
    local_contrast = cv2.GaussianBlur(np.abs(local_contrast), (0, 0), 4.0)
    local_contrast /= max(local_contrast.max(), 1e-6)
    return 0.6 * centre_bias + 0.4 * local_contrast


def segment_subject(rgb: np.ndarray, iterations: int = 5) -> np.ndarray:
    """GrabCut foreground segmentation seeded by the saliency prior, feathered to a soft mask."""
    h, w = rgb.shape[:2]
    img8 = np.clip(rgb * 255, 0, 255).astype(np.uint8)

    prior = estimate_saliency_prior(rgb)
    gc_mask = np.full((h, w), cv2.GC_PR_BGD, dtype=np.uint8)
    gc_mask[prior > np.percentile(prior, 60)] = cv2.GC_PR_FGD
    gc_mask[prior > np.percentile(prior, 90)] = cv2.GC_FGD

    bgd_model = np.zeros((1, 65), np.float64)
    fgd_model = np.zeros((1, 65), np.float64)
    try:
        cv2.grabCut(img8, gc_mask, None, bgd_model, fgd_model, iterations, cv2.GC_INIT_WITH_MASK)
        hard = np.where((gc_mask == cv2.GC_FGD) | (gc_mask == cv2.GC_PR_FGD), 1.0, 0.0).astype(np.float32)
    except cv2.error:
        hard = (prior > np.percentile(prior, 55)).astype(np.float32)

    # Feather for a natural matte instead of a hard cutout.
    alpha = cv2.GaussianBlur(hard, (0, 0), 3.0)
    return np.clip(alpha, 0.0, 1.0)


def estimate_depth(rgb: np.ndarray, alpha_mask: np.ndarray) -> np.ndarray:
    """Pseudo-depth: subject (from the alpha mask) is "near" (0); everything
    else recedes with distance from the subject and loss of local sharpness
    (a real stack would use dual-pixel disparity, ToF, or a monocular-depth
    network -- see module docstring)."""
    h, w = rgb.shape[:2]
    dist = cv2.distanceTransform((alpha_mask < 0.5).astype(np.uint8), cv2.DIST_L2, 5)
    dist = dist / max(dist.max(), 1e-6)

    gray = cv2.cvtColor(np.clip(rgb * 255, 0, 255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32)
    sharpness = np.abs(cv2.Laplacian(gray, cv2.CV_32F))
    sharpness = cv2.GaussianBlur(sharpness, (0, 0), 3.0)
    sharpness /= max(sharpness.max(), 1e-6)
    blur_depth_cue = 1.0 - sharpness  # blurrier region -> assumed farther away

    depth = np.clip(0.65 * dist + 0.35 * blur_depth_cue, 0.0, 1.0)
    depth[alpha_mask > 0.7] = 0.0
    return depth.astype(np.float32)


def skin_mask_estimate(rgb: np.ndarray) -> np.ndarray:
    """YCrCb-range skin-tone heuristic mask, softened for gentle blending."""
    img8 = np.clip(rgb * 255, 0, 255).astype(np.uint8)
    ycrcb = cv2.cvtColor(img8, cv2.COLOR_RGB2YCrCb)
    lower = np.array([0, 133, 77], dtype=np.uint8)
    upper = np.array([255, 178, 133], dtype=np.uint8)
    mask = cv2.inRange(ycrcb, lower, upper).astype(np.float32) / 255.0
    return cv2.GaussianBlur(mask, (0, 0), 2.0)


def skin_aware_smoothing(rgb: np.ndarray, skin_mask: np.ndarray, strength: float = 0.5) -> np.ndarray:
    """Mild, edge-preserving tonal smoothing confined to skin -- softens
    blemishes/texture noise without touching eyes, brows, hairline or
    non-skin structure, and never warps geometry, so identity is preserved."""
    smoothed = cv2.bilateralFilter(rgb.astype(np.float32), d=9, sigmaColor=0.08, sigmaSpace=9)
    # Extra edge protection: don't smooth strong local edges (eyes, lips
    # outline) even inside the skin mask.
    gray = cv2.cvtColor(np.clip(rgb * 255, 0, 255).astype(np.uint8), cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 40, 120).astype(np.float32) / 255.0
    edges = cv2.dilate(edges, np.ones((3, 3), np.uint8))
    effective_mask = skin_mask * (1.0 - edges) * strength
    return rgb * (1 - effective_mask[..., None]) + smoothed * effective_mask[..., None]


def synthetic_depth_of_field(rgb: np.ndarray, alpha_mask: np.ndarray, depth_map: np.ndarray,
                              max_blur_sigma: float = 14.0, aperture_shape: str = "gaussian") -> np.ndarray:
    """Depth-graduated background blur ("portrait mode" bokeh): several blur
    strengths are precomputed and blended per pixel by depth, so blur ramps
    smoothly with distance instead of a binary subject/background cutout."""
    levels = 5
    blurred_stack = [rgb]
    for i in range(1, levels):
        sigma = max_blur_sigma * (i / (levels - 1))
        blurred_stack.append(cv2.GaussianBlur(rgb, (0, 0), sigma))

    depth_bins = np.clip((depth_map * (levels - 1)), 0, levels - 1 - 1e-3)
    lower = np.floor(depth_bins).astype(int)
    frac = (depth_bins - lower)[..., None]

    out = np.zeros_like(rgb)
    for i in range(levels - 1):
        m = lower == i
        if not m.any():
            continue
        blend = blurred_stack[i] * (1 - frac) + blurred_stack[i + 1] * frac
        out[m] = blend[m]

    keep_sharp = alpha_mask[..., None]
    return rgb * keep_sharp + out * (1 - keep_sharp)


class PortraitEngine:
    def process(self, rgb: np.ndarray, blur_strength: float = 14.0, skin_smoothing: float = 0.45) -> PortraitResult:
        alpha = segment_subject(rgb)
        depth = estimate_depth(rgb, alpha)
        skin = skin_mask_estimate(rgb)

        out = skin_aware_smoothing(rgb, skin, strength=skin_smoothing)
        out = synthetic_depth_of_field(out, alpha, depth, max_blur_sigma=blur_strength)

        return PortraitResult(image=np.clip(out, 0.0, None), alpha_mask=alpha, depth_map=depth, skin_mask=skin)
