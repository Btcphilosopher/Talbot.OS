"""Black-level / calibration and defect correction stages.

Order matches the spec's core pipeline: BLACK LEVEL / CALIBRATION then
DEFECT CORRECTION, both operating on the raw mosaic before demosaic.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from vision_engine.sensor.cfa import CFAPattern, full_mask


def black_level_correct(mosaic: np.ndarray, black_level: float, white_level: float) -> np.ndarray:
    """Subtract black level and normalise to float32 [0, 1]."""
    out = (mosaic.astype(np.float32) - black_level) / max(white_level - black_level, 1)
    return np.clip(out, 0.0, None)


def lens_shading_map(height: int, width: int, strength: float = 0.35) -> np.ndarray:
    """Synthetic radial vignetting gain map (1.0 centre -> 1+strength at corners)."""
    yy, xx = np.mgrid[0:height, 0:width].astype(np.float32)
    cy, cx = height / 2, width / 2
    r = np.sqrt(((yy - cy) / cy) ** 2 + ((xx - cx) / cx) ** 2)
    r = np.clip(r, 0, 1)
    return (1.0 + strength * r ** 2).astype(np.float32)


def apply_lens_shading_correction(mosaic: np.ndarray, shading_map: np.ndarray | None = None) -> np.ndarray:
    if shading_map is None:
        shading_map = lens_shading_map(*mosaic.shape)
    return mosaic * shading_map


def correct_defects(mosaic: np.ndarray, defect_mask: np.ndarray, pattern: CFAPattern) -> np.ndarray:
    """Replace defective pixels with the median of same-channel neighbours.

    Because the CFA interleaves colours, a naive spatial median would blend
    channels; instead each colour plane is treated separately (matching the
    channel index tile from :mod:`vision_engine.sensor.cfa`), so a dead
    green photosite is repaired only from nearby green photosites.
    """
    if not defect_mask.any():
        return mosaic
    h, w = mosaic.shape
    idx = full_mask(pattern, h, w)
    out = mosaic.copy()
    for c in np.unique(idx):
        chan_mask = idx == c
        defects_here = defect_mask & chan_mask
        if not defects_here.any():
            continue
        # Median-filter the whole channel plane (subsampled onto its own
        # grid so the 3x3 window only ever sees same-colour neighbours),
        # then splice the repaired values back in at the defect sites.
        ys, xs = np.where(chan_mask)
        y0, y1 = ys.min(), ys.max() + 1
        x0, x1 = xs.min(), xs.max() + 1
        step_y = int(np.median(np.diff(np.unique(ys)))) if len(np.unique(ys)) > 1 else 1
        step_x = int(np.median(np.diff(np.unique(xs)))) if len(np.unique(xs)) > 1 else 1
        plane = mosaic[y0:y1:step_y, x0:x1:step_x]
        med = cv2.medianBlur(plane.astype(np.float32), 3)
        repaired = np.zeros_like(mosaic)
        repaired[y0:y1:step_y, x0:x1:step_x] = med
        out[defects_here] = repaired[defects_here]
    return out


@dataclass
class CalibrationProfile:
    black_level: float
    white_level: float
    defect_mask: np.ndarray | None = None
    shading_map: np.ndarray | None = None
    cfa_pattern: CFAPattern = CFAPattern.RGGB

    @classmethod
    def from_raw_frame(cls, raw_frame) -> "CalibrationProfile":
        from vision_engine.sensor.noise_model import dead_pixel_map

        cal = raw_frame.calibration_data
        seed = cal.get("dead_pixel_map_seed", 0)
        h, w = raw_frame.shape
        return cls(
            black_level=cal.get("black_level", 0),
            white_level=cal.get("white_level", (1 << raw_frame.bit_depth) - 1),
            defect_mask=dead_pixel_map((h, w), seed),
            shading_map=lens_shading_map(h, w),
            cfa_pattern=CFAPattern(raw_frame.sensor_params.get("cfa_pattern", "RGGB")),
        )

    def apply(self, mosaic_adu: np.ndarray, correct_shading: bool = True) -> np.ndarray:
        """Black-level normalise + defect-correct + (optionally) de-vignette a raw ADU mosaic."""
        out = black_level_correct(mosaic_adu, self.black_level, self.white_level)
        if self.defect_mask is not None:
            out = correct_defects(out, self.defect_mask, self.cfa_pattern)
        if correct_shading:
            out = apply_lens_shading_correction(out, self.shading_map)
        return np.clip(out, 0.0, None)
