"""Edge-aware spatial denoising via a hand-rolled guided filter.

(headless OpenCV builds omit ``cv2.ximgproc``, so this reimplements the
classic He/Sun/Tang 2010 guided filter from box filters -- it is the
"structure-preserving smoothing" building block the detail-preservation
logic in :mod:`vision_engine.denoise.engine` leans on.)
"""
from __future__ import annotations

import cv2
import numpy as np


def guided_filter(guide: np.ndarray, src: np.ndarray, radius: int = 8, eps: float = 1e-3) -> np.ndarray:
    guide = guide.astype(np.float32)
    src = src.astype(np.float32)
    ksize = (radius * 2 + 1, radius * 2 + 1)

    mean_g = cv2.boxFilter(guide, -1, ksize)
    mean_s = cv2.boxFilter(src, -1, ksize)
    mean_gs = cv2.boxFilter(guide * src, -1, ksize)
    cov_gs = mean_gs - mean_g * mean_s

    mean_gg = cv2.boxFilter(guide * guide, -1, ksize)
    var_g = mean_gg - mean_g * mean_g

    a = cov_gs / (var_g + eps)
    b = mean_s - a * mean_g

    mean_a = cv2.boxFilter(a, -1, ksize)
    mean_b = cv2.boxFilter(b, -1, ksize)
    return mean_a * guide + mean_b


def guided_filter_denoise(rgb: np.ndarray, radius: int = 8, eps: float = 4e-3) -> np.ndarray:
    """Self-guided edge-aware smoothing per channel -- removes noise while
    keeping strong edges (unlike a Gaussian blur, which softens everything)."""
    out = np.empty_like(rgb, dtype=np.float32)
    for c in range(rgb.shape[-1]):
        out[..., c] = guided_filter(rgb[..., c], rgb[..., c], radius, eps)
    return out
