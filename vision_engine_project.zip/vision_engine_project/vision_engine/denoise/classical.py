"""Classical (non-learned) denoising algorithms: the baseline every other
strategy in :mod:`vision_engine.denoise.engine` is measured against."""
from __future__ import annotations

import cv2
import numpy as np
from skimage.restoration import denoise_wavelet


def bilateral_denoise(rgb: np.ndarray, diameter: int = 9, sigma_colour: float = 0.06, sigma_space: float = 7.0) -> np.ndarray:
    """Edge-aware bilateral filter -- fast, but tends to leave low-frequency
    "blotchy" residual noise in flat regions at strong settings."""
    return cv2.bilateralFilter(rgb.astype(np.float32), diameter, sigma_colour, sigma_space)


def nlm_denoise(rgb: np.ndarray, h: float = 6.0, template_window: int = 7, search_window: int = 21) -> np.ndarray:
    """Non-local means -- exploits self-similarity across the whole image,
    generally the strongest classical option for preserving fine texture."""
    rgb8 = np.clip(rgb * 255.0, 0, 255).astype(np.uint8)
    out = cv2.fastNlMeansDenoisingColored(rgb8, None, h, h, template_window, search_window)
    return out.astype(np.float32) / 255.0


def wavelet_denoise(rgb: np.ndarray, sigma: float | None = None) -> np.ndarray:
    """Wavelet-domain shrinkage denoise (BayesShrink) -- good at separating
    noise from real edges/detail by frequency band rather than just space."""
    out = denoise_wavelet(np.clip(rgb, 0, None), channel_axis=-1, sigma=sigma, method="BayesShrink", mode="soft", rescale_sigma=True)
    return out.astype(np.float32)


def median_denoise(rgb: np.ndarray, ksize: int = 3) -> np.ndarray:
    """Median filter -- effective against impulse/salt-pepper defects, weak on Gaussian/shot noise."""
    rgb8 = np.clip(rgb * 255.0, 0, 255).astype(np.uint8)
    return cv2.medianBlur(rgb8, ksize).astype(np.float32) / 255.0
