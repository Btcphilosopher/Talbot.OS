"""AI DENOISING ENGINE: strategy selection, detail-preserving blending, and
classical-vs-neural benchmarking, unified behind one call.

The engine's core idea for *not* over-smoothing: any denoiser is run in
"detail recovery" mode by default -- after denoising, an edge/texture
confidence map (gradient-magnitude-based, i.e. cheap structure detection
rather than a learned saliency model) decides, per pixel, how much of the
original high-frequency content to blend back in. Flat, low-gradient
regions (where high-frequency content is overwhelmingly sensor noise) stay
fully denoised; textured/edge regions (where high-frequency content is
overwhelmingly real detail -- foliage, fabric, skin pores, text) recover
much of their original sharpness. This is the mechanism described in the
brief as "understand the difference between real image detail and sensor
noise" without requiring a learned detail/noise classifier.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field

import cv2
import numpy as np
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

from vision_engine.denoise.classical import bilateral_denoise, nlm_denoise, wavelet_denoise
from vision_engine.denoise.neural import denoise_neural
from vision_engine.denoise.spatial import guided_filter_denoise
from vision_engine.denoise.temporal import temporal_denoise


class DenoiseStrategy(str, enum.Enum):
    CLASSICAL = "classical"       # non-local means
    BILATERAL = "bilateral"
    WAVELET = "wavelet"
    SPATIAL = "spatial"           # guided filter
    TEMPORAL = "temporal"         # multi-frame burst (needs frames=)
    NEURAL = "neural"
    AUTO = "auto"                 # picks classical vs neural by ISO/noise level


def detail_confidence(rgb: np.ndarray, edge_low: float = 0.02, edge_high: float = 0.12) -> np.ndarray:
    """Per-pixel confidence in [0, 1] that high-frequency content here is
    real structure rather than noise, from local gradient magnitude."""
    gray = (rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722).astype(np.float32)
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    mag = cv2.GaussianBlur(np.hypot(gx, gy), (0, 0), 1.0)
    conf = (mag - edge_low) / max(edge_high - edge_low, 1e-6)
    return np.clip(conf, 0.0, 1.0)


def recover_detail(original: np.ndarray, denoised: np.ndarray, strength: float = 0.65) -> np.ndarray:
    conf = detail_confidence(original)[..., None]
    high_freq = original - denoised
    return denoised + high_freq * conf * strength


def _run_strategy(strategy: DenoiseStrategy, rgb: np.ndarray, frames: list[np.ndarray] | None,
                   iso: int | None, **kwargs) -> np.ndarray:
    if strategy == DenoiseStrategy.CLASSICAL:
        return nlm_denoise(rgb, **kwargs)
    if strategy == DenoiseStrategy.BILATERAL:
        return bilateral_denoise(rgb, **kwargs)
    if strategy == DenoiseStrategy.WAVELET:
        return wavelet_denoise(rgb, **kwargs)
    if strategy == DenoiseStrategy.SPATIAL:
        return guided_filter_denoise(rgb, **kwargs)
    if strategy == DenoiseStrategy.TEMPORAL:
        if not frames:
            raise ValueError("DenoiseStrategy.TEMPORAL requires frames=[...]")
        denoised, _confidence = temporal_denoise(frames, **kwargs)
        return denoised
    if strategy == DenoiseStrategy.NEURAL:
        return denoise_neural(rgb, **kwargs)
    if strategy == DenoiseStrategy.AUTO:
        # Higher ISO -> more noise -> favour the stronger neural/NLM option;
        # low ISO scenes are already clean enough that a lighter touch
        # (guided filter) preserves more genuine detail.
        chosen = DenoiseStrategy.NEURAL if (iso or 0) > 800 else DenoiseStrategy.SPATIAL
        return _run_strategy(chosen, rgb, frames, iso, **kwargs)
    raise ValueError(strategy)


@dataclass
class DenoiseResult:
    image: np.ndarray
    strategy: DenoiseStrategy
    detail_recovered: bool = True


class DenoiseEngine:
    def denoise(self, rgb: np.ndarray, strategy: DenoiseStrategy | str = DenoiseStrategy.AUTO,
                frames: list[np.ndarray] | None = None, iso: int | None = None,
                preserve_detail: bool = True, detail_strength: float = 0.65, **kwargs) -> DenoiseResult:
        strategy = DenoiseStrategy(strategy)
        out = _run_strategy(strategy, rgb, frames, iso, **kwargs)
        if preserve_detail:
            out = recover_detail(rgb, out, strength=detail_strength)
        return DenoiseResult(image=np.clip(out, 0.0, None), strategy=strategy, detail_recovered=preserve_detail)

    def compare(self, noisy: np.ndarray, clean_reference: np.ndarray,
                strategies: list[DenoiseStrategy] | None = None, iso: int | None = None) -> list[dict]:
        """Benchmark every requested strategy against a known-clean reference
        (only available in the synthetic lab, where ground truth exists) --
        the RESEARCH LAB's classical-vs-neural comparison table."""
        import time

        strategies = strategies or [DenoiseStrategy.BILATERAL, DenoiseStrategy.CLASSICAL,
                                     DenoiseStrategy.WAVELET, DenoiseStrategy.SPATIAL, DenoiseStrategy.NEURAL]
        ref = np.clip(clean_reference, 0, 1)
        results = []
        for strat in strategies:
            t0 = time.perf_counter()
            result = self.denoise(noisy, strategy=strat, iso=iso)
            elapsed_ms = (time.perf_counter() - t0) * 1000
            out = np.clip(result.image, 0, 1)
            psnr = peak_signal_noise_ratio(ref, out, data_range=1.0)
            ssim = structural_similarity(ref, out, channel_axis=-1, data_range=1.0)
            results.append({"strategy": strat.value, "psnr": float(psnr), "ssim": float(ssim), "latency_ms": elapsed_ms})
        results.sort(key=lambda r: -r["psnr"])
        return results
