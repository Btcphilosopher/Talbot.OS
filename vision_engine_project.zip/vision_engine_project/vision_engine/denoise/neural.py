"""Neural denoising inference.

Wraps :class:`vision_engine.models.denoise_net.DenoiseNet`. Loads trained
weights from ``assets/models/denoise_net.pt`` if present (see
``scripts/train_toy_models.py``); otherwise runs the network with its
safe zero-initialised identity behaviour and logs that it is doing so.
If torch itself isn't importable at all, falls back to the classical
non-local-means denoiser so :class:`~vision_engine.denoise.engine.DenoiseEngine`
always has a "neural" option to compare, degraded gracefully.
"""
from __future__ import annotations

import logging
from pathlib import Path

import numpy as np

from vision_engine.utils.optional_deps import HAS_TORCH

logger = logging.getLogger("vision_engine.denoise.neural")

DEFAULT_CHECKPOINT = Path(__file__).resolve().parents[2] / "assets" / "models" / "denoise_net.pt"

_model_cache: dict = {}


def _tile_bounds(size: int, tile: int, overlap: int):
    step = tile - overlap
    starts = list(range(0, max(size - tile, 0) + 1, step)) or [0]
    if starts[-1] + tile < size:
        starts.append(size - tile)
    return starts


def load_model(checkpoint_path: str | Path | None = None):
    if not HAS_TORCH:
        return None
    import torch

    from vision_engine.models.denoise_net import DenoiseNet

    path = Path(checkpoint_path) if checkpoint_path else DEFAULT_CHECKPOINT
    key = str(path)
    if key in _model_cache:
        return _model_cache[key]

    model = DenoiseNet()
    if path.exists():
        state = torch.load(path, map_location="cpu")
        model.load_state_dict(state)
        logger.info("loaded trained denoiser checkpoint from %s", path)
    else:
        logger.info("no trained denoiser checkpoint at %s -- running untrained (identity) network. "
                     "Run scripts/train_toy_models.py to produce real weights.", path)
    model.eval()
    _model_cache[key] = model
    return model


def denoise_neural(rgb: np.ndarray, checkpoint_path: str | Path | None = None, tile: int = 256, overlap: int = 16) -> np.ndarray:
    if not HAS_TORCH:
        from vision_engine.denoise.classical import nlm_denoise

        logger.info("torch unavailable -- neural denoiser falling back to classical NLM")
        return nlm_denoise(rgb)

    import torch

    model = load_model(checkpoint_path)
    h, w = rgb.shape[:2]
    x = torch.from_numpy(np.clip(rgb, 0, None).transpose(2, 0, 1)).unsqueeze(0).float()

    if h <= tile and w <= tile:
        with torch.no_grad():
            out = model(x)
        return out.squeeze(0).permute(1, 2, 0).numpy()

    out = np.zeros_like(rgb, dtype=np.float32)
    weight = np.zeros((h, w, 1), dtype=np.float32)
    window = np.ones((tile, tile), dtype=np.float32)
    for y0 in _tile_bounds(h, tile, overlap):
        for x0 in _tile_bounds(w, tile, overlap):
            patch = x[:, :, y0:y0 + tile, x0:x0 + tile]
            with torch.no_grad():
                pred = model(patch).squeeze(0).permute(1, 2, 0).numpy()
            ph, pw = pred.shape[:2]
            out[y0:y0 + ph, x0:x0 + pw] += pred * window[:ph, :pw, None]
            weight[y0:y0 + ph, x0:x0 + pw] += window[:ph, :pw, None]
    return out / np.clip(weight, 1e-6, None)
