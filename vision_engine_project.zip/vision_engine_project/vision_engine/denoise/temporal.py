"""Temporal (multi-frame burst) denoising.

Aligns a burst onto a reference frame and averages it with per-pixel
confidence weighting: static, well-aligned content is averaged across the
whole burst (noise averages down as ~1/sqrt(N)); pixels where frames still
disagree after alignment (real subject motion) fall back towards the
reference frame alone, so moving subjects don't ghost or smear.
"""
from __future__ import annotations

import numpy as np

from vision_engine.motion.motion_engine import align_frames, to_gray_u8


def temporal_denoise(frames: list[np.ndarray], reference_idx: int = 0, motion_softness: float = 12.0) -> tuple[np.ndarray, np.ndarray]:
    """Returns (denoised, confidence_map). ``confidence_map`` in [0, 1] is how
    much of the burst effectively contributed at each pixel -- 1.0 near
    ``len(frames)`` frames' worth of averaging, lower where motion forced a
    fallback to fewer frames (useful as a diagnostic / visualisation)."""
    aligned, _warps = align_frames(frames, reference_idx, method="ecc")
    ref = aligned[reference_idx]
    ref_gray = to_gray_u8(ref).astype(np.float32) / 255.0

    weighted_sum = np.zeros_like(ref, dtype=np.float32)
    weight_sum = np.zeros(ref_gray.shape, dtype=np.float32)

    for f in aligned:
        g = to_gray_u8(f).astype(np.float32) / 255.0
        disagreement = np.abs(g - ref_gray)
        # Smooth falloff (not a hard mask): confident (near-1) where content
        # agrees with the reference, decaying towards 0 as disagreement grows.
        w = np.exp(-motion_softness * disagreement)
        weighted_sum += f * w[..., None]
        weight_sum += w

    denoised = weighted_sum / np.clip(weight_sum[..., None], 1e-6, None)
    confidence = weight_sum / len(frames)
    return denoised.astype(np.float32), confidence.astype(np.float32)
