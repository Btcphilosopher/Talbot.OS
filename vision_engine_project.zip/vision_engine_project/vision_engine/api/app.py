"""CAMERA PIPELINE API: a FastAPI service wrapping :class:`vision_engine.simulator.camera.Camera`.

Run with:  uvicorn vision_engine.api.app:app --reload

Every capture endpoint returns the rendered photo as a base64 PNG plus the
same diagnostic trail (`ProcessedImage.summary()`, scene classification,
profiling) the Python API exposes, so this is a thin, stateless transport
layer over the exact same engine used everywhere else in the lab.
"""
from __future__ import annotations

import base64
import io
import time
from typing import Optional

import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from vision_engine.pipeline.image_result import ProcessedImage
from vision_engine.sensor.cfa import SensorArchitecture
from vision_engine.sensor.sensor import SensorConfig
from vision_engine.simulator.camera import Camera
from vision_engine.simulator.scenes import GENERATORS, generate_scene

app = FastAPI(
    title="vision-engine camera API",
    description="A computational photography pipeline for a hypothetical next-generation smartphone image sensor.",
    version="0.1.0",
)

_camera_cache: dict[str, Camera] = {}


def _get_camera(width: int, height: int, architecture: str, bit_depth: int) -> Camera:
    key = f"{width}x{height}:{architecture}:{bit_depth}"
    if key not in _camera_cache:
        cfg = SensorConfig(width=width, height=height, architecture=SensorArchitecture(architecture), bit_depth=bit_depth)
        _camera_cache[key] = Camera(cfg)
    return _camera_cache[key]


class CaptureRequest(BaseModel):
    width: int = 640
    height: int = 480
    architecture: str = Field(default="quad_bayer", description="bayer | quad_bayer | rgbw | stacked_cmos")
    bit_depth: int = 14
    scene: str = Field(default="landscape", description=f"one of {sorted(GENERATORS)}")
    seed: Optional[int] = None
    exposure: Optional[float] = None
    iso: Optional[int] = None


class HDRRequest(CaptureRequest):
    brackets_ev: list[float] = [-2.0, 0.0, 2.0]


class NightRequest(CaptureRequest):
    n_frames: int = 12


class ZoomRequest(CaptureRequest):
    zoom_factor: float = 5.0


class CaptureResponse(BaseModel):
    image_base64: str
    format: str = "png"
    width: int
    height: int
    scene_predicted: Optional[str] = None
    scene_confidence: Optional[float] = None
    total_ms: float
    stage_timings_ms: dict
    notes: Optional[str] = None


def _encode(image: ProcessedImage) -> str:
    buf = io.BytesIO()
    image.to_pil().save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _response(image: ProcessedImage, notes: str | None = None) -> CaptureResponse:
    prof = image.profile
    sc = image.scene_classification
    return CaptureResponse(
        image_base64=_encode(image),
        width=image.rgb.shape[1],
        height=image.rgb.shape[0],
        scene_predicted=sc.category.value if sc else None,
        scene_confidence=sc.confidence if sc else None,
        total_ms=prof.total_seconds * 1000 if prof else 0.0,
        stage_timings_ms={s.name: round(s.seconds * 1000, 3) for s in prof.stages} if prof else {},
        notes=notes,
    )


def _scene(req: CaptureRequest, height: int, width: int) -> np.ndarray:
    if req.scene not in GENERATORS:
        raise HTTPException(400, f"unknown scene '{req.scene}'. Available: {sorted(GENERATORS)}")
    return generate_scene(req.scene, height, width, seed=req.seed)


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "time": time.time()}


@app.get("/scenes")
def list_scenes() -> dict:
    return {"scenes": sorted(GENERATORS)}


@app.get("/architectures")
def list_architectures() -> dict:
    return {"architectures": [a.value for a in SensorArchitecture]}


@app.post("/capture", response_model=CaptureResponse)
def capture(req: CaptureRequest) -> CaptureResponse:
    camera = _get_camera(req.width, req.height, req.architecture, req.bit_depth)
    scene = _scene(req, req.height, req.width)
    exposure = req.exposure or 1 / 120
    iso = req.iso or camera.config.base_iso
    raw = camera.capture(exposure=exposure, iso=iso, scene_radiance=scene)
    image = camera.pipeline.process(raw)
    return _response(image)


@app.post("/capture/hdr", response_model=CaptureResponse)
def capture_hdr(req: HDRRequest) -> CaptureResponse:
    camera = _get_camera(req.width, req.height, req.architecture, req.bit_depth)
    scene = _scene(req, req.height, req.width)
    image = camera.capture_hdr(scene_radiance=scene, exposure=req.exposure, iso=req.iso,
                                brackets_ev=tuple(req.brackets_ev))
    return _response(image)


@app.post("/capture/night", response_model=CaptureResponse)
def capture_night(req: NightRequest) -> CaptureResponse:
    camera = _get_camera(req.width, req.height, req.architecture, req.bit_depth)
    scene = _scene(req, req.height, req.width)
    image = camera.capture_night(scene_radiance=scene, n_frames=req.n_frames, exposure=req.exposure, iso=req.iso)
    return _response(image)


@app.post("/capture/portrait", response_model=CaptureResponse)
def capture_portrait(req: CaptureRequest) -> CaptureResponse:
    camera = _get_camera(req.width, req.height, req.architecture, req.bit_depth)
    scene = _scene(req, req.height, req.width)
    image = camera.capture_portrait(scene_radiance=scene, exposure=req.exposure, iso=req.iso)
    return _response(image)


@app.post("/capture/zoom", response_model=CaptureResponse)
def capture_zoom(req: ZoomRequest) -> CaptureResponse:
    camera = _get_camera(req.width, req.height, req.architecture, req.bit_depth)
    scene = _scene(req, req.height, req.width)
    image = camera.computational_zoom(req.zoom_factor, scene_radiance=scene, exposure=req.exposure, iso=req.iso)
    tier = image.metadata.get("zoom_result").tier.value if "zoom_result" in image.metadata else None
    return _response(image, notes=f"zoom tier: {tier}")


@app.get("/benchmarks/denoise")
def benchmark_denoise(scene: str = "macro") -> dict:
    from vision_engine.benchmarks.research_lab import ResearchLab

    rows = ResearchLab().benchmark_denoise(scene_kind=scene)
    return {"results": [r.__dict__ for r in rows]}


@app.get("/benchmarks/scene_classifier")
def benchmark_scene_classifier() -> dict:
    from vision_engine.benchmarks.research_lab import ResearchLab

    row = ResearchLab().benchmark_scene_classifier()
    return row.__dict__
