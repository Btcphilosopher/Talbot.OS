#!/usr/bin/env python3
"""Demonstrates every capture mode on the high-level Camera API:

    result = camera.capture_hdr()
    result = camera.capture_night()
    result = camera.capture_portrait()
    result = camera.computational_zoom(5.0)

Saves one photo per mode to output/, plus a RAW-vs-processed comparison
and a couple of diagnostic visualisations.

Run: python examples/02_capture_modes.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cv2

from vision_engine.calibration.calibration import CalibrationProfile
from vision_engine.sensor import SensorArchitecture, SensorConfig
from vision_engine.simulator import Camera, generate_scene
from vision_engine.visualisation.viz import raw_quick_preview, side_by_side, visualise_hdr_map

OUT_DIR = Path(__file__).resolve().parents[1] / "output"
OUT_DIR.mkdir(exist_ok=True)


def main() -> None:
    cfg = SensorConfig(width=1024, height=768, architecture=SensorArchitecture.QUAD_BAYER)
    camera = Camera(cfg)

    # -- HDR --------------------------------------------------------
    sunset = generate_scene("sunset", cfg.height, cfg.width, seed=10)
    hdr_image = camera.capture_hdr(scene_radiance=sunset)
    print("HDR:", hdr_image.summary())
    hdr_image.save(str(OUT_DIR / "mode_hdr.jpg"))
    hdr_result = hdr_image.metadata["hdr_result"]
    cv2.imwrite(str(OUT_DIR / "mode_hdr_radiance_map.png"),
                cv2.cvtColor(visualise_hdr_map(hdr_result.merged_radiance), cv2.COLOR_RGB2BGR))

    # -- NIGHT --------------------------------------------------------
    night_scene = generate_scene("night", cfg.height, cfg.width, seed=11)
    night_image = camera.capture_night(scene_radiance=night_scene, n_frames=10)
    print("Night:", night_image.summary())
    night_image.save(str(OUT_DIR / "mode_night.jpg"))

    # -- PORTRAIT --------------------------------------------------------
    portrait_scene = generate_scene("portrait", cfg.height, cfg.width, seed=12)
    portrait_image = camera.capture_portrait(scene_radiance=portrait_scene)
    print("Portrait:", portrait_image.summary())
    portrait_image.save(str(OUT_DIR / "mode_portrait.jpg"))

    # -- COMPUTATIONAL ZOOM (5x, per the spec example) -----------------
    city_scene = generate_scene("city", cfg.height, cfg.width, seed=13)
    zoom_image = camera.computational_zoom(5.0, scene_radiance=city_scene)
    zoom_result = zoom_image.metadata["zoom_result"]
    print(f"Zoom 5x: tier={zoom_result.tier.value}, "
          f"captured_information_fraction={zoom_result.captured_information_fraction:.2f}")
    print(f"  {zoom_result.notes}")
    zoom_image.save(str(OUT_DIR / "mode_zoom5x.jpg"))

    # -- RAW vs PROCESSED side-by-side (basic capture) -----------------
    scene = generate_scene("beach", cfg.height, cfg.width, seed=14)
    plan = camera.auto_expose(scene)  # SMART EXPOSURE picks ISO/shutter for this scene's brightness
    raw = camera.capture(exposure=plan.shutter_speed, iso=plan.iso, scene_radiance=scene)
    processed = camera.pipeline.process(raw)
    cal = CalibrationProfile.from_raw_frame(raw)
    mosaic = cal.apply(raw.pixels)
    raw_preview = raw_quick_preview(mosaic, cal.cfa_pattern)
    comparison = side_by_side(raw_preview, processed.to_uint8())
    cv2.imwrite(str(OUT_DIR / "raw_vs_processed.png"), cv2.cvtColor(comparison, cv2.COLOR_RGB2BGR))

    print(f"\nAll outputs written to {OUT_DIR}")


if __name__ == "__main__":
    main()
