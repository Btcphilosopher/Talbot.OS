#!/usr/bin/env python3
"""CAMERA PIPELINE API demo -- exercises the FastAPI app in-process (no
server needed for this script; to actually serve it:

    uvicorn vision_engine.api.app:app --reload

and then POST to http://127.0.0.1:8000/capture etc., see /docs for the
interactive schema).

Run: python examples/06_api_client.py
"""
import base64
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient

from vision_engine.api.app import app

OUT_DIR = Path(__file__).resolve().parents[1] / "output"
OUT_DIR.mkdir(exist_ok=True)

if __name__ == "__main__":
    client = TestClient(app)

    print(client.get("/scenes").json())
    print(client.get("/architectures").json())

    resp = client.post("/capture/hdr", json={"width": 640, "height": 480, "scene": "sunset"})
    body = resp.json()
    print(f"POST /capture/hdr -> {resp.status_code}, scene predicted: {body['scene_predicted']}, "
          f"{body['total_ms']:.1f} ms")

    png_bytes = base64.b64decode(body["image_base64"])
    out_path = OUT_DIR / "api_capture_hdr.png"
    out_path.write_bytes(png_bytes)
    print(f"wrote {out_path}")

    bench = client.get("/benchmarks/denoise").json()
    print("\n/benchmarks/denoise:")
    for row in bench["results"]:
        print(f"  {row['name']:<12} PSNR={row['psnr']:.1f}  SSIM={row['ssim']:.2f}  {row['latency_ms']:.0f}ms")
