#!/usr/bin/env python3
"""VISUALISATION: RAW Bayer data, noise maps, HDR maps, motion vectors,
tone curves, histograms.

Run: python examples/04_visualisation.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cv2
import numpy as np

from vision_engine.calibration.calibration import CalibrationProfile
from vision_engine.colour.colour_science import ToneCurveStyle
from vision_engine.denoise.classical import bilateral_denoise
from vision_engine.sensor import Sensor, SensorArchitecture, SensorConfig
from vision_engine.simulator.scenes import generate_scene
from vision_engine.visualisation import (
    visualise_bayer,
    visualise_histogram,
    visualise_motion_vectors,
    visualise_noise_map,
    visualise_tone_curve,
)
from vision_engine.motion.motion_engine import dense_optical_flow

OUT_DIR = Path(__file__).resolve().parents[1] / "output" / "visualisations"
OUT_DIR.mkdir(exist_ok=True, parents=True)


def save(name: str, rgb_uint8: np.ndarray) -> None:
    cv2.imwrite(str(OUT_DIR / name), cv2.cvtColor(rgb_uint8, cv2.COLOR_RGB2BGR))
    print(f"wrote {OUT_DIR / name}")


if __name__ == "__main__":
    cfg = SensorConfig(width=512, height=384, architecture=SensorArchitecture.BAYER)
    sensor = Sensor(cfg)
    scene = generate_scene("landscape", 384, 512, seed=1)
    raw = sensor.capture(exposure=1 / 120, iso=200, scene_radiance=scene)
    cal = CalibrationProfile.from_raw_frame(raw)
    mosaic = cal.apply(raw.pixels)

    save("bayer_falsecolour.png", visualise_bayer(raw.pixels.astype(float), cal.cfa_pattern))

    from vision_engine.demosaic.demosaic import demosaic

    clean = demosaic(mosaic, pattern=cal.cfa_pattern, architecture=cfg.architecture)
    noisy = clean + np.random.default_rng(0).normal(0, 0.04, clean.shape).astype(np.float32)
    denoised = bilateral_denoise(np.clip(noisy, 0, None))
    save("noise_map.png", visualise_noise_map(noisy, denoised))

    save("histogram.png", visualise_histogram(np.clip(clean, 0, 1)))

    for style in ToneCurveStyle:
        save(f"tone_curve_{style.value}.png", visualise_tone_curve(style))

    scene2 = generate_scene("sport", 384, 512, seed=2)
    raw_a = sensor.capture(exposure=1 / 120, iso=200, scene_radiance=scene2)
    from vision_engine.simulator.scenes import generate_scene_sequence

    seq = generate_scene_sequence("sport", 384, 512, n_frames=2, seed=2, subject_motion_px=8.0)
    flow = dense_optical_flow(np.clip(seq[0], 0, 1), np.clip(seq[1], 0, 1))
    save("motion_vectors.png", visualise_motion_vectors(flow))

    print(f"\nAll visualisations written to {OUT_DIR}")
