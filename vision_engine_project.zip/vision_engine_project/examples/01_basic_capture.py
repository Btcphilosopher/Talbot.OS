#!/usr/bin/env python3
"""The spec's basic usage example, verbatim in spirit:

    camera = Sensor(width=8192, height=6144, bit_depth=14)
    raw = camera.capture(exposure=1/120, iso=400)
    image = pipeline.process(raw)
    image.save("photo.jpg")

Run: python examples/01_basic_capture.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from vision_engine.pipeline import Pipeline
from vision_engine.simulator.camera import Camera
from vision_engine.sensor import SensorArchitecture, SensorConfig
from vision_engine.simulator.scenes import generate_scene

OUT_DIR = Path(__file__).resolve().parents[1] / "output"
OUT_DIR.mkdir(exist_ok=True)

if __name__ == "__main__":
    # Full 8192x6144 (50 MP) at 14-bit is the spec's literal example
    # resolution; dropped to 2048x1536 here so the demo runs in seconds
    # instead of minutes -- every class in this lab is written to scale to
    # the full resolution unmodified, see PERFORMANCE.md.
    camera = Camera(SensorConfig(width=2048, height=1536, bit_depth=14, architecture=SensorArchitecture.QUAD_BAYER))
    scene = generate_scene("landscape", 1536, 2048, seed=1)

    # The spec's literal example fixes exposure=1/120, iso=400 -- a
    # reasonable *pairing* (fast shutter, some ISO gain) but not universally
    # correct exposure for every scene: ISO 400 in bright daylight would
    # heavily overexpose, the same way it would on a real camera without
    # auto-exposure compensating the shutter speed to match. SMART EXPOSURE
    # (see also examples/02_capture_modes.py) is what a real device would
    # run here; using it is the more faithful demonstration.
    plan = camera.auto_expose(scene)
    print(f"SMART EXPOSURE: {plan.rationale}")

    raw = camera.capture(exposure=plan.shutter_speed, iso=plan.iso, scene_radiance=scene)
    print(f"captured RAW: {raw.shape}, {raw.bit_depth}-bit, ISO {raw.iso}, {raw.exposure * 1000:.2f}ms exposure")

    pipeline = Pipeline()
    image = pipeline.process(raw)
    print(image.summary())

    out_path = OUT_DIR / "photo.jpg"
    image.save(str(out_path))
    print(f"saved {out_path}")

    # Also demonstrate the internal RAW container + interchange export.
    raw.save(str(OUT_DIR / "photo.vraw"))
    raw.to_dng(str(OUT_DIR / "photo.dng"))
    raw.to_tiff(str(OUT_DIR / "photo.tiff"))
    print(f"also wrote {OUT_DIR / 'photo.vraw'}, .dng, .tiff")
