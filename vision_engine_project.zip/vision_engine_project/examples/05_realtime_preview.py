#!/usr/bin/env python3
"""REAL-TIME MODE: a simulated live camera preview.

    Sensor -> RAW -> ISP -> AI -> Preview

Run: python examples/05_realtime_preview.py
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from vision_engine.sensor import Sensor, SensorArchitecture, SensorConfig
from vision_engine.simulator import RealtimePreview, generate_scene


async def main() -> None:
    cfg = SensorConfig(width=640, height=480, architecture=SensorArchitecture.BAYER)
    sensor = Sensor(cfg)
    scene = generate_scene("city", 480, 640, seed=1)

    preview = RealtimePreview(sensor, target_fps=30.0, scene_provider=lambda i: scene)
    print("Streaming 60 preview frames at a 30 fps target...\n")
    async for frame in preview.stream(n_frames=60):
        if frame.index % 15 == 0:
            print(f"frame {frame.index:3d}  {frame.instantaneous_fps:5.1f} fps  "
                  f"{frame.capture_to_preview_ms:5.2f} ms capture->preview  shape={frame.rgb_uint8.shape}")

    print(f"\nframes produced: {preview.frames_produced}, dropped: {preview.frames_dropped}")


if __name__ == "__main__":
    asyncio.run(main())
