#!/usr/bin/env python3
"""RESEARCH LAB: automated algorithm comparison.

    Algorithm A
    PSNR: 42.2
    SSIM: 0.94
    Latency: 18ms

Run: python examples/03_research_lab.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from vision_engine.benchmarks import ResearchLab, format_report
from vision_engine.simulator import Camera
from vision_engine.sensor import SensorArchitecture, SensorConfig

if __name__ == "__main__":
    lab = ResearchLab()

    print("=== Denoising: classical vs neural ===\n")
    print(format_report(lab.benchmark_denoise(scene_kind="macro")))

    print("\n\n=== Super-resolution: bicubic / lanczos / multi-frame / AI ===\n")
    print(format_report(lab.benchmark_super_resolution(scene_kind="test_chart")))

    print("\n\n=== Scene classifier accuracy (held-out synthetic scenes) ===\n")
    print(lab.benchmark_scene_classifier(n_per_class=5))

    print("\n\n=== Full pipeline latency, per stage ===\n")
    camera = Camera(SensorConfig(width=1024, height=768, architecture=SensorArchitecture.QUAD_BAYER))
    print(lab.benchmark_pipeline(camera, scene_kind="landscape", n_runs=3))
