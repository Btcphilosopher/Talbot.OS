"""
Lightweight structured logging + metrics collection for VISIONCORE-X.

Avoids any hard dependency beyond the standard library so the simulator
can run in minimal environments. Provides:

  * ``get_logger``      -- a configured ``logging.Logger``
  * ``MetricsRecorder``  -- an in-memory + CSV/JSON sink for per-frame
                             telemetry produced by every subsystem
"""
from __future__ import annotations

import csv
import json
import logging
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List

_CONFIGURED = False


def get_logger(name: str = "visioncore_x", level: int = logging.INFO) -> logging.Logger:
    """Return a module-scoped logger with a single consistent formatter."""
    global _CONFIGURED
    root = logging.getLogger("visioncore_x")
    if not _CONFIGURED:
        handler = logging.StreamHandler(stream=sys.stdout)
        fmt = "%(asctime)s.%(msecs)03d | %(levelname)-7s | %(name)-28s | %(message)s"
        handler.setFormatter(logging.Formatter(fmt, datefmt="%H:%M:%S"))
        root.addHandler(handler)
        root.setLevel(level)
        root.propagate = False
        _CONFIGURED = True
    return logging.getLogger(name)


class MetricsRecorder:
    """Collects per-frame scalar metrics and can export them for analysis.

    Every subsystem calls ``record(frame_index, stage, key, value)`` during
    the simulation loop; the visualization layer and the performance
    engine both read back from the same recorder.
    """

    def __init__(self) -> None:
        self._rows: List[Dict[str, Any]] = []
        self._series: Dict[str, List[float]] = defaultdict(list)
        self._t_start = time.time()

    def record(self, frame_index: int, stage: str, key: str, value: Any) -> None:
        full_key = f"{stage}.{key}"
        self._rows.append(
            {
                "frame": frame_index,
                "stage": stage,
                "metric": key,
                "value": value,
                "t_wall_s": round(time.time() - self._t_start, 6),
            }
        )
        if isinstance(value, (int, float)):
            self._series[full_key].append(float(value))

    def series(self, full_key: str) -> List[float]:
        return list(self._series.get(full_key, []))

    def latest(self, full_key: str, default: float = 0.0) -> float:
        s = self._series.get(full_key)
        return s[-1] if s else default

    def mean(self, full_key: str, default: float = 0.0) -> float:
        s = self._series.get(full_key)
        return sum(s) / len(s) if s else default

    def all_keys(self) -> List[str]:
        return sorted(self._series.keys())

    def to_csv(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=["frame", "stage", "metric", "value", "t_wall_s"])
            writer.writeheader()
            for row in self._rows:
                writer.writerow(row)

    def to_json(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self._rows, indent=2, default=str))

    def summary_report(self) -> str:
        lines = ["=== VISIONCORE-X Metrics Summary ==="]
        for key in self.all_keys():
            s = self._series[key]
            lines.append(
                f"  {key:38s}  n={len(s):4d}  "
                f"mean={sum(s)/len(s):12.4f}  min={min(s):12.4f}  max={max(s):12.4f}"
            )
        return "\n".join(lines)
