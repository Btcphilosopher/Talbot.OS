"""
Configuration management for VISIONCORE-X.

Defines every tunable parameter for the simulated 16K camera system:
optics, sensor, exposure, processing, compression, storage, and
simulation-loop behaviour. Configs can be built programmatically or
loaded/saved as JSON, and are threaded by reference into every
subsystem so the whole platform shares one source of truth.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional, Tuple

# ---------------------------------------------------------------------------
# Resolution presets
# ---------------------------------------------------------------------------
# "16K" is not a single standardised broadcast number. VISIONCORE-X follows
# the common UHD-multiple convention and models a 16:9 sensor at
# 15360 x 8640 ("16K FUHD") by default -- 132.7 effective megapixels.
RESOLUTION_PRESETS = {
    "16K_FUHD": (15360, 8640),
    "16K_DCI": (16384, 8640),
    "8K_UHD": (7680, 4320),
    "4K_UHD": (3840, 2160),
    "1080p": (1920, 1080),
}


@dataclass
class LensConfig:
    focal_length_mm: float = 50.0
    f_number: float = 2.8
    min_f_number: float = 1.4
    max_f_number: float = 22.0
    aperture_blades: int = 9
    transmission: float = 0.92           # optical transmittance (T-stop loss vs f-stop)
    coc_limit_um: float = 20.0           # acceptable circle of confusion, sensor-referred
    distortion_k1: float = -0.015        # radial distortion coefficient (barrel < 0)
    distortion_k2: float = 0.004
    chromatic_aberration_px: float = 0.6  # lateral CA at image corner, in pixels
    vignetting_strength: float = 0.35     # 0..1 relative corner illumination falloff
    lens_mtf50_lp_per_mm: float = 90.0    # lens-only MTF50 contribution


@dataclass
class SensorConfig:
    resolution_preset: str = "16K_FUHD"
    sensor_width_mm: float = 35.6         # full-frame width
    sensor_height_mm: float = 20.0
    pixel_bit_depth: int = 14
    full_well_capacity_e: float = 8_000.0   # electrons -- small because 16K pixels are tiny
    quantum_efficiency: float = 0.62
    fill_factor: float = 0.78
    read_noise_e: float = 2.3
    dark_current_e_per_s_25c: float = 1.8
    row_readout_time_ns: float = 45.0     # time to read out one row of pixels
    adc_noise_e: float = 0.9
    conversion_gain_uv_per_e: float = 55.0
    max_analog_gain_db: float = 48.0
    thermal_design_power_w: float = 6.5
    ambient_temp_c: float = 25.0

    def resolution(self) -> Tuple[int, int]:
        return RESOLUTION_PRESETS[self.resolution_preset]

    def pixel_pitch_um(self) -> float:
        w_px, _ = self.resolution()
        return (self.sensor_width_mm * 1000.0) / w_px

    def megapixels(self) -> float:
        w, h = self.resolution()
        return (w * h) / 1_000_000.0


@dataclass
class ExposureConfig:
    shutter_speed_s: float = 1.0 / 120.0
    iso: int = 400
    auto_exposure: bool = True
    target_mean_intensity: float = 0.45   # 0..1 mid-grey target
    ev_compensation: float = 0.0
    min_shutter_s: float = 1.0 / 8000.0
    max_shutter_s: float = 1.0 / 24.0
    min_iso: int = 100
    max_iso: int = 25600


@dataclass
class ProcessingConfig:
    demosaic_method: str = "bilinear"      # bilinear | malvar
    sharpening_amount: float = 0.35
    sharpening_radius_px: float = 1.2
    denoise_strength: float = 0.4
    hdr_enabled: bool = False
    hdr_stops: Tuple[float, ...] = (-2.0, 0.0, 2.0)
    white_balance_mode: str = "gray_world"  # gray_world | preset | manual
    colour_temp_k: float = 5600.0


@dataclass
class CompressionConfig:
    codec: str = "hevc_like"               # raw | lossless | hevc_like | prores_like
    quality: float = 0.75                  # 0..1
    tile_size_px: int = 512
    keyframe_interval: int = 24


@dataclass
class StorageConfig:
    device_write_speed_mb_s: float = 2800.0   # e.g. RAID-0 NVMe array
    buffer_capacity_frames: int = 12
    interface: str = "PCIe4x4"                # informational label only


@dataclass
class SimulationConfig:
    n_frames: int = 30
    frame_rate_target_fps: float = 24.0
    # Array-based ISP/visualisation stages run on a *representative* frame
    # downscaled from the true 16K sensor grid by this factor, so the
    # simulation can actually hold the array in memory and finish in
    # seconds. All bandwidth/storage/timing metrics remain computed
    # analytically at the *true* full 16K resolution -- see resolution/.
    preview_scale: float = 1.0 / 40.0
    random_seed: Optional[int] = 42
    scene_type: str = "studio_gradient"
    motion_type: str = "static"          # static | pan | handheld | whip_pan
    parallel_encode_workers: int = 16
    storage_budget_mb_s: Optional[float] = None
    output_dir: str = "output"


@dataclass
class CameraConfig:
    lens: LensConfig = field(default_factory=LensConfig)
    sensor: SensorConfig = field(default_factory=SensorConfig)
    exposure: ExposureConfig = field(default_factory=ExposureConfig)
    processing: ProcessingConfig = field(default_factory=ProcessingConfig)
    compression: CompressionConfig = field(default_factory=CompressionConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    simulation: SimulationConfig = field(default_factory=SimulationConfig)

    def to_json(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), indent=2))

    @classmethod
    def from_json(cls, path: str | Path) -> "CameraConfig":
        data = json.loads(Path(path).read_text())
        return cls(
            lens=LensConfig(**data.get("lens", {})),
            sensor=SensorConfig(**data.get("sensor", {})),
            exposure=ExposureConfig(**data.get("exposure", {})),
            processing=ProcessingConfig(**data.get("processing", {})),
            compression=CompressionConfig(**data.get("compression", {})),
            storage=StorageConfig(**data.get("storage", {})),
            simulation=SimulationConfig(**data.get("simulation", {})),
        )

    def summary(self) -> str:
        w, h = self.sensor.resolution()
        return (
            f"VISIONCORE-X CameraConfig: {w}x{h} "
            f"({self.sensor.megapixels():.1f} MP), "
            f"{self.lens.focal_length_mm:.0f}mm f/{self.lens.f_number:.1f}, "
            f"ISO {self.exposure.iso}, "
            f"shutter 1/{1.0 / self.exposure.shutter_speed_s:.0f}s, "
            f"codec={self.compression.codec}"
        )
