import numpy as np

from optics import aperture_sim, diffraction, focal_geometry, lens_model
from utils.config import LensConfig, SensorConfig


def test_airy_disk_grows_with_f_number():
    r1 = diffraction.airy_disk_radius_um(f_number=2.0)
    r2 = diffraction.airy_disk_radius_um(f_number=8.0)
    assert r2 > r1


def test_diffraction_limited_resolution_shrinks_with_f_number():
    f1 = diffraction.diffraction_limited_resolution_lp_mm(f_number=2.0)
    f2 = diffraction.diffraction_limited_resolution_lp_mm(f_number=8.0)
    assert f2 < f1


def test_diffraction_mtf_zero_at_and_beyond_cutoff():
    fc = diffraction.diffraction_limited_resolution_lp_mm(f_number=4.0)
    mtf = diffraction.diffraction_mtf(np.array([fc, fc * 1.5]), f_number=4.0)
    assert np.allclose(mtf, 0.0, atol=1e-6)


def test_diffraction_mtf_near_one_at_dc():
    mtf = diffraction.diffraction_mtf(np.array([1e-6]), f_number=4.0)
    assert mtf[0] > 0.99


def test_is_diffraction_limited_true_for_tiny_pixels():
    # 16K-scale pixel pitches are a couple of microns -- stopping down to
    # f/8 should already be diffraction limited.
    assert diffraction.is_diffraction_limited(f_number=8.0, pixel_pitch_um=2.3)


def test_hyperfocal_distance_decreases_with_smaller_aperture():
    lens_wide = LensConfig(f_number=1.4)
    lens_narrow = LensConfig(f_number=16.0)
    h_wide = aperture_sim.hyperfocal_distance_m(lens_wide, sensor_width_mm=35.6)
    h_narrow = aperture_sim.hyperfocal_distance_m(lens_narrow, sensor_width_mm=35.6)
    assert h_narrow < h_wide


def test_depth_of_field_range_increases_when_stopped_down():
    sensor_w = 35.6
    lens_wide = LensConfig(f_number=1.4)
    lens_narrow = LensConfig(f_number=11.0)
    dof_wide = aperture_sim.depth_of_field(lens_wide, subject_distance_m=3.0, sensor_width_mm=sensor_w)
    dof_narrow = aperture_sim.depth_of_field(lens_narrow, subject_distance_m=3.0, sensor_width_mm=sensor_w)
    assert dof_narrow.dof_range_m > dof_wide.dof_range_m


def test_field_of_view_widens_with_shorter_focal_length():
    sensor = SensorConfig()
    fov_wide = focal_geometry.field_of_view(LensConfig(focal_length_mm=14.0), sensor)
    fov_tele = focal_geometry.field_of_view(LensConfig(focal_length_mm=200.0), sensor)
    assert fov_wide.horizontal_deg > fov_tele.horizontal_deg


def test_system_mtf_bounded_0_1():
    lens = LensConfig()
    freqs = np.linspace(0, 200, 50)
    mtf = lens_model.system_mtf(freqs, lens)
    assert np.all(mtf >= -1e-9) and np.all(mtf <= 1.0 + 1e-9)
