import numpy as np

from compression import bandwidth_model, image_codec
from compression.encoder_16k import build_tile_plan, estimate_encode_time
from optimisation.compression_optimizer import optimize_quality_for_bandwidth
from storage.buffer_manager import BufferedFrame, FrameBuffer
from storage.write_pipeline import WritePipeline
from utils.config import CompressionConfig, SensorConfig, StorageConfig


def test_lossy_bpp_increases_with_quality():
    cfg = CompressionConfig(codec="hevc_like", quality=0.1)
    low = image_codec.estimate_bits_per_pixel(cfg)
    cfg.quality = 0.9
    high = image_codec.estimate_bits_per_pixel(cfg)
    assert high > low


def test_raw_frame_size_matches_bit_depth():
    sensor = SensorConfig(resolution_preset="4K_UHD", pixel_bit_depth=12)
    size = image_codec.raw_frame_size_bytes(sensor)
    w, h = sensor.resolution()
    assert size == w * h * 12 / 8


def test_compression_ratio_above_one_for_lossy():
    sensor = SensorConfig(resolution_preset="4K_UHD")
    cfg = CompressionConfig(codec="hevc_like", quality=0.5)
    ratio = image_codec.compression_ratio(sensor, cfg)
    assert ratio > 1.0


def test_tile_plan_covers_full_frame():
    sensor = SensorConfig(resolution_preset="4K_UHD")
    cfg = CompressionConfig(tile_size_px=512)
    plan = build_tile_plan(sensor, cfg)
    w, h = sensor.resolution()
    assert plan.tiles_x * plan.tile_size_px >= w
    assert plan.tiles_y * plan.tile_size_px >= h


def test_encode_time_positive_and_parallel_faster():
    sensor = SensorConfig(resolution_preset="4K_UHD")
    cfg = CompressionConfig(codec="hevc_like", quality=0.7)
    est_serial = estimate_encode_time(sensor, cfg, parallel_workers=1)
    est_parallel = estimate_encode_time(sensor, cfg, parallel_workers=32)
    assert est_parallel.parallel_total_time_ms < est_serial.parallel_total_time_ms


def test_bandwidth_report_flags_infeasible_interfaces_for_huge_rate():
    report = bandwidth_model.analyze_bandwidth(frame_size_bytes=500 * 1024 * 1024, frame_rate_fps=60)
    assert "SATA_SSD" in report.infeasible_interfaces


def test_compression_optimizer_meets_budget():
    sensor = SensorConfig(resolution_preset="4K_UHD")
    cfg = CompressionConfig(codec="hevc_like", quality=1.0)
    result = optimize_quality_for_bandwidth(sensor, cfg, frame_rate_fps=24, budget_mb_s=50.0)
    assert result.within_budget
    assert 0.0 <= result.quality <= 1.0


def test_buffer_drops_frames_when_full():
    buf = FrameBuffer(capacity_frames=2)
    assert buf.push(BufferedFrame(0, 100.0, 0.0))
    assert buf.push(BufferedFrame(1, 100.0, 0.0))
    assert not buf.push(BufferedFrame(2, 100.0, 0.0))  # over capacity
    assert buf.dropped_frame_count == 1


def test_write_pipeline_drains_within_budget():
    storage_cfg = StorageConfig(device_write_speed_mb_s=100.0, buffer_capacity_frames=5)
    pipeline = WritePipeline(storage_cfg)
    frame_bytes = 10 * 1024 * 1024  # 10MB, well under 100MB/s * 1s budget
    pipeline.submit_frame(0, frame_bytes, 0.0)
    result = pipeline.drain_tick(0, tick_duration_s=1.0)
    assert result.frames_drained == 1
    assert result.bytes_written == frame_bytes


def test_write_pipeline_saturates_when_overloaded():
    storage_cfg = StorageConfig(device_write_speed_mb_s=1.0, buffer_capacity_frames=5)
    pipeline = WritePipeline(storage_cfg)
    big_frame = 50 * 1024 * 1024  # 50MB, way over 1MB/s * 1s budget
    pipeline.submit_frame(0, big_frame, 0.0)
    result = pipeline.drain_tick(0, tick_duration_s=1.0)
    assert result.write_saturated
    assert result.frames_drained == 0
