import numpy as np

from imaging import exposure, iso_gain, white_balance
from imaging.colour_filter_array import bayer_channel_mask, channel_sampling_fraction, mosaic
from resolution.oversampling import analyze_binning
from signal_processing.demosaic import demosaic
from signal_processing.noise_reduction import denoise, estimate_noise_std
from signal_processing.sharpening import edge_energy, unsharp_mask
from utils.config import CameraConfig


def test_exposure_value_matches_known_formula():
    # EV = log2(N^2 / t); f/2, 1/4s -> log2(4 / 0.25) = log2(16) = 4.0
    ev = exposure.exposure_value(f_number=2.0, shutter_speed_s=1.0 / 4.0)
    assert abs(ev - 4.0) < 1e-9


def test_auto_expose_step_moves_toward_target():
    cfg = CameraConfig()
    cfg.exposure.target_mean_intensity = 0.45
    dark_metered = 0.1
    new_state = exposure.auto_expose_step(cfg, dark_metered)
    # Underexposed -> controller should lengthen shutter or raise ISO
    assert (new_state.shutter_speed_s > cfg.exposure.shutter_speed_s) or (new_state.iso > cfg.exposure.iso)


def test_iso_gain_db_doubles_correctly():
    db_200 = iso_gain.iso_to_gain_db(200)
    db_400 = iso_gain.iso_to_gain_db(400)
    assert abs((db_400 - db_200) - 6.0206) < 0.01


def test_gain_profile_splits_analog_and_digital():
    cfg = __import__("utils.config", fromlist=["SensorConfig"]).SensorConfig(max_analog_gain_db=24.0)
    profile = iso_gain.build_gain_profile(iso=25600, sensor_cfg=cfg)
    assert profile.digital_gain_db > 0  # exceeds max analog gain, must spill to digital
    assert profile.is_extended_digital


def test_bayer_channel_fractions_sum_to_one():
    fractions = channel_sampling_fraction("RGGB")
    assert abs(sum(fractions.values()) - 1.0) < 1e-9
    assert fractions["G"] == 0.5


def test_mosaic_matches_channel_mask():
    rgb = np.random.default_rng(0).uniform(0, 1, size=(8, 8, 3))
    raw = mosaic(rgb, "RGGB")
    mask = bayer_channel_mask(8, 8, "RGGB")
    for y in range(8):
        for x in range(8):
            assert raw[y, x] == rgb[y, x, mask[y, x]]


def test_demosaic_output_shape_and_range():
    raw = np.random.default_rng(1).uniform(0, 1, size=(32, 32))
    result = demosaic(raw, method="bilinear")
    assert result.shape == (32, 32, 3)
    assert result.min() >= -1e-6


def test_demosaic_malvar_runs_without_error():
    raw = np.random.default_rng(2).uniform(0, 1, size=(32, 32))
    result = demosaic(raw, method="malvar")
    assert result.shape == (32, 32, 3)


def test_gray_world_white_balance_neutralizes_mean():
    rng = np.random.default_rng(3)
    rgb = rng.uniform(0, 1, size=(16, 16, 3))
    rgb[..., 0] *= 0.5  # push red down to create a colour cast
    gains = white_balance.gray_world_gains(rgb)
    balanced = white_balance.apply_white_balance(rgb, gains)
    means = balanced.reshape(-1, 3).mean(axis=0)
    assert abs(means[0] - means[1]) < 1e-6


def test_denoise_reduces_noise_std():
    rng = np.random.default_rng(4)
    clean = np.ones((64, 64, 3)) * 0.5
    noisy = clean + rng.normal(0, 0.08, size=clean.shape)
    denoised = denoise(noisy, strength=0.8)
    assert estimate_noise_std(denoised) < estimate_noise_std(noisy)


def test_unsharp_mask_increases_edge_energy():
    yy, xx = np.mgrid[0:64, 0:64]
    step_edge = np.where(xx < 32, 0.2, 0.8).astype(np.float64)
    step_edge = np.repeat(step_edge[..., None], 3, axis=2)
    sharpened = unsharp_mask(step_edge, amount=1.0, radius_px=1.5)
    assert edge_energy(sharpened) >= edge_energy(step_edge)


def test_binning_reduces_resolution_and_improves_snr():
    result = analyze_binning(3840, 2160, bin_factor=2, full_well_capacity_e=8000.0, read_noise_e=2.3)
    assert result.resolution_retained_pct < 30.0  # 1/4 the pixel count
    assert result.snr_improvement_db > 0
