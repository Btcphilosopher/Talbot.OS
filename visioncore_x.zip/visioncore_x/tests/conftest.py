"""Shared pytest fixtures: put the project root on sys.path so `import
core...`, `import optics...` etc. resolve when tests are run from any
working directory (`pytest` from repo root or `pytest tests/`).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pytest

from utils.config import CameraConfig


@pytest.fixture
def small_camera_config() -> CameraConfig:
    """A CameraConfig tuned for fast tests: tiny preview grid, few frames."""
    cfg = CameraConfig()
    cfg.simulation.n_frames = 3
    cfg.simulation.preview_scale = 1.0 / 400.0  # ~38x22 preview grid
    cfg.simulation.random_seed = 123
    return cfg


@pytest.fixture
def rng() -> np.random.Generator:
    return np.random.default_rng(0)
