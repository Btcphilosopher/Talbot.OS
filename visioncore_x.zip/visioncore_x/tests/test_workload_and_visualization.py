import numpy as np

from workload.motion_simulation import generate_motion_profile, motion_blur_kernel
from workload.scene_generator import generate_scene, SCENE_GENERATORS


def test_all_scene_generators_produce_valid_rgb():
    for name in SCENE_GENERATORS:
        scene = generate_scene(name, 32, 48)
        assert scene.shape == (32, 48, 3)
        assert np.all(np.isfinite(scene))
        assert scene.min() >= 0.0


def test_motion_profile_length_matches_frame_count():
    profile = generate_motion_profile(10, motion_type="handheld")
    assert len(profile) == 10


def test_motion_blur_kernel_normalizes_to_one():
    kernel = motion_blur_kernel(extent_px=6.0, angle_deg=30.0)
    assert abs(kernel.sum() - 1.0) < 1e-9
    assert kernel.shape[0] == kernel.shape[1]


def test_static_motion_profile_has_zero_motion():
    profile = generate_motion_profile(5, motion_type="static")
    assert all(s.pan_deg_s == 0.0 and s.tilt_deg_s == 0.0 for s in profile)


def test_whip_pan_profile_peaks_mid_sequence():
    profile = generate_motion_profile(11, motion_type="whip_pan")
    rates = [abs(s.pan_deg_s) for s in profile]
    assert rates.index(max(rates)) in range(4, 7)  # peaks near the middle


def test_visualization_module_importable_without_crashing():
    # Import-time guard: these modules must not require matplotlib to be
    # *imported* -- only to actually render.
    import visualization.image_viewer  # noqa: F401
    import visualization.sensor_heatmap  # noqa: F401
    import visualization.optical_flow  # noqa: F401
    import visualization.dashboard  # noqa: F401
