import numpy as np

from optics.lens_model import evaluate_optical_performance
from performance.frame_rate import compute_frame_rate, pipelined_fps, sequential_fps
from performance.latency import LatencyTracker
from resolution.aliasing_model import analyze_aliasing, nyquist_frequency_lp_mm
from resolution.resolution_engine import build_preview_grid, compute_effective_resolution, snr_to_resolution_factor
from utils.config import CameraConfig, SensorConfig


def test_preview_grid_scales_from_true_resolution():
    cfg = CameraConfig()
    cfg.simulation.preview_scale = 0.01
    grid = build_preview_grid(cfg)
    assert grid.preview_width < grid.true_width
    assert grid.preview_height < grid.true_height
    assert grid.preview_width >= 32  # enforced minimum


def test_snr_to_resolution_factor_monotonic():
    low = snr_to_resolution_factor(0.0)
    high = snr_to_resolution_factor(40.0)
    assert high > low
    assert 0.0 <= low <= 1.0 and 0.0 <= high <= 1.0


def test_effective_resolution_never_exceeds_nominal():
    cfg = CameraConfig()
    optical_perf = evaluate_optical_performance(cfg.lens, cfg.sensor.pixel_pitch_um())
    report = compute_effective_resolution(cfg, optical_perf, mean_snr_db=30.0, aliasing_severity=0.0)
    assert report.effective_megapixels <= report.nominal_megapixels + 1e-6


def test_aliasing_severity_zero_for_flat_scene():
    flat = np.full((64, 64), 0.5)
    sensor = SensorConfig()
    report = analyze_aliasing(flat, sensor)
    assert report.aliasing_severity == 0.0


def test_nyquist_frequency_positive():
    sensor = SensorConfig()
    assert nyquist_frequency_lp_mm(sensor) > 0


def test_frame_rate_bottleneck_identifies_slowest_stage():
    stage_times = {"sensor_readout": 5.0, "isp": 12.0, "encode": 30.0, "write": 8.0}
    report = compute_frame_rate(stage_times, target_fps=24.0)
    assert report.bottleneck_stage == "encode"
    assert abs(report.achievable_fps - (1000.0 / 30.0)) < 1e-6


def test_pipelined_fps_faster_than_sequential():
    stage_times = {"a": 5.0, "b": 10.0, "c": 15.0}
    assert pipelined_fps(stage_times) > sequential_fps(stage_times)


def test_latency_tracker_percentiles():
    tracker = LatencyTracker()
    for i in range(10):
        trace = tracker.new_trace(i)
        trace.mark("stage_a", 0.0, float(i + 1) * 10.0)
    percentiles = tracker.percentiles()
    assert percentiles["p50"] > 0
    assert percentiles["p99"] >= percentiles["p50"]
