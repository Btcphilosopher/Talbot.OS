"""
End-to-end smoke tests: run the *actual* VisionCoreEngine pipeline for a
few frames at a tiny preview resolution, and sanity-check the results.
These are intentionally light on precise numeric assertions (the unit
tests own that) and heavy on "did the whole pipeline run without
crashing and produce physically sane output."
"""
import numpy as np

from core.simulation_loop import run_simulation
from utils.config import CameraConfig


def test_full_pipeline_runs_and_produces_results(small_camera_config):
    engine, results, summary = run_simulation(small_camera_config, save_images_every=1, verbose=False)

    assert len(results) == small_camera_config.simulation.n_frames
    for r in results:
        assert r.mean_electrons >= 0.0
        assert 0.0 <= r.saturation_fraction <= 1.0
        assert r.frame_size_bytes > 0
        assert r.achievable_fps > 0
        assert 0.0 <= r.effective_resolution_factor <= 1.0
        assert r.images["final"].shape[-1] == 3
        assert np.all(np.isfinite(r.images["final"]))

    assert summary.n_frames == small_camera_config.simulation.n_frames
    assert summary.mean_snr_db > -100  # sane finite value


def test_low_light_scene_has_lower_snr_than_bright_scene():
    bright_cfg = CameraConfig()
    bright_cfg.simulation.n_frames = 2
    bright_cfg.simulation.preview_scale = 1.0 / 400.0
    bright_cfg.simulation.scene_type = "studio_gradient"
    bright_cfg.exposure.auto_exposure = False

    dark_cfg = CameraConfig()
    dark_cfg.simulation.n_frames = 2
    dark_cfg.simulation.preview_scale = 1.0 / 400.0
    dark_cfg.simulation.scene_type = "low_light"
    dark_cfg.exposure.auto_exposure = False

    _, bright_results, _ = run_simulation(bright_cfg, verbose=False)
    _, dark_results, _ = run_simulation(dark_cfg, verbose=False)

    assert np.mean([r.snr_db for r in bright_results]) > np.mean([r.snr_db for r in dark_results])


def test_higher_iso_increases_gain_and_can_reduce_dropped_frames_metric_present():
    cfg = CameraConfig()
    cfg.simulation.n_frames = 2
    cfg.simulation.preview_scale = 1.0 / 400.0
    cfg.exposure.iso = 12800
    cfg.exposure.auto_exposure = False

    _, results, summary = run_simulation(cfg, verbose=False)
    assert all(r.exposure_iso == 12800 for r in results)
    assert summary.dropped_frames >= 0


def test_storage_bottleneck_drops_frames_when_write_speed_too_low():
    cfg = CameraConfig()
    cfg.simulation.n_frames = 5
    cfg.simulation.preview_scale = 1.0 / 400.0
    cfg.storage.device_write_speed_mb_s = 0.001  # absurdly slow on purpose
    cfg.storage.buffer_capacity_frames = 1

    _, results, summary = run_simulation(cfg, verbose=False)
    assert summary.dropped_frames > 0


def test_metrics_recorder_has_expected_series(small_camera_config):
    engine, _, _ = run_simulation(small_camera_config, verbose=False)
    keys = engine.metrics.all_keys()
    assert "sensor.mean_electrons" in keys
    assert "performance.achievable_fps" in keys
    assert "compression.frame_size_mb" in keys
