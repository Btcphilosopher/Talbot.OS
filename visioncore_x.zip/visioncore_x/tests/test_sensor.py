import numpy as np

from physics import photon_noise
from sensor import cmos_model, dynamic_range, readout_noise
from sensor.pixel_array import PixelArray
from utils.config import SensorConfig


def test_pixel_pitch_shrinks_with_more_pixels():
    small = SensorConfig(resolution_preset="4K_UHD")
    large = SensorConfig(resolution_preset="16K_FUHD")
    assert large.pixel_pitch_um() < small.pixel_pitch_um()


def test_full_frame_readout_time_positive_and_scales_with_rows():
    cfg_4k = SensorConfig(resolution_preset="4K_UHD")
    cfg_16k = SensorConfig(resolution_preset="16K_FUHD")
    t4k = readout_noise.full_frame_readout_time_ms(cfg_4k)
    t16k = readout_noise.full_frame_readout_time_ms(cfg_16k)
    assert t4k > 0 and t16k > t4k  # more rows -> longer full-frame readout


def test_theoretical_max_fps_decreases_with_resolution():
    cfg_4k = SensorConfig(resolution_preset="4K_UHD")
    cfg_16k = SensorConfig(resolution_preset="16K_FUHD")
    assert readout_noise.theoretical_max_fps(cfg_16k) < readout_noise.theoretical_max_fps(cfg_4k)


def test_dynamic_range_positive_stops():
    cfg = SensorConfig()
    report = dynamic_range.compute_dynamic_range(cfg, adc_noise_e=0.9)
    assert report.dynamic_range_stops > 0
    assert report.dynamic_range_linear == cfg.full_well_capacity_e / report.noise_floor_e


def test_thermal_noise_penalty_increases_with_temperature():
    p_cold = cmos_model.thermal_noise_penalty(20.0)
    p_hot = cmos_model.thermal_noise_penalty(60.0)
    assert p_hot > p_cold
    assert cmos_model.thermal_noise_penalty(25.0) == 1.0


def test_shot_noise_std_matches_poisson_statistics():
    rng = np.random.default_rng(1)
    mean_photons = np.full((256, 256), 1000.0)
    samples = photon_noise.sample_shot_noise(mean_photons, rng)
    empirical_std = float(np.std(samples))
    expected_std = float(photon_noise.shot_noise_std(1000.0))
    assert abs(empirical_std - expected_std) / expected_std < 0.15


def test_pixel_array_capture_clips_at_full_well():
    cfg = SensorConfig(full_well_capacity_e=5000.0)
    arr = PixelArray(16, 16, cfg)
    huge_photon_map = np.full((16, 16), 1e7)
    electrons = arr.capture(huge_photon_map, exposure_time_s=0.01, die_temperature_c=25.0)
    assert np.all(electrons <= cfg.full_well_capacity_e)
    assert arr.saturation_fraction() > 0.9


def test_pixel_array_digital_output_in_range():
    cfg = SensorConfig(pixel_bit_depth=12)
    arr = PixelArray(16, 16, cfg)
    photon_map = np.full((16, 16), 3000.0)
    arr.capture(photon_map, exposure_time_s=0.01, die_temperature_c=25.0)
    digital = arr.to_digital(analog_gain_linear=1.0, adc_noise_e=0.9)
    assert digital.min() >= 0
    assert digital.max() <= (2 ** 12 - 1)
