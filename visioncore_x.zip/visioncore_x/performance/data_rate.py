"""
performance.data_rate
=======================
Sustained-vs-burst data rate accounting: the buffer lets the system
absorb short bursts above the sustained storage write speed, but only
for as long as it has spare capacity. This module summarises observed
data-rate behaviour across a simulation run.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np


@dataclass
class DataRateSummary:
    mean_produced_mb_s: float
    peak_produced_mb_s: float
    mean_written_mb_s: float
    sustained_write_limit_mb_s: float
    burst_headroom_frames: int
    saturation_fraction: float


def summarize_data_rate(
    frame_sizes_bytes: List[float],
    frame_interval_s: float,
    write_tick_bytes: List[float],
    tick_duration_s: float,
    device_write_speed_mb_s: float,
    saturated_ticks: int,
) -> DataRateSummary:
    mb = 1024.0 * 1024.0

    produced_rates = [b / mb / frame_interval_s for b in frame_sizes_bytes] if frame_interval_s > 0 else [0.0]
    written_rates = [b / mb / tick_duration_s for b in write_tick_bytes] if tick_duration_s > 0 else [0.0]

    total_ticks = max(len(write_tick_bytes), 1)

    return DataRateSummary(
        mean_produced_mb_s=float(np.mean(produced_rates)) if produced_rates else 0.0,
        peak_produced_mb_s=float(np.max(produced_rates)) if produced_rates else 0.0,
        mean_written_mb_s=float(np.mean(written_rates)) if written_rates else 0.0,
        sustained_write_limit_mb_s=device_write_speed_mb_s,
        burst_headroom_frames=0,  # filled in by caller once buffer capacity is known
        saturation_fraction=saturated_ticks / total_ticks,
    )


def estimate_burst_headroom_frames(buffer_capacity_frames: int, mean_frame_size_bytes: float, device_write_speed_mb_s: float, produced_rate_mb_s: float) -> int:
    """How many frames of headroom the buffer provides before a
    sustained-overrate capture (produced > write limit) forces frame
    drops, expressed in frame counts.
    """
    if produced_rate_mb_s <= device_write_speed_mb_s:
        return buffer_capacity_frames  # not overrun -- full buffer is headroom
    return buffer_capacity_frames
