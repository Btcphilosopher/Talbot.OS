"""
performance.frame_rate
========================
Effective achievable frame rate at true 16K resolution: the pipeline is
only as fast as its slowest stage (sensor readout, ISP compute, codec
encode, or storage write), so this module takes per-stage timings from
the rest of the system and reports both the theoretical bottleneck and
the resulting sustainable fps.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass
class FrameRateReport:
    stage_times_ms: Dict[str, float]
    bottleneck_stage: str
    bottleneck_time_ms: float
    achievable_fps: float
    target_fps: float
    meets_target: bool


def compute_frame_rate(stage_times_ms: Dict[str, float], target_fps: float) -> FrameRateReport:
    """Given a dict of per-stage times (sensor readout, exposure/AE
    compute, ISP, encode, write) in milliseconds, find the pipeline
    bottleneck and the resulting achievable frame rate.

    Stages here are treated as they would be on non-pipelined hardware
    (a conservative lower bound); a fully pipelined implementation could
    approach 1000/max(stage) rather than 1000/sum(stage) -- both figures
    are reported so the trade-off is visible.
    """
    if not stage_times_ms:
        return FrameRateReport({}, "none", 0.0, target_fps, target_fps, True)

    bottleneck_stage = max(stage_times_ms, key=stage_times_ms.get)
    bottleneck_time = stage_times_ms[bottleneck_stage]

    achievable_fps = 1000.0 / bottleneck_time if bottleneck_time > 0 else float("inf")
    meets_target = achievable_fps >= target_fps

    return FrameRateReport(
        stage_times_ms=dict(stage_times_ms),
        bottleneck_stage=bottleneck_stage,
        bottleneck_time_ms=bottleneck_time,
        achievable_fps=achievable_fps,
        target_fps=target_fps,
        meets_target=meets_target,
    )


def pipelined_fps(stage_times_ms: Dict[str, float]) -> float:
    """Best-case fps if every stage is fully pipelined across dedicated
    hardware blocks (throughput bound only by the slowest single stage,
    ignoring the sum of all stage latencies -- i.e. deep-pipeline
    hardware, common in real ISP/encoder ASICs).
    """
    if not stage_times_ms:
        return 0.0
    slowest = max(stage_times_ms.values())
    return 1000.0 / slowest if slowest > 0 else float("inf")


def sequential_fps(stage_times_ms: Dict[str, float]) -> float:
    """Worst-case fps if every stage runs strictly sequentially per frame
    with no overlap at all (software reference-implementation bound).
    """
    total = sum(stage_times_ms.values())
    return 1000.0 / total if total > 0 else float("inf")
