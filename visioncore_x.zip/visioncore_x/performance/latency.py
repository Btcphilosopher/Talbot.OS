"""
performance.latency
=====================
End-to-end pipeline latency tracking: per-stage timestamps for a single
frame's journey from photon capture to storage write, aggregated across
the simulation run into percentile statistics (p50/p95/p99) -- the
figures that actually matter for e.g. live-preview responsiveness or
broadcast-delay budgets, as opposed to average latency alone.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np


@dataclass
class FrameLatencyTrace:
    frame_index: int
    stage_start_ms: Dict[str, float] = field(default_factory=dict)
    stage_end_ms: Dict[str, float] = field(default_factory=dict)

    def mark(self, stage: str, start_ms: float, end_ms: float) -> None:
        self.stage_start_ms[stage] = start_ms
        self.stage_end_ms[stage] = end_ms

    def total_latency_ms(self) -> float:
        if not self.stage_end_ms:
            return 0.0
        return max(self.stage_end_ms.values()) - min(self.stage_start_ms.values())

    def stage_duration_ms(self, stage: str) -> float:
        return self.stage_end_ms.get(stage, 0.0) - self.stage_start_ms.get(stage, 0.0)


class LatencyTracker:
    def __init__(self) -> None:
        self._traces: List[FrameLatencyTrace] = []

    def new_trace(self, frame_index: int) -> FrameLatencyTrace:
        trace = FrameLatencyTrace(frame_index=frame_index)
        self._traces.append(trace)
        return trace

    def all_total_latencies_ms(self) -> np.ndarray:
        return np.array([t.total_latency_ms() for t in self._traces], dtype=np.float64)

    def percentiles(self, percentiles=(50, 95, 99)) -> Dict[str, float]:
        totals = self.all_total_latencies_ms()
        if totals.size == 0:
            return {f"p{p}": 0.0 for p in percentiles}
        return {f"p{p}": float(np.percentile(totals, p)) for p in percentiles}

    def stage_breakdown_ms(self) -> Dict[str, float]:
        """Mean duration per named stage across all recorded frames."""
        stage_totals: Dict[str, List[float]] = {}
        for trace in self._traces:
            for stage in trace.stage_start_ms:
                stage_totals.setdefault(stage, []).append(trace.stage_duration_ms(stage))
        return {stage: float(np.mean(vals)) for stage, vals in stage_totals.items()}

    def worst_frame(self) -> FrameLatencyTrace | None:
        if not self._traces:
            return None
        return max(self._traces, key=lambda t: t.total_latency_ms())
