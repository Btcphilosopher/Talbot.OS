"""
VISIONCORE-X -- 16K Camera System Simulator & Photonic Imaging Prototyper.

A modular, end-to-end digital twin of a next-generation 16K digital
camera system: optics -> sensor -> exposure -> ISP -> compression ->
storage, with physically-grounded noise, bandwidth and performance
modelling throughout.

See README.md for architecture and usage.
"""

__version__ = "1.0.0"
__all__ = ["__version__"]
