"""
core.engine
============
VisionCoreEngine wires every subsystem into the single-frame pipeline
described in the project brief:

    generate_scene -> apply_optical_model -> capture_photons(sensor) ->
    convert_to_electrical_signal -> process_image_pipeline ->
    compress_frame_if_needed -> write_to_storage ->
    update_performance_metrics -> optimise_camera_parameters

`run_frame` executes exactly one pass of that loop and returns a
FrameResult snapshot; core.simulation_loop drives it across N frames.

Resolution model: array-based stages (scene, sensor grid, ISP) operate
on a downscaled "preview" grid (resolution.resolution_engine); all
timing/bandwidth/dynamic-range figures are computed analytically at the
*true* 16K sensor resolution from utils.config.SensorConfig, independent
of the preview array size. See resolution/resolution_engine.py.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np

from compression import bandwidth_model, image_codec
from compression.encoder_16k import estimate_encode_time, keyframe_overhead_factor
from core.frame_clock import FrameClock
from imaging import exposure as exposure_mod
from imaging import iso_gain
from imaging.colour_filter_array import mosaic as cfa_mosaic
from imaging.white_balance import apply_white_balance, estimate_gains
from optics import lens_model
from optics.diffraction import diffraction_blur_kernel
from optimisation.exposure_optimizer import optimize_exposure
from performance import frame_rate as frame_rate_mod
from performance.latency import LatencyTracker
from physics import light_transport, photon_noise
from resolution.aliasing_model import analyze_aliasing
from resolution.resolution_engine import build_preview_grid, compute_effective_resolution
from sensor import cmos_model, dynamic_range, readout_noise
from sensor.pixel_array import PixelArray
from signal_processing.demosaic import demosaic, convolve_same
from signal_processing.noise_reduction import denoise, estimate_noise_std
from signal_processing.sharpening import unsharp_mask
from storage.write_pipeline import WritePipeline
from utils.config import CameraConfig
from utils.logging import MetricsRecorder, get_logger
from workload.motion_simulation import (
    apply_motion_blur,
    generate_motion_profile,
    inject_moving_object,
)
from workload.scene_generator import generate_scene

logger = get_logger("core.engine")

# Baseline ISP compute throughput, in megapixels/second, for the combined
# demosaic + white-balance + denoise + sharpen chain on representative
# modern ISP hardware -- used to derive an analytical (resolution-scale-
# independent) ISP stage time for the performance/frame-rate model.
ISP_BASE_THROUGHPUT_MP_S = 900.0


@dataclass
class FrameResult:
    frame_index: int
    timestamp_s: float
    exposure_iso: int
    exposure_shutter_s: float
    metered_intensity: float
    mean_electrons: float
    saturation_fraction: float
    snr_db: float
    dynamic_range_stops: float
    effective_megapixels: float
    effective_resolution_factor: float
    aliasing_severity: float
    frame_size_bytes: float
    compression_ratio: float
    encode_time_ms: float
    stage_times_ms: Dict[str, float]
    bottleneck_stage: str
    achievable_fps: float
    buffer_occupancy_pct: float
    frame_dropped: bool
    total_latency_ms: float
    die_temperature_c: float
    images: Dict[str, np.ndarray] = field(default_factory=dict)


class VisionCoreEngine:
    def __init__(self, cam_cfg: CameraConfig) -> None:
        self.cfg = cam_cfg
        self.rng = np.random.default_rng(cam_cfg.simulation.random_seed)
        self.clock = FrameClock(cam_cfg.simulation.frame_rate_target_fps)

        self.preview = build_preview_grid(cam_cfg)
        self.pixel_array = PixelArray(self.preview.preview_height, self.preview.preview_width, cam_cfg.sensor)
        self.write_pipeline = WritePipeline(cam_cfg.storage)
        self.latency_tracker = LatencyTracker()
        self.metrics = MetricsRecorder()

        self._motion_profile = generate_motion_profile(
            cam_cfg.simulation.n_frames, cam_cfg.simulation.motion_type, self.rng
        )

        # True-sensor physical constants, reused every frame.
        self._true_pixel_area_m2 = cmos_model.pixel_area_m2(cam_cfg.sensor.pixel_pitch_um())
        # Physical size (in microns) that one *preview* grid site spans,
        # used only to size spatially-relative kernels (diffraction /
        # motion blur) correctly on the coarser preview array.
        self._preview_pixel_pitch_um = cam_cfg.sensor.pixel_pitch_um() / max(cam_cfg.simulation.preview_scale, 1e-6)

    # -- pipeline stages -----------------------------------------------

    def _apply_optical_model(self, scene: np.ndarray) -> np.ndarray:
        """Diffraction blur + (vignetting is applied later, inside
        light_transport.scene_to_photon_map, since it acts on irradiance).
        """
        kernel = diffraction_blur_kernel(
            self.cfg.lens.f_number,
            self._preview_pixel_pitch_um,
            size=7,
        )
        blurred = np.stack([convolve_same(scene[..., c], kernel) for c in range(scene.shape[2])], axis=-1)
        return blurred

    def _capture_photons(self, scene_after_optics: np.ndarray) -> np.ndarray:
        return light_transport.scene_to_photon_map(
            scene_after_optics,
            f_number=self.cfg.lens.f_number,
            transmission=self.cfg.lens.transmission,
            vignetting_strength=self.cfg.lens.vignetting_strength,
            pixel_area_m2=self._true_pixel_area_m2,
            exposure_time_s=self.cfg.exposure.shutter_speed_s,
        )

    def _convert_to_electrical_signal(self, photon_map_rgb: np.ndarray, die_temp_c: float):
        raw_photon_mosaic = cfa_mosaic(photon_map_rgb)
        electrons = self.pixel_array.capture(
            raw_photon_mosaic, self.cfg.exposure.shutter_speed_s, die_temp_c, self.rng
        )
        gain_profile = iso_gain.build_gain_profile(self.cfg.exposure.iso, self.cfg.sensor)
        digital_raw = self.pixel_array.to_digital(
            gain_profile.analog_gain_linear, self.cfg.sensor.adc_noise_e, self.rng
        )
        return electrons, digital_raw, gain_profile

    def _process_image_pipeline(self, digital_raw: np.ndarray) -> np.ndarray:
        max_code = (2 ** self.cfg.sensor.pixel_bit_depth) - 1
        raw_norm = digital_raw.astype(np.float64) / max_code

        demosaiced = demosaic(raw_norm, method=self.cfg.processing.demosaic_method)

        wb_gains = estimate_gains(demosaiced, self.cfg.processing)
        wb_image = apply_white_balance(demosaiced, wb_gains)

        noise_std = estimate_noise_std(wb_image)
        denoised = denoise(wb_image, self.cfg.processing.denoise_strength, noise_std)

        sharpened = unsharp_mask(
            denoised, self.cfg.processing.sharpening_amount, self.cfg.processing.sharpening_radius_px
        )
        return np.clip(sharpened, 0.0, 1.0)

    # -- top-level per-frame pipeline -----------------------------------

    def run_frame(self, frame_index: int, save_images: bool = False) -> FrameResult:
        cfg = self.cfg
        timestamp = self.clock.tick()
        trace = self.latency_tracker.new_trace(frame_index)
        t = 0.0  # cumulative analytical stage time, ms

        # 1. generate_scene()
        scene = generate_scene(cfg.simulation.scene_type, self.preview.preview_height, self.preview.preview_width)
        motion_state = self._motion_profile[frame_index % len(self._motion_profile)]
        scene = inject_moving_object(scene, frame_index, cfg.simulation.n_frames) if cfg.simulation.scene_type != "low_light" else scene

        # 2. apply_optical_model()
        t0 = t
        scene = self._apply_optical_model(scene)
        motion_blur_px = abs(motion_state.pan_deg_s) * cfg.exposure.shutter_speed_s * 4.0
        if motion_blur_px > 0.5:
            scene = apply_motion_blur(scene, motion_blur_px)
        t += 0.4  # negligible analytically vs. readout/encode; small fixed overhead
        trace.mark("optics", t0, t)

        # 3. capture_photons(sensor)
        photon_map = self._capture_photons(scene)

        # 4. convert_to_electrical_signal()
        t0 = t
        die_profile = cmos_model.build_die_profile(cfg.sensor, cfg.simulation.frame_rate_target_fps)
        electrons, digital_raw, gain_profile = self._convert_to_electrical_signal(photon_map, die_profile.die_temperature_c)
        readout_ms = readout_noise.full_frame_readout_time_ms(cfg.sensor)
        t += readout_ms
        trace.mark("sensor_readout", t0, t)

        # 5. process_image_pipeline() (ISP)
        t0 = t
        final_image = self._process_image_pipeline(digital_raw)
        true_mp = cfg.sensor.megapixels()
        isp_time_ms = (true_mp / ISP_BASE_THROUGHPUT_MP_S) * 1000.0
        t += isp_time_ms
        trace.mark("isp", t0, t)

        # 6. compress_frame_if_needed()
        t0 = t
        encode_estimate = estimate_encode_time(cfg.sensor, cfg.compression, cfg.simulation.parallel_encode_workers)
        overhead = keyframe_overhead_factor(cfg.compression, frame_index)
        encode_time_ms = encode_estimate.parallel_total_time_ms * overhead
        t += encode_time_ms
        trace.mark("encode", t0, t)
        frame_size_bytes = encode_estimate.output_frame_size_bytes

        # 7. write_to_storage()
        t0 = t
        accepted = self.write_pipeline.submit_frame(frame_index, frame_size_bytes, timestamp)
        write_result = self.write_pipeline.drain_tick(frame_index, self.clock.frame_interval_s)
        write_time_ms = bandwidth_model.required_data_rate_mb_s(frame_size_bytes, 1.0) / max(
            cfg.storage.device_write_speed_mb_s, 1e-6
        ) * 1000.0
        t += write_time_ms
        trace.mark("write", t0, t)

        # 8. update_performance_metrics()
        stage_times_ms = {
            "sensor_readout": readout_ms,
            "isp": isp_time_ms,
            "encode": encode_time_ms,
            "write": write_time_ms,
        }
        fps_report = frame_rate_mod.compute_frame_rate(stage_times_ms, cfg.simulation.frame_rate_target_fps)

        mean_e = self.pixel_array.mean_electrons()
        snr_linear = photon_noise.photon_transfer_snr(mean_e, cfg.sensor.read_noise_e, cfg.sensor.dark_current_e_per_s_25c)
        snr_db_val = float(photon_noise.snr_db(snr_linear))

        dr_report = dynamic_range.compute_dynamic_range(cfg.sensor, cfg.sensor.adc_noise_e)
        optical_perf = lens_model.evaluate_optical_performance(cfg.lens, cfg.sensor.pixel_pitch_um())
        aliasing_report = analyze_aliasing(final_image.mean(axis=2), cfg.sensor)
        eff_res = compute_effective_resolution(cfg, optical_perf, snr_db_val, aliasing_report.aliasing_severity)

        comp_ratio = image_codec.compression_ratio(cfg.sensor, cfg.compression)

        # 9. optimise_camera_parameters()
        metered = exposure_mod.meter_frame(final_image)
        if cfg.exposure.auto_exposure:
            optimize_exposure(cfg, lambda c: metered, max_iterations=1)

        result = FrameResult(
            frame_index=frame_index,
            timestamp_s=timestamp,
            exposure_iso=cfg.exposure.iso,
            exposure_shutter_s=cfg.exposure.shutter_speed_s,
            metered_intensity=metered,
            mean_electrons=mean_e,
            saturation_fraction=self.pixel_array.saturation_fraction(),
            snr_db=snr_db_val,
            dynamic_range_stops=dr_report.dynamic_range_stops,
            effective_megapixels=eff_res.effective_megapixels,
            effective_resolution_factor=eff_res.effective_factor,
            aliasing_severity=aliasing_report.aliasing_severity,
            frame_size_bytes=frame_size_bytes,
            compression_ratio=comp_ratio,
            encode_time_ms=encode_time_ms,
            stage_times_ms=stage_times_ms,
            bottleneck_stage=fps_report.bottleneck_stage,
            achievable_fps=fps_report.achievable_fps,
            buffer_occupancy_pct=write_result.buffer_occupancy_pct,
            frame_dropped=not accepted,
            total_latency_ms=trace.total_latency_ms(),
            die_temperature_c=die_profile.die_temperature_c,
        )

        if save_images:
            result.images = {
                "raw_mosaic": digital_raw.astype(np.float64),
                "final": final_image,
                "electrons": self.pixel_array.electrons.copy(),
                # Captured now, not read back later: pixel_array's mask is
                # mutable live state that the *next* frame's capture()
                # will overwrite, so any consumer reading it post-loop
                # would silently see the last frame's mask instead of
                # this one's.
                "saturated_mask": self.pixel_array.saturated_mask.copy(),
            }

        self._record_metrics(result)
        return result

    def _record_metrics(self, r: FrameResult) -> None:
        m = self.metrics
        i = r.frame_index
        m.record(i, "exposure", "iso", r.exposure_iso)
        m.record(i, "exposure", "shutter_s", r.exposure_shutter_s)
        m.record(i, "sensor", "mean_electrons", r.mean_electrons)
        m.record(i, "sensor", "saturation_fraction", r.saturation_fraction)
        m.record(i, "sensor", "snr_db", r.snr_db)
        m.record(i, "sensor", "dynamic_range_stops", r.dynamic_range_stops)
        m.record(i, "sensor", "die_temperature_c", r.die_temperature_c)
        m.record(i, "resolution", "effective_megapixels", r.effective_megapixels)
        m.record(i, "resolution", "effective_factor", r.effective_resolution_factor)
        m.record(i, "resolution", "aliasing_severity", r.aliasing_severity)
        m.record(i, "compression", "frame_size_mb", r.frame_size_bytes / (1024 * 1024))
        m.record(i, "compression", "ratio", r.compression_ratio)
        m.record(i, "compression", "encode_time_ms", r.encode_time_ms)
        m.record(i, "performance", "achievable_fps", r.achievable_fps)
        m.record(i, "performance", "total_latency_ms", r.total_latency_ms)
        m.record(i, "storage", "buffer_occupancy_pct", r.buffer_occupancy_pct)
        m.record(i, "storage", "frame_dropped", int(r.frame_dropped))
