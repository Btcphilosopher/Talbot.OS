"""VISIONCORE-X :: core package."""
