"""
core.simulation_loop
======================
Drives core.engine.VisionCoreEngine across the configured number of
frames, exactly per the project brief's pseudocode:

    for frame in simulation:
        generate_scene()
        apply_optical_model()
        capture_photons(sensor)
        convert_to_electrical_signal()
        process_image_pipeline()
        compress_frame_if_needed()
        write_to_storage()
        update_performance_metrics()
        optimise_camera_parameters()

(all of which live inside VisionCoreEngine.run_frame; this module is the
thin driver + summary-report layer.)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np

from core.engine import FrameResult, VisionCoreEngine
from utils.config import CameraConfig
from utils.logging import get_logger

logger = get_logger("core.simulation_loop")


@dataclass
class SimulationSummary:
    n_frames: int
    mean_achievable_fps: float
    mean_snr_db: float
    mean_dynamic_range_stops: float
    mean_effective_megapixels: float
    nominal_megapixels: float
    mean_frame_size_mb: float
    mean_compression_ratio: float
    total_data_written_gb: float
    dropped_frames: int
    p50_latency_ms: float
    p95_latency_ms: float
    p99_latency_ms: float
    mean_die_temperature_c: float


def run_simulation(cam_cfg: CameraConfig, save_images_every: int = 0, verbose: bool = True) -> tuple:
    """Run the full frame loop. Returns (engine, list[FrameResult],
    SimulationSummary). `save_images_every` > 0 retains rendered arrays
    on every Nth frame (0 = never, saves memory for long runs).
    """
    engine = VisionCoreEngine(cam_cfg)
    results: List[FrameResult] = []

    n_frames = cam_cfg.simulation.n_frames
    for i in range(n_frames):
        save_images = save_images_every > 0 and (i % save_images_every == 0)
        result = engine.run_frame(i, save_images=save_images)
        results.append(result)

        if verbose and (i % max(n_frames // 10, 1) == 0 or i == n_frames - 1):
            logger.info(
                "frame %4d/%-4d | ISO %5d 1/%-5.0fs | SNR %5.1fdB | "
                "eff.res %5.1fMP (%4.0f%%) | fps %5.1f | frame %6.1fMB | "
                "buf %4.0f%% | %s",
                i + 1,
                n_frames,
                result.exposure_iso,
                1.0 / result.exposure_shutter_s,
                result.snr_db,
                result.effective_megapixels,
                result.effective_resolution_factor * 100.0,
                result.achievable_fps,
                result.frame_size_bytes / (1024 * 1024),
                result.buffer_occupancy_pct,
                "DROPPED" if result.frame_dropped else "ok",
            )

    summary = summarize(cam_cfg, results, engine)
    return engine, results, summary


def summarize(cam_cfg: CameraConfig, results: List[FrameResult], engine: VisionCoreEngine) -> SimulationSummary:
    if not results:
        raise ValueError("No frame results to summarize")

    fps = np.array([r.achievable_fps for r in results])
    snr = np.array([r.snr_db for r in results])
    dr = np.array([r.dynamic_range_stops for r in results])
    eff_mp = np.array([r.effective_megapixels for r in results])
    size_mb = np.array([r.frame_size_bytes / (1024 * 1024) for r in results])
    ratio = np.array([r.compression_ratio for r in results])
    dropped = sum(1 for r in results if r.frame_dropped)
    temps = np.array([r.die_temperature_c for r in results])

    latency_pct = engine.latency_tracker.percentiles()
    total_bytes = sum(r.frame_size_bytes for r in results)

    return SimulationSummary(
        n_frames=len(results),
        mean_achievable_fps=float(np.mean(fps)),
        mean_snr_db=float(np.mean(snr)),
        mean_dynamic_range_stops=float(np.mean(dr)),
        mean_effective_megapixels=float(np.mean(eff_mp)),
        nominal_megapixels=cam_cfg.sensor.megapixels(),
        mean_frame_size_mb=float(np.mean(size_mb)),
        mean_compression_ratio=float(np.mean(ratio)),
        total_data_written_gb=total_bytes / (1024 ** 3),
        dropped_frames=dropped,
        p50_latency_ms=latency_pct["p50"],
        p95_latency_ms=latency_pct["p95"],
        p99_latency_ms=latency_pct["p99"],
        mean_die_temperature_c=float(np.mean(temps)),
    )


def print_summary(summary: SimulationSummary) -> None:
    print("=" * 72)
    print("VISIONCORE-X SIMULATION SUMMARY")
    print("=" * 72)
    print(f"  Frames simulated:            {summary.n_frames}")
    print(f"  Nominal sensor resolution:   {summary.nominal_megapixels:.1f} MP (true 16K)")
    print(f"  Mean effective resolution:   {summary.mean_effective_megapixels:.1f} MP "
          f"({100*summary.mean_effective_megapixels/summary.nominal_megapixels:.1f}% of nominal)")
    print(f"  Mean SNR:                    {summary.mean_snr_db:.1f} dB")
    print(f"  Mean dynamic range:          {summary.mean_dynamic_range_stops:.1f} stops")
    print(f"  Mean achievable frame rate:  {summary.mean_achievable_fps:.2f} fps")
    print(f"  Mean compressed frame size:  {summary.mean_frame_size_mb:.1f} MB")
    print(f"  Mean compression ratio:      {summary.mean_compression_ratio:.1f}x")
    print(f"  Total data written:          {summary.total_data_written_gb:.2f} GB")
    print(f"  Dropped frames:              {summary.dropped_frames}")
    print(f"  Latency p50/p95/p99 (ms):    {summary.p50_latency_ms:.1f} / "
          f"{summary.p95_latency_ms:.1f} / {summary.p99_latency_ms:.1f}")
    print(f"  Mean sensor die temperature: {summary.mean_die_temperature_c:.1f} C")
    print("=" * 72)
