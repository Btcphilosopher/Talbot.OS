"""
core.frame_clock
==================
Tracks simulated (not wall-clock) time as the frame loop advances,
independent of how long the host machine actually takes to compute each
frame -- so performance metrics describe the *simulated camera's*
behaviour, not this process's CPU speed.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class FrameClock:
    frame_rate_target_fps: float
    frame_index: int = 0
    simulated_time_s: float = 0.0
    _frame_timestamps_s: List[float] = field(default_factory=list)

    @property
    def frame_interval_s(self) -> float:
        return 1.0 / self.frame_rate_target_fps if self.frame_rate_target_fps > 0 else 0.0

    def tick(self) -> float:
        """Advance the clock by one nominal frame interval and return the
        new simulated timestamp.
        """
        self.simulated_time_s += self.frame_interval_s
        self._frame_timestamps_s.append(self.simulated_time_s)
        self.frame_index += 1
        return self.simulated_time_s

    def timestamps(self) -> List[float]:
        return list(self._frame_timestamps_s)

    def elapsed_s(self) -> float:
        return self.simulated_time_s

    def reset(self) -> None:
        self.frame_index = 0
        self.simulated_time_s = 0.0
        self._frame_timestamps_s.clear()
