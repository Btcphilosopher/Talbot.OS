"""
workload.scene_generator
==========================
Procedural test-scene generation. Produces (H, W, 3) linear-light scene
luminance maps (candela/m^2-ish arbitrary units, scaled by a configurable
brightness) at the preview grid resolution, used as ground truth input
to physics.light_transport. Includes several canonical camera test
patterns plus a simple "studio" gradient/object scene for general use.
"""
from __future__ import annotations

import numpy as np


def studio_gradient_scene(height: int, width: int, mean_luminance_cd_m2: float = 200.0) -> np.ndarray:
    """A smooth gradient + soft vignette 'product shot' style scene with
    mild colour variation -- a reasonable general-purpose default.
    """
    yy, xx = np.mgrid[0:height, 0:width].astype(np.float64)
    gradient = 0.4 + 0.6 * (xx / max(width - 1, 1))
    vertical = 0.85 + 0.15 * (yy / max(height - 1, 1))
    base = gradient * vertical

    scene = np.stack(
        [
            base * 1.00,
            base * 0.96,
            base * 0.90,
        ],
        axis=-1,
    )
    return scene * mean_luminance_cd_m2


def checkerboard_scene(height: int, width: int, tile_px: int = 24, mean_luminance_cd_m2: float = 200.0) -> np.ndarray:
    """High-frequency checkerboard -- stresses aliasing/moire and
    resolution-limit analysis.
    """
    yy, xx = np.mgrid[0:height, 0:width]
    pattern = ((yy // tile_px) + (xx // tile_px)) % 2
    intensity = np.where(pattern == 0, 0.9, 0.1)
    scene = np.repeat(intensity[..., None], 3, axis=2)
    return scene * mean_luminance_cd_m2


def resolution_chart_scene(height: int, width: int, mean_luminance_cd_m2: float = 200.0) -> np.ndarray:
    """Radial zone-plate chart -- classic resolution/MTF test target,
    reused from resolution.aliasing_model's synthesis helper.
    """
    from resolution.aliasing_model import synthesize_moire_test_pattern

    pattern = synthesize_moire_test_pattern(height, width, frequency_cycles_per_px=0.5)
    scene = np.repeat(pattern[..., None], 3, axis=2)
    return scene * mean_luminance_cd_m2


def low_light_scene(height: int, width: int, mean_luminance_cd_m2: float = 2.0) -> np.ndarray:
    """Dim scene with a few bright point sources (streetlights at night
    style) -- stresses noise and dynamic-range handling.
    """
    rng = np.random.default_rng(7)
    base = np.full((height, width, 3), mean_luminance_cd_m2, dtype=np.float64)
    n_sources = max(int(0.0008 * height * width), 3)
    for _ in range(n_sources):
        cy, cx = rng.integers(0, height), rng.integers(0, width)
        radius = rng.integers(2, max(height, width) // 40 + 3)
        yy, xx = np.mgrid[0:height, 0:width]
        d2 = (yy - cy) ** 2 + (xx - cx) ** 2
        glow = np.exp(-d2 / (2.0 * radius ** 2)) * mean_luminance_cd_m2 * 400.0
        base += glow[..., None]
    return base


def high_contrast_hdr_scene(height: int, width: int) -> np.ndarray:
    """Split scene: bright sunlit half, dark shadowed half -- stresses
    the HDR fusion pipeline and dynamic-range headroom reporting.
    """
    yy, xx = np.mgrid[0:height, 0:width].astype(np.float64)
    bright = 8000.0
    dark = 8.0
    split = xx / max(width - 1, 1)
    luminance = dark + (bright - dark) * (split ** 3)
    return np.repeat(luminance[..., None], 3, axis=2)


SCENE_GENERATORS = {
    "studio_gradient": studio_gradient_scene,
    "checkerboard": checkerboard_scene,
    "resolution_chart": resolution_chart_scene,
    "low_light": low_light_scene,
    "high_contrast_hdr": high_contrast_hdr_scene,
}


def generate_scene(scene_type: str, height: int, width: int, **kwargs) -> np.ndarray:
    if scene_type not in SCENE_GENERATORS:
        raise ValueError(f"Unknown scene_type '{scene_type}'. Options: {list(SCENE_GENERATORS)}")
    return SCENE_GENERATORS[scene_type](height, width, **kwargs)
