"""
workload.motion_simulation
============================
Camera and scene motion: generates per-frame camera pose deltas (pan/
tilt/shake), applies resulting motion blur (via convolution with a
motion kernel) and feeds rolling-shutter shear parameters derived from
the same motion. Also supports simple moving-object overlays.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class CameraMotionState:
    pan_deg_s: float
    tilt_deg_s: float
    shake_amplitude_deg: float
    handheld: bool


def generate_motion_profile(n_frames: int, motion_type: str = "static", rng: np.random.Generator | None = None) -> list:
    """Produce a per-frame list of CameraMotionState describing simulated
    camera movement across the sequence.
    """
    rng = rng or np.random.default_rng(11)
    states = []

    for i in range(n_frames):
        if motion_type == "static":
            states.append(CameraMotionState(0.0, 0.0, 0.0, handheld=False))
        elif motion_type == "pan":
            states.append(CameraMotionState(pan_deg_s=25.0, tilt_deg_s=0.0, shake_amplitude_deg=0.0, handheld=False))
        elif motion_type == "handheld":
            jitter = rng.normal(0, 0.6, size=2)
            states.append(
                CameraMotionState(
                    pan_deg_s=float(jitter[0]),
                    tilt_deg_s=float(jitter[1]),
                    shake_amplitude_deg=0.35,
                    handheld=True,
                )
            )
        elif motion_type == "whip_pan":
            # Ramp up then down across the sequence -- stresses rolling
            # shutter skew and motion blur extent simultaneously.
            t = i / max(n_frames - 1, 1)
            rate = 180.0 * np.sin(np.pi * t)
            states.append(CameraMotionState(pan_deg_s=rate, tilt_deg_s=0.0, shake_amplitude_deg=0.0, handheld=False))
        else:
            raise ValueError(f"Unknown motion_type '{motion_type}'")

    return states


def motion_blur_kernel(extent_px: float, angle_deg: float = 0.0, size: int | None = None) -> np.ndarray:
    """Directional line-blur kernel of the given extent (in pixels) and
    angle, approximating linear motion blur from an exposure captured
    during constant-velocity camera/subject motion.
    """
    extent_px = max(abs(extent_px), 0.5)
    ksize = size or (2 * int(np.ceil(extent_px / 2.0)) + 1)
    kernel = np.zeros((ksize, ksize), dtype=np.float64)
    center = ksize // 2
    theta = np.radians(angle_deg)

    n_samples = max(int(extent_px * 2), 2)
    for t in np.linspace(-extent_px / 2.0, extent_px / 2.0, n_samples):
        x = int(round(center + t * np.cos(theta)))
        y = int(round(center + t * np.sin(theta)))
        if 0 <= x < ksize and 0 <= y < ksize:
            kernel[y, x] += 1.0

    total = kernel.sum()
    if total > 0:
        kernel /= total
    else:
        kernel[center, center] = 1.0
    return kernel


def apply_motion_blur(image: np.ndarray, extent_px: float, angle_deg: float = 0.0) -> np.ndarray:
    from signal_processing.demosaic import convolve_same

    if extent_px < 0.5:
        return image.copy()

    kernel = motion_blur_kernel(extent_px, angle_deg)
    if image.ndim == 3:
        out = np.stack([convolve_same(image[..., c], kernel) for c in range(image.shape[2])], axis=-1)
    else:
        out = convolve_same(image, kernel)
    return out


def inject_moving_object(scene: np.ndarray, frame_index: int, n_frames: int, size_px: int = 40, brightness: float = 3000.0) -> np.ndarray:
    """Overlay a bright object sweeping horizontally across the scene
    across the sequence -- useful for visually demonstrating motion blur
    and rolling-shutter skew together.
    """
    h, w = scene.shape[:2]
    t = frame_index / max(n_frames - 1, 1)
    cx = int(t * (w - 1))
    cy = h // 2

    out = scene.copy()
    yy, xx = np.mgrid[0:h, 0:w]
    d2 = (yy - cy) ** 2 + (xx - cx) ** 2
    glow = np.exp(-d2 / (2.0 * (size_px / 2.0) ** 2)) * brightness
    out += glow[..., None]
    return out
