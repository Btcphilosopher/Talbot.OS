"""
storage.buffer_manager
========================
A finite-depth FIFO ring buffer standing in for the camera's onboard
frame RAM: captured/compressed frames are pushed in as they're produced
and drained out by the write pipeline. If capture rate persistently
exceeds drain rate, the buffer fills and the camera must either drop
frames or stall capture -- both are modelled explicitly here rather than
assumed away.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Optional


@dataclass
class BufferedFrame:
    frame_index: int
    size_bytes: float
    timestamp_s: float


@dataclass
class BufferStats:
    capacity_frames: int
    occupied_frames: int
    occupancy_pct: float
    overflowed: bool
    dropped_frame_count: int
    total_frames_pushed: int


class FrameBuffer:
    """Ring buffer of pending frames awaiting storage write."""

    def __init__(self, capacity_frames: int) -> None:
        self.capacity_frames = max(capacity_frames, 1)
        self._queue: Deque[BufferedFrame] = deque()
        self.dropped_frame_count = 0
        self.total_frames_pushed = 0
        self.total_bytes_dropped = 0.0

    def push(self, frame: BufferedFrame) -> bool:
        """Attempt to enqueue a frame. Returns False (and records a drop)
        if the buffer is already at capacity -- modelling a camera that
        cannot capture faster than it can (eventually) write out.
        """
        self.total_frames_pushed += 1
        if len(self._queue) >= self.capacity_frames:
            self.dropped_frame_count += 1
            self.total_bytes_dropped += frame.size_bytes
            return False
        self._queue.append(frame)
        return True

    def pop(self) -> Optional[BufferedFrame]:
        if not self._queue:
            return None
        return self._queue.popleft()

    def peek_bytes_pending(self) -> float:
        return sum(f.size_bytes for f in self._queue)

    def stats(self) -> BufferStats:
        occ = len(self._queue)
        return BufferStats(
            capacity_frames=self.capacity_frames,
            occupied_frames=occ,
            occupancy_pct=100.0 * occ / self.capacity_frames,
            overflowed=occ >= self.capacity_frames,
            dropped_frame_count=self.dropped_frame_count,
            total_frames_pushed=self.total_frames_pushed,
        )

    def drop_rate(self) -> float:
        if self.total_frames_pushed == 0:
            return 0.0
        return self.dropped_frame_count / self.total_frames_pushed
