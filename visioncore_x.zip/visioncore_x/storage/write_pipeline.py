"""
storage.write_pipeline
========================
Drains storage.buffer_manager.FrameBuffer at the configured device write
speed, tracking whether sustained writes can keep pace with capture. Each
simulated "tick" corresponds to one frame interval; the write pipeline
drains as many bytes as the device can sustain in that interval.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from storage.buffer_manager import BufferedFrame, FrameBuffer
from utils.config import StorageConfig


@dataclass
class WriteTickResult:
    frame_index: int
    bytes_written: float
    frames_drained: int
    buffer_occupancy_pct: float
    write_saturated: bool  # True if the device wrote at its max sustained rate


class WritePipeline:
    def __init__(self, storage_cfg: StorageConfig) -> None:
        self.storage_cfg = storage_cfg
        self.buffer = FrameBuffer(storage_cfg.buffer_capacity_frames)
        self.total_bytes_written = 0.0
        self._history: List[WriteTickResult] = []

    def submit_frame(self, frame_index: int, size_bytes: float, timestamp_s: float) -> bool:
        return self.buffer.push(BufferedFrame(frame_index, size_bytes, timestamp_s))

    def drain_tick(self, frame_index: int, tick_duration_s: float) -> WriteTickResult:
        """Drain the buffer for one frame interval's worth of wall time at
        the device's sustained write speed.
        """
        budget_bytes = self.storage_cfg.device_write_speed_mb_s * 1024.0 * 1024.0 * tick_duration_s
        written = 0.0
        drained = 0
        saturated = False

        while budget_bytes > 0:
            pending = self.buffer.peek_bytes_pending()
            if pending <= 0:
                break
            next_frame = self.buffer.pop()
            if next_frame is None:
                break
            if next_frame.size_bytes <= budget_bytes:
                budget_bytes -= next_frame.size_bytes
                written += next_frame.size_bytes
                drained += 1
            else:
                # Partial write: not enough budget to finish this frame this
                # tick -- push it back to the front conceptually by
                # re-inserting at head via a temporary buffer, and stop.
                self.buffer._queue.appendleft(next_frame)  # noqa: SLF001 (internal, same-package cooperation)
                saturated = True
                break

        if self.buffer.stats().occupied_frames > 0 and budget_bytes <= 0:
            saturated = True

        self.total_bytes_written += written
        result = WriteTickResult(
            frame_index=frame_index,
            bytes_written=written,
            frames_drained=drained,
            buffer_occupancy_pct=self.buffer.stats().occupancy_pct,
            write_saturated=saturated,
        )
        self._history.append(result)
        return result

    def history(self) -> List[WriteTickResult]:
        return list(self._history)

    def total_dropped_frames(self) -> int:
        return self.buffer.dropped_frame_count
