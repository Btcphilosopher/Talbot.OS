"""
imaging.white_balance
=======================
White balance gain estimation and application. Supports a "gray world"
auto-WB estimator (assume the scene averages to neutral grey) and a
correlated-colour-temperature (CCT) preset table for manual/preset modes.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from utils.config import ProcessingConfig

# Approximate RGB multipliers for common colour temperatures (normalised
# so the green channel gain is always 1.0), covering the classic daylight
# / tungsten / shade presets used in real camera menus.
_CCT_PRESETS_K = {
    2800: (0.62, 1.0, 1.85),   # tungsten
    4000: (0.78, 1.0, 1.55),   # fluorescent
    5600: (1.00, 1.0, 1.05),   # daylight
    6500: (1.08, 1.0, 0.95),   # overcast
    7500: (1.22, 1.0, 0.80),   # shade
}


@dataclass
class WhiteBalanceGains:
    r_gain: float
    g_gain: float
    b_gain: float


def gray_world_gains(mosaic_or_rgb: np.ndarray) -> WhiteBalanceGains:
    """Estimate WB gains assuming the scene average should be neutral
    grey: gain_c = mean(G) / mean(C).
    """
    if mosaic_or_rgb.ndim != 3 or mosaic_or_rgb.shape[-1] != 3:
        raise ValueError("gray_world_gains expects an (H, W, 3) RGB image")

    means = mosaic_or_rgb.reshape(-1, 3).mean(axis=0)
    means = np.clip(means, 1e-6, None)
    g_mean = means[1]
    return WhiteBalanceGains(
        r_gain=float(g_mean / means[0]),
        g_gain=1.0,
        b_gain=float(g_mean / means[2]),
    )


def preset_gains(colour_temp_k: float) -> WhiteBalanceGains:
    """Interpolate WB gains from the CCT preset table for the requested
    colour temperature.
    """
    temps = sorted(_CCT_PRESETS_K.keys())
    if colour_temp_k <= temps[0]:
        r, g, b = _CCT_PRESETS_K[temps[0]]
        return WhiteBalanceGains(r, g, b)
    if colour_temp_k >= temps[-1]:
        r, g, b = _CCT_PRESETS_K[temps[-1]]
        return WhiteBalanceGains(r, g, b)

    for lo, hi in zip(temps, temps[1:]):
        if lo <= colour_temp_k <= hi:
            frac = (colour_temp_k - lo) / (hi - lo)
            r_lo, g_lo, b_lo = _CCT_PRESETS_K[lo]
            r_hi, g_hi, b_hi = _CCT_PRESETS_K[hi]
            return WhiteBalanceGains(
                r_gain=r_lo + frac * (r_hi - r_lo),
                g_gain=1.0,
                b_gain=b_lo + frac * (b_hi - b_lo),
            )
    return WhiteBalanceGains(1.0, 1.0, 1.0)


def estimate_gains(rgb_image: np.ndarray, processing_cfg: ProcessingConfig) -> WhiteBalanceGains:
    if processing_cfg.white_balance_mode == "gray_world":
        return gray_world_gains(rgb_image)
    return preset_gains(processing_cfg.colour_temp_k)


def apply_white_balance(rgb_image: np.ndarray, gains: WhiteBalanceGains) -> np.ndarray:
    out = rgb_image.astype(np.float64).copy()
    out[..., 0] *= gains.r_gain
    out[..., 1] *= gains.g_gain
    out[..., 2] *= gains.b_gain
    return out
