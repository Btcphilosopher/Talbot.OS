"""
imaging.exposure
==================
The classic exposure triangle (shutter speed, aperture, ISO) expressed as
exposure value (EV), plus a simple closed-loop auto-exposure controller
that meters a captured frame and proposes new settings to converge on a
target mid-tone brightness.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from utils.config import CameraConfig


@dataclass
class ExposureState:
    shutter_speed_s: float
    f_number: float
    iso: int
    ev: float
    ev100: float


def exposure_value(f_number: float, shutter_speed_s: float) -> float:
    """EV = log2(N^2 / t)."""
    return math.log2((f_number ** 2) / max(shutter_speed_s, 1e-9))


def ev_to_ev100(ev: float, iso: int) -> float:
    """Normalise EV at the current ISO to the EV100 (ISO 100) reference
    scale: EV100 = EV - log2(ISO / 100).
    """
    return ev - math.log2(max(iso, 1) / 100.0)


def current_exposure_state(cam_cfg: CameraConfig) -> ExposureState:
    exp = cam_cfg.exposure
    lens = cam_cfg.lens
    ev = exposure_value(lens.f_number, exp.shutter_speed_s)
    return ExposureState(
        shutter_speed_s=exp.shutter_speed_s,
        f_number=lens.f_number,
        iso=exp.iso,
        ev=ev,
        ev100=ev_to_ev100(ev, exp.iso),
    )


def meter_frame(linear_image: np.ndarray, weighting: str = "center_weighted") -> float:
    """Estimate scene brightness (mean normalised intensity, 0..1) from a
    captured linear-light frame, using either a flat average or a simple
    centre-weighted mask approximating a real camera's metering pattern.
    """
    if linear_image.ndim == 3:
        luminance = 0.2126 * linear_image[..., 0] + 0.7152 * linear_image[..., 1] + 0.0722 * linear_image[..., 2]
    else:
        luminance = linear_image

    if weighting == "flat":
        return float(np.clip(np.mean(luminance), 0.0, 1.0))

    h, w = luminance.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
    cy, cx = (h - 1) / 2.0, (w - 1) / 2.0
    r = np.sqrt(((yy - cy) / (h / 2.0)) ** 2 + ((xx - cx) / (w / 2.0)) ** 2)
    weight = np.clip(1.2 - r, 0.05, 1.0)
    weighted_mean = np.sum(luminance * weight) / np.sum(weight)
    return float(np.clip(weighted_mean, 0.0, 1.0))


def auto_expose_step(cam_cfg: CameraConfig, metered_intensity: float) -> ExposureState:
    """One iteration of a proportional auto-exposure controller: compares
    metered brightness to the configured target and adjusts shutter speed
    first (motion-limited), then ISO, while keeping aperture fixed
    (aperture-priority-style behaviour, the common default for video/16K
    capture where DoF intent is usually set deliberately by the operator).
    """
    exp = cam_cfg.exposure
    target = exp.target_mean_intensity
    metered_intensity = max(metered_intensity, 1e-4)

    error_stops = math.log2(target / metered_intensity) + exp.ev_compensation

    # Prefer shutter speed adjustment within its allowed range; overflow
    # spills into ISO gain. error_stops > 0 means the frame is under-
    # exposed (metered < target), so exposure *time* must increase --
    # multiply, not divide, by the stop factor.
    new_shutter = exp.shutter_speed_s * (2.0 ** error_stops)
    new_shutter_clamped = float(np.clip(new_shutter, exp.min_shutter_s, exp.max_shutter_s))
    residual_stops = math.log2(new_shutter / max(new_shutter_clamped, 1e-9))

    new_iso = exp.iso * (2.0 ** residual_stops)
    new_iso_clamped = int(np.clip(round(new_iso), exp.min_iso, exp.max_iso))

    ev = exposure_value(cam_cfg.lens.f_number, new_shutter_clamped)
    return ExposureState(
        shutter_speed_s=new_shutter_clamped,
        f_number=cam_cfg.lens.f_number,
        iso=new_iso_clamped,
        ev=ev,
        ev100=ev_to_ev100(ev, new_iso_clamped),
    )


def apply_auto_exposure(cam_cfg: CameraConfig, metered_intensity: float) -> None:
    """Mutate `cam_cfg.exposure` in place towards the metered target, if
    auto-exposure is enabled.
    """
    if not cam_cfg.exposure.auto_exposure:
        return
    new_state = auto_expose_step(cam_cfg, metered_intensity)
    cam_cfg.exposure.shutter_speed_s = new_state.shutter_speed_s
    cam_cfg.exposure.iso = new_state.iso
