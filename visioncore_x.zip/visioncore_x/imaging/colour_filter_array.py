"""
imaging.colour_filter_array
=============================
Bayer colour filter array (CFA) mosaic generation: takes a full-colour
scene render and samples it down to the single-channel-per-pixel raw
mosaic a real Bayer sensor actually produces, in the standard RGGB tiling.
"""
from __future__ import annotations

import numpy as np

BAYER_PATTERNS = {
    "RGGB": np.array([["R", "G"], ["G", "B"]]),
    "BGGR": np.array([["B", "G"], ["G", "R"]]),
    "GRBG": np.array([["G", "R"], ["B", "G"]]),
    "GBRG": np.array([["G", "B"], ["R", "G"]]),
}

_CHANNEL_INDEX = {"R": 0, "G": 1, "B": 2}


def bayer_channel_mask(height: int, width: int, pattern: str = "RGGB") -> np.ndarray:
    """Return an (H, W) int array where each entry is the channel index
    (0=R, 1=G, 2=B) sampled by the CFA at that pixel.
    """
    tile = BAYER_PATTERNS[pattern]
    mask = np.empty((height, width), dtype=np.int8)
    for dy in range(2):
        for dx in range(2):
            mask[dy::2, dx::2] = _CHANNEL_INDEX[tile[dy, dx]]
    return mask


def mosaic(rgb_image: np.ndarray, pattern: str = "RGGB") -> np.ndarray:
    """Sample an (H, W, 3) RGB image down to the (H, W) single-channel raw
    Bayer mosaic a real sensor would have produced -- exactly one colour
    sample per photosite, as in physical hardware.
    """
    h, w = rgb_image.shape[:2]
    mask = bayer_channel_mask(h, w, pattern)
    raw = np.take_along_axis(rgb_image, mask[..., None], axis=2)[..., 0]
    return raw


def channel_sampling_fraction(pattern: str = "RGGB") -> dict:
    """Fraction of photosites dedicated to each colour channel -- 25% R,
    50% G, 25% B for a standard Bayer array, which is *why* the green
    channel carries the bulk of perceived luminance resolution.
    """
    tile = BAYER_PATTERNS[pattern].flatten()
    counts = {"R": 0, "G": 0, "B": 0}
    for c in tile:
        counts[c] += 1
    total = len(tile)
    return {k: v / total for k, v in counts.items()}
