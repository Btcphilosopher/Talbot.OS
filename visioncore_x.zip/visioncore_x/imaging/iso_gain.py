"""
imaging.iso_gain
==================
ISO is implemented as analog (and, beyond the sensor's native max, digital)
gain applied after the photodiode but before/after the ADC. Gain amplifies
signal *and* read noise equally, which is why raising ISO does not create
new noise but does make existing shot/read noise more visible relative to
a now-brighter picture, and why *digital* ISO (post-ADC) is strictly worse
than analog ISO for the same nominal gain.
"""
from __future__ import annotations

from dataclasses import dataclass

from utils.config import SensorConfig

BASE_ISO = 100


@dataclass
class GainProfile:
    iso: int
    total_gain_db: float
    analog_gain_db: float
    digital_gain_db: float
    analog_gain_linear: float
    digital_gain_linear: float
    is_extended_digital: bool


def iso_to_gain_db(iso: int, base_iso: int = BASE_ISO) -> float:
    """ISO doubling corresponds to +6.02 dB of gain (20*log10(2))."""
    import math

    return 20.0 * math.log10(max(iso, 1) / base_iso)


def db_to_linear(gain_db: float) -> float:
    return 10.0 ** (gain_db / 20.0)


def build_gain_profile(iso: int, sensor_cfg: SensorConfig) -> GainProfile:
    total_db = iso_to_gain_db(iso)
    analog_db = min(total_db, sensor_cfg.max_analog_gain_db)
    digital_db = max(total_db - analog_db, 0.0)

    return GainProfile(
        iso=iso,
        total_gain_db=total_db,
        analog_gain_db=analog_db,
        digital_gain_db=digital_db,
        analog_gain_linear=db_to_linear(analog_db),
        digital_gain_linear=db_to_linear(digital_db),
        is_extended_digital=digital_db > 0.01,
    )


def noise_amplification_factor(gain_profile: GainProfile) -> float:
    """How much the *displayed* noise floor is amplified relative to
    base ISO. Analog gain amplifies signal and pre-ADC noise together
    (roughly noise-neutral in read-noise-equivalent-electrons terms, but
    it does raise dark-current and residual noise proportionally);
    digital gain amplifies *everything* including quantisation noise
    with no matching signal benefit, so it is penalised more heavily.
    """
    return gain_profile.analog_gain_linear * (gain_profile.digital_gain_linear ** 1.5)


def read_noise_equivalent_electrons(read_noise_e: float, gain_profile: GainProfile) -> float:
    """Read noise referred back to input (electrons at the photodiode) is
    roughly gain-independent for the analog stage (that's the point of
    analog gain -- it moves the signal above the *fixed* downstream noise
    floor); this returns the *input-referred* noise, useful for SNR calcs.
    """
    return read_noise_e
