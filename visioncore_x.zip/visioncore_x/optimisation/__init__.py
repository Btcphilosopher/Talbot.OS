"""VISIONCORE-X :: optimisation package."""
