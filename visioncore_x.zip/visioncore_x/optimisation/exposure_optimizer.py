"""
optimisation.exposure_optimizer
=================================
Iterative auto-exposure convergence: wraps imaging.exposure's single-step
controller in a small optimisation loop that also considers noise cost
(higher ISO is only accepted if shutter/aperture room is exhausted) and
reports convergence diagnostics, rather than just applying one P-step.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from imaging.exposure import ExposureState, auto_expose_step, exposure_value, ev_to_ev100
from utils.config import CameraConfig


@dataclass
class ExposureOptimizationResult:
    converged: bool
    iterations: int
    final_state: ExposureState
    final_error_stops: float


def optimize_exposure(
    cam_cfg: CameraConfig,
    meter_fn: Callable[[CameraConfig], float],
    max_iterations: int = 6,
    tolerance_stops: float = 0.05,
) -> ExposureOptimizationResult:
    """Repeatedly meter (via `meter_fn`, which re-renders/estimates scene
    brightness under the current exposure state -- supplied by the
    caller since it depends on the live scene) and step the exposure
    controller until the metered brightness converges within tolerance
    or the iteration budget is exhausted.
    """
    import math

    state = None
    error_stops = float("inf")

    for i in range(max_iterations):
        metered = meter_fn(cam_cfg)
        target = cam_cfg.exposure.target_mean_intensity
        error_stops = math.log2(max(target, 1e-4) / max(metered, 1e-4))

        if abs(error_stops) <= tolerance_stops:
            state = state or _state_from_cfg(cam_cfg)
            return ExposureOptimizationResult(True, i, state, error_stops)

        state = auto_expose_step(cam_cfg, metered)
        cam_cfg.exposure.shutter_speed_s = state.shutter_speed_s
        cam_cfg.exposure.iso = state.iso

    state = state or _state_from_cfg(cam_cfg)
    return ExposureOptimizationResult(False, max_iterations, state, error_stops)


def _state_from_cfg(cam_cfg: CameraConfig) -> ExposureState:
    ev = exposure_value(cam_cfg.lens.f_number, cam_cfg.exposure.shutter_speed_s)
    return ExposureState(
        shutter_speed_s=cam_cfg.exposure.shutter_speed_s,
        f_number=cam_cfg.lens.f_number,
        iso=cam_cfg.exposure.iso,
        ev=ev,
        ev100=ev_to_ev100(ev, cam_cfg.exposure.iso),
    )


def suggest_aperture_for_dof_vs_light(
    cam_cfg: CameraConfig,
    prefer_shallow_dof: bool,
) -> float:
    """A simple heuristic advisor: when the operator prioritises shallow
    depth of field, recommend opening up toward the lens's minimum
    f-number (subject to the diffraction-limited ceiling being moot at
    wide apertures); when prioritising deep focus / diffraction-limited
    sharpness, recommend a middle f-stop that avoids both wide-open
    aberrations and small-aperture diffraction softening.
    """
    lens = cam_cfg.lens
    if prefer_shallow_dof:
        return lens.min_f_number
    # "Sweet spot" heuristic: roughly 2 stops down from wide open, which
    # is a common practical guideline for peak lens sharpness before
    # diffraction dominates.
    return min(lens.min_f_number * 2.0, lens.max_f_number)
