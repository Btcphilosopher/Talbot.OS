"""
optimisation.compression_optimizer
=====================================
Given a storage/bandwidth budget, search for the highest compression
quality setting that still fits within it -- a bisection search over the
quality dial using compression.image_codec's rate model, avoiding a
brute-force sweep.
"""
from __future__ import annotations

from dataclasses import dataclass

from compression.bandwidth_model import required_data_rate_mb_s
from compression.image_codec import estimate_frame_size_bytes, estimate_quality_score
from utils.config import CompressionConfig, SensorConfig


@dataclass
class CompressionOptimizationResult:
    quality: float
    achieved_rate_mb_s: float
    budget_mb_s: float
    quality_score: float
    iterations: int
    within_budget: bool


def optimize_quality_for_bandwidth(
    sensor_cfg: SensorConfig,
    compression_cfg: CompressionConfig,
    frame_rate_fps: float,
    budget_mb_s: float,
    tolerance: float = 1e-3,
    max_iterations: int = 24,
) -> CompressionOptimizationResult:
    """Bisection search on `quality` in [0, 1] for the largest value whose
    resulting sustained data rate stays at or below `budget_mb_s`.
    Monotonic by construction (estimate_bits_per_pixel increases with
    quality for lossy codecs), so bisection converges reliably.
    """
    lo, hi = 0.0, 1.0
    working_cfg = CompressionConfig(**{**compression_cfg.__dict__})

    def rate_at(q: float) -> float:
        working_cfg.quality = q
        size = estimate_frame_size_bytes(sensor_cfg, working_cfg, channels=3)
        return required_data_rate_mb_s(size, frame_rate_fps)

    if rate_at(1.0) <= budget_mb_s:
        best_q = 1.0
    elif rate_at(0.0) > budget_mb_s:
        best_q = 0.0
    else:
        best_q = 0.0
        for _ in range(max_iterations):
            mid = (lo + hi) / 2.0
            r = rate_at(mid)
            if r <= budget_mb_s:
                best_q = mid
                lo = mid
            else:
                hi = mid
            if (hi - lo) < tolerance:
                break

    working_cfg.quality = best_q
    final_rate = rate_at(best_q)
    quality_score = estimate_quality_score(working_cfg)

    return CompressionOptimizationResult(
        quality=best_q,
        achieved_rate_mb_s=final_rate,
        budget_mb_s=budget_mb_s,
        quality_score=quality_score,
        iterations=max_iterations,
        within_budget=final_rate <= budget_mb_s + 1e-6,
    )


def recommend_codec_for_budget(
    sensor_cfg: SensorConfig,
    frame_rate_fps: float,
    budget_mb_s: float,
) -> str:
    """Pick the highest-fidelity codec profile (in a fixed quality-
    preference order) that can meet the bandwidth budget at some
    achievable quality setting, falling back to the most aggressive
    codec if nothing else fits.
    """
    from compression.image_codec import CODEC_PROFILES

    preference_order = ["raw", "lossless", "prores_like", "hevc_like"]
    for codec_name in preference_order:
        cfg = CompressionConfig(codec=codec_name, quality=1.0)
        size = estimate_frame_size_bytes(sensor_cfg, cfg, channels=3)
        if required_data_rate_mb_s(size, frame_rate_fps) <= budget_mb_s:
            return codec_name
    return "hevc_like"
