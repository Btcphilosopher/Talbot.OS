"""
compression.encoder_16k
=========================
Note on filename: Python module names cannot begin with a digit, so the
architecture's "16k_encoder.py" is implemented here as `encoder_16k.py`
(imported as `compression.encoder_16k`).

Tile-based encode-time simulation for full 16K frames. Real hardware/
software encoders parallelise a frame across many tiles (CTU/tile-based
parallelism, as in HEVC/AV1); this module models that: split the true
16K frame into fixed-size tiles, estimate per-tile encode cost, and
combine into a realistic total encode latency given a configurable
parallelism (thread/core count).
"""
from __future__ import annotations

from dataclasses import dataclass

from compression.image_codec import CodecProfile, estimate_bits_per_pixel, get_profile
from utils.config import CompressionConfig, SensorConfig

# Baseline single-tile, single-core encode throughput at compute_cost_factor
# == 1.0, in megapixels/second. Calibrated so a "hevc_like" profile on a
# realistic many-core encode farm lands in a plausible ballpark for 16K
# real-time-ish encoding, while a naive raw/lossless path is much faster.
BASE_ENCODE_THROUGHPUT_MP_S = 220.0


@dataclass
class TileEncodePlan:
    tile_size_px: int
    tiles_x: int
    tiles_y: int
    total_tiles: int
    tile_megapixels: float


@dataclass
class EncodeEstimate:
    plan: TileEncodePlan
    per_tile_time_ms: float
    single_core_total_time_ms: float
    parallel_total_time_ms: float
    encode_throughput_mp_s: float
    output_frame_size_bytes: float


def build_tile_plan(sensor_cfg: SensorConfig, compression_cfg: CompressionConfig) -> TileEncodePlan:
    w, h = sensor_cfg.resolution()
    tile = max(compression_cfg.tile_size_px, 16)
    tiles_x = -(-w // tile)  # ceil div
    tiles_y = -(-h // tile)
    return TileEncodePlan(
        tile_size_px=tile,
        tiles_x=tiles_x,
        tiles_y=tiles_y,
        total_tiles=tiles_x * tiles_y,
        tile_megapixels=(tile * tile) / 1_000_000.0,
    )


def estimate_encode_time(
    sensor_cfg: SensorConfig,
    compression_cfg: CompressionConfig,
    parallel_workers: int = 16,
) -> EncodeEstimate:
    """Estimate wall-clock encode time for one full 16K frame.

    Throughput scales inversely with the codec's relative compute cost
    (a more sophisticated codec, e.g. hevc_like, costs more per pixel
    than a raw passthrough), and total tile work is divided across
    `parallel_workers`, capped by the number of available tiles (you
    cannot parallelise beyond one worker per tile in this simple model).
    """
    profile = get_profile(compression_cfg.codec)
    plan = build_tile_plan(sensor_cfg, compression_cfg)

    effective_throughput_mp_s = BASE_ENCODE_THROUGHPUT_MP_S / max(profile.compute_cost_factor, 1e-3)
    total_mp = (sensor_cfg.resolution()[0] * sensor_cfg.resolution()[1]) / 1_000_000.0

    single_core_time_ms = (total_mp / effective_throughput_mp_s) * 1000.0
    per_tile_time_ms = single_core_time_ms / max(plan.total_tiles, 1)

    effective_workers = max(1, min(parallel_workers, plan.total_tiles))
    parallel_time_ms = single_core_time_ms / effective_workers

    from compression.image_codec import estimate_frame_size_bytes

    output_size = estimate_frame_size_bytes(sensor_cfg, compression_cfg, channels=3)

    return EncodeEstimate(
        plan=plan,
        per_tile_time_ms=per_tile_time_ms,
        single_core_total_time_ms=single_core_time_ms,
        parallel_total_time_ms=parallel_time_ms,
        encode_throughput_mp_s=effective_throughput_mp_s,
        output_frame_size_bytes=output_size,
    )


def keyframe_overhead_factor(compression_cfg: CompressionConfig, frame_index: int) -> float:
    """Keyframes (I-frames) cost more to encode than predicted (P/B)
    frames since there's no temporal reference to exploit; apply a
    multiplicative overhead on keyframe boundaries.
    """
    interval = max(compression_cfg.keyframe_interval, 1)
    is_keyframe = (frame_index % interval) == 0
    return 1.6 if is_keyframe else 1.0
