"""
compression.bandwidth_model
=============================
Translates per-frame compressed size and target frame rate into sustained
data-rate requirements, and checks that requirement against real-world
interface/storage bandwidth ceilings. This is where "16K is a bandwidth
problem as much as an optics problem" becomes a concrete, checkable
number.
"""
from __future__ import annotations

from dataclasses import dataclass

from utils.config import CameraConfig

# Representative sustained bandwidth ceilings for common interfaces /
# media, in MB/s. Informational reference values used for feasibility
# checks against the modelled data rate.
INTERFACE_BANDWIDTH_MB_S = {
    "SDI_12G": 1_485.0 / 8 * 1.0,       # ~1 lane of 12G-SDI, illustrative
    "Thunderbolt4": 5_000.0,
    "PCIe4x4": 7_800.0,
    "PCIe5x4": 15_000.0,
    "10GbE": 1_150.0,
    "25GbE": 2_900.0,
    "CFexpress_TypeB": 1_700.0,
    "SATA_SSD": 550.0,
}


@dataclass
class BandwidthReport:
    frame_size_bytes: float
    frame_rate_fps: float
    required_rate_mb_s: float
    required_rate_gb_min: float
    feasible_interfaces: list
    infeasible_interfaces: list


def required_data_rate_mb_s(frame_size_bytes: float, frame_rate_fps: float) -> float:
    return (frame_size_bytes * frame_rate_fps) / (1024.0 * 1024.0)


def analyze_bandwidth(frame_size_bytes: float, frame_rate_fps: float) -> BandwidthReport:
    rate_mb_s = required_data_rate_mb_s(frame_size_bytes, frame_rate_fps)
    rate_gb_min = rate_mb_s * 60.0 / 1024.0

    feasible, infeasible = [], []
    for name, cap in INTERFACE_BANDWIDTH_MB_S.items():
        (feasible if cap >= rate_mb_s else infeasible).append(name)

    return BandwidthReport(
        frame_size_bytes=frame_size_bytes,
        frame_rate_fps=frame_rate_fps,
        required_rate_mb_s=rate_mb_s,
        required_rate_gb_min=rate_gb_min,
        feasible_interfaces=sorted(feasible),
        infeasible_interfaces=sorted(infeasible),
    )


def headroom_ratio(cam_cfg: CameraConfig, required_rate_mb_s: float) -> float:
    """How much spare write bandwidth the configured storage device has
    relative to what the current capture settings demand (>1 = comfortable
    margin, <1 = the storage subsystem cannot keep up and buffering /
    frame drops will occur -- see storage.buffer_manager).
    """
    device_speed = cam_cfg.storage.device_write_speed_mb_s
    if required_rate_mb_s <= 0:
        return float("inf")
    return device_speed / required_rate_mb_s


def session_storage_gb(required_rate_mb_s: float, duration_minutes: float) -> float:
    return (required_rate_mb_s * 60.0 * duration_minutes) / 1024.0
