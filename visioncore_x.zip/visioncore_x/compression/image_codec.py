"""
compression.image_codec
=========================
Codec profiles and a size/quality estimator. This is not a bit-exact
codec implementation (that's out of scope for a systems simulator) but a
calibrated *rate-distortion model*: given a codec profile and a quality
setting, estimate the resulting bits-per-pixel, output file size, and a
quality/PSNR-like fidelity score, using standard entropy-coding scaling
behaviour (near-linear bpp reduction with quantisation step, logarithmic
diminishing returns on fidelity).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from utils.config import CompressionConfig, SensorConfig


@dataclass
class CodecProfile:
    name: str
    base_bpp_at_q1: float     # bits per pixel per channel at quality=1.0 (near-lossless)
    min_bpp: float            # floor bpp at quality=0.0 (most aggressive)
    lossless: bool
    compute_cost_factor: float  # relative encode complexity, 1.0 = baseline


CODEC_PROFILES = {
    "raw": CodecProfile("raw", base_bpp_at_q1=14.0, min_bpp=14.0, lossless=True, compute_cost_factor=0.05),
    "lossless": CodecProfile("lossless", base_bpp_at_q1=8.5, min_bpp=6.0, lossless=True, compute_cost_factor=0.6),
    "prores_like": CodecProfile("prores_like", base_bpp_at_q1=6.0, min_bpp=2.2, lossless=False, compute_cost_factor=0.8),
    "hevc_like": CodecProfile("hevc_like", base_bpp_at_q1=4.5, min_bpp=0.12, lossless=False, compute_cost_factor=1.6),
}


def get_profile(codec_name: str) -> CodecProfile:
    if codec_name not in CODEC_PROFILES:
        raise ValueError(f"Unknown codec '{codec_name}'. Options: {list(CODEC_PROFILES)}")
    return CODEC_PROFILES[codec_name]


def estimate_bits_per_pixel(compression_cfg: CompressionConfig) -> float:
    """Map the 0..1 quality dial to bits-per-pixel-per-channel using a
    profile's [min_bpp, base_bpp_at_q1] range and a gamma curve that
    concentrates most of the *visual* quality change in the upper part
    of the quality range (matching how real codecs behave: bpp collapses
    fast below a 'good enough' quality point, then fidelity degrades
    more per bit removed).
    """
    profile = get_profile(compression_cfg.codec)
    q = float(np.clip(compression_cfg.quality, 0.0, 1.0))
    if profile.lossless:
        # Lossless/near-lossless codecs still vary somewhat with content-
        # adaptive prediction quality but are bounded tightly.
        return profile.min_bpp + (profile.base_bpp_at_q1 - profile.min_bpp) * (0.3 + 0.7 * q)
    gamma = 2.2
    return profile.min_bpp + (profile.base_bpp_at_q1 - profile.min_bpp) * (q ** gamma)


def estimate_quality_score(compression_cfg: CompressionConfig) -> float:
    """A synthetic 0..100 perceptual-quality-like score (not true PSNR/
    SSIM, which require a reference decode) derived from bpp relative to
    the codec's native lossless bpp -- diminishing returns modelled with
    a saturating log curve, consistent with real rate-distortion curves.
    """
    profile = get_profile(compression_cfg.codec)
    bpp = estimate_bits_per_pixel(compression_cfg)
    if profile.lossless:
        return 100.0
    ratio = bpp / profile.base_bpp_at_q1
    score = 100.0 * (1.0 - np.exp(-3.2 * ratio))
    return float(np.clip(score, 0.0, 100.0))


def estimate_frame_size_bytes(sensor_cfg: SensorConfig, compression_cfg: CompressionConfig, channels: int = 3) -> float:
    """Estimate the compressed size of one *true 16K* frame, in bytes,
    from the codec's estimated bits-per-pixel-per-channel.
    """
    w, h = sensor_cfg.resolution()
    bpp_total = estimate_bits_per_pixel(compression_cfg) * channels
    total_bits = w * h * bpp_total
    return total_bits / 8.0


def raw_frame_size_bytes(sensor_cfg: SensorConfig) -> float:
    """Uncompressed raw Bayer frame size (1 sample/pixel at sensor bit
    depth) -- the reference point every compression ratio is measured
    against.
    """
    w, h = sensor_cfg.resolution()
    return w * h * sensor_cfg.pixel_bit_depth / 8.0


def compression_ratio(sensor_cfg: SensorConfig, compression_cfg: CompressionConfig) -> float:
    raw = raw_frame_size_bytes(sensor_cfg)
    compressed = estimate_frame_size_bytes(sensor_cfg, compression_cfg, channels=1)
    return raw / compressed if compressed > 0 else float("inf")
