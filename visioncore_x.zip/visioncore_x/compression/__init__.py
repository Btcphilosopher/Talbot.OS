"""VISIONCORE-X :: compression package."""
