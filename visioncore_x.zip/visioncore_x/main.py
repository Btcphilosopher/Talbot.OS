#!/usr/bin/env python3
"""
VISIONCORE-X -- command-line entry point.

Run a full end-to-end simulation of the 16K camera system and print/save
a metrics report, optionally with visualisation output.

Examples
--------
    python main.py
    python main.py --frames 60 --fps 24 --iso 800 --f-number 4 --scene low_light
    python main.py --resolution 8K_UHD --codec prores_like --quality 0.9 --visualize
    python main.py --config my_camera.json
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from core.simulation_loop import print_summary, run_simulation  # noqa: E402
from utils.config import RESOLUTION_PRESETS, CameraConfig  # noqa: E402
from utils.logging import get_logger  # noqa: E402

logger = get_logger("main")


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="visioncore-x",
        description="VISIONCORE-X -- 16K Camera System Simulator & Photonic Imaging Prototyper",
    )
    p.add_argument("--config", type=str, default=None, help="Load a CameraConfig from a JSON file")
    p.add_argument("--save-config", type=str, default=None, help="Save the resolved CameraConfig to a JSON file and exit")

    p.add_argument("--frames", type=int, default=None, help="Number of frames to simulate")
    p.add_argument("--fps", type=float, default=None, help="Target frame rate (fps)")
    p.add_argument("--resolution", type=str, default=None, choices=list(RESOLUTION_PRESETS), help="Sensor resolution preset")
    p.add_argument("--scene", type=str, default=None, help="Scene generator (studio_gradient|checkerboard|resolution_chart|low_light|high_contrast_hdr)")
    p.add_argument("--motion", type=str, default=None, help="Camera motion profile (static|pan|handheld|whip_pan)")

    p.add_argument("--focal-length", type=float, default=None, help="Lens focal length (mm)")
    p.add_argument("--f-number", type=float, default=None, help="Lens aperture f-number")
    p.add_argument("--iso", type=int, default=None, help="ISO sensitivity")
    p.add_argument("--shutter", type=float, default=None, help="Shutter speed as 1/x seconds (pass x)")
    p.add_argument("--no-auto-exposure", action="store_true", help="Disable auto-exposure")

    p.add_argument("--codec", type=str, default=None, choices=["raw", "lossless", "prores_like", "hevc_like"], help="Compression codec profile")
    p.add_argument("--quality", type=float, default=None, help="Compression quality, 0..1")
    p.add_argument("--write-speed", type=float, default=None, help="Storage device write speed (MB/s)")
    p.add_argument("--buffer-frames", type=int, default=None, help="Frame buffer capacity")

    p.add_argument("--preview-scale", type=float, default=None, help="Array-simulation downscale factor from true 16K")
    p.add_argument("--seed", type=int, default=None, help="Random seed")

    p.add_argument("--visualize", action="store_true", help="Save visualisation PNGs to the output directory")
    p.add_argument("--output-dir", type=str, default=None, help="Output directory for reports/visualisations")
    p.add_argument("--metrics-csv", type=str, default=None, help="Write per-frame metrics to this CSV path")
    p.add_argument("--quiet", action="store_true", help="Suppress per-frame progress logging")
    return p


def resolve_config(args: argparse.Namespace) -> CameraConfig:
    cfg = CameraConfig.from_json(args.config) if args.config else CameraConfig()

    if args.frames is not None:
        cfg.simulation.n_frames = args.frames
    if args.fps is not None:
        cfg.simulation.frame_rate_target_fps = args.fps
    if args.resolution is not None:
        cfg.sensor.resolution_preset = args.resolution
    if args.scene is not None:
        cfg.simulation.scene_type = args.scene
    if args.motion is not None:
        cfg.simulation.motion_type = args.motion
    if args.preview_scale is not None:
        cfg.simulation.preview_scale = args.preview_scale
    if args.seed is not None:
        cfg.simulation.random_seed = args.seed
    if args.output_dir is not None:
        cfg.simulation.output_dir = args.output_dir

    if args.focal_length is not None:
        cfg.lens.focal_length_mm = args.focal_length
    if args.f_number is not None:
        cfg.lens.f_number = args.f_number

    if args.iso is not None:
        cfg.exposure.iso = args.iso
    if args.shutter is not None:
        cfg.exposure.shutter_speed_s = 1.0 / args.shutter
    if args.no_auto_exposure:
        cfg.exposure.auto_exposure = False

    if args.codec is not None:
        cfg.compression.codec = args.codec
    if args.quality is not None:
        cfg.compression.quality = args.quality

    if args.write_speed is not None:
        cfg.storage.device_write_speed_mb_s = args.write_speed
    if args.buffer_frames is not None:
        cfg.storage.buffer_capacity_frames = args.buffer_frames

    return cfg


def maybe_visualize(engine, results, cfg: CameraConfig) -> None:
    from visualization.image_viewer import save_frame_png, save_side_by_side
    from visualization.sensor_heatmap import plot_intensity_heatmap, plot_saturation_overlay
    from visualization.optical_flow import plot_distortion_grid, plot_rolling_shutter_skew
    from visualization.dashboard import plot_latency_dashboard, plot_compression_sweep
    from sensor.readout_noise import build_readout_profile

    out_dir = Path(cfg.simulation.output_dir) / "visualizations"
    out_dir.mkdir(parents=True, exist_ok=True)

    imaged = [r for r in results if r.images]
    if imaged:
        sample = imaged[len(imaged) // 2]
        save_frame_png(sample.images["final"], out_dir / f"frame_{sample.frame_index:04d}_final.png", title="Final ISP Output")
        plot_intensity_heatmap(sample.images["electrons"], out_dir / f"frame_{sample.frame_index:04d}_heatmap.png")
        plot_saturation_overlay(
            sample.images["final"],
            sample.images["saturated_mask"][..., None].repeat(3, axis=2),
            out_dir / f"frame_{sample.frame_index:04d}_saturation.png",
        )
        save_side_by_side(
            [sample.images["raw_mosaic"], sample.images["final"]],
            ["Raw Mosaic", "Final ISP Output"],
            out_dir / f"frame_{sample.frame_index:04d}_pipeline.png",
        )

    # Fixed diagnostic canvas (independent of the array-simulation preview
    # scale, which can be too small to visibly resolve mild distortion)
    # sized to the sensor's true aspect ratio.
    true_w, true_h = cfg.sensor.resolution()
    diag_w, diag_h = 640, max(int(640 * true_h / true_w), 64)
    plot_distortion_grid(
        diag_w, diag_h,
        cfg.lens.distortion_k1, cfg.lens.distortion_k2,
        out_dir / "lens_distortion.png",
    )
    readout = build_readout_profile(cfg.sensor)
    plot_rolling_shutter_skew(engine.preview.preview_height, readout.max_rolling_shutter_skew_ms, out_dir / "rolling_shutter_skew.png")

    plot_latency_dashboard(engine.latency_tracker, out_dir / "latency_dashboard.png")
    plot_compression_sweep(cfg.sensor, cfg.compression.codec, out_dir / "compression_tradeoff.png")

    logger.info("Visualisations written to %s", out_dir)


def main(argv=None) -> int:
    args = build_arg_parser().parse_args(argv)
    cfg = resolve_config(args)

    if args.save_config:
        cfg.to_json(args.save_config)
        print(f"Config saved to {args.save_config}")
        return 0

    print(cfg.summary())
    print(f"Preview grid: array-based ISP stages run at a downscaled representative "
          f"resolution (scale={cfg.simulation.preview_scale:.4f}); all bandwidth/"
          f"timing/dynamic-range figures are computed analytically at the true "
          f"{cfg.sensor.resolution()[0]}x{cfg.sensor.resolution()[1]} sensor resolution.\n")

    engine, results, summary = run_simulation(cfg, save_images_every=max(cfg.simulation.n_frames // 4, 1), verbose=not args.quiet)
    print_summary(summary)

    if args.metrics_csv:
        engine.metrics.to_csv(args.metrics_csv)
        print(f"Per-frame metrics written to {args.metrics_csv}")

    if args.visualize:
        maybe_visualize(engine, results, cfg)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
