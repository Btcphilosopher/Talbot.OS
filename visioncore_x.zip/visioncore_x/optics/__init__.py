"""VISIONCORE-X :: optics package."""
