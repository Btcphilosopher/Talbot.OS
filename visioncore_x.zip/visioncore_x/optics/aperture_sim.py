"""
optics.aperture_sim
=====================
Aperture geometry, depth-of-field, and hyperfocal-distance calculations.
The aperture is the single control that simultaneously drives exposure
(via lens_transmitted_irradiance), diffraction (via optics.diffraction)
and depth of field -- this module owns the DoF side of that trade-off.
"""
from __future__ import annotations

from dataclasses import dataclass

from utils.config import LensConfig


@dataclass
class DepthOfFieldResult:
    hyperfocal_distance_m: float
    near_limit_m: float
    far_limit_m: float
    dof_range_m: float
    entrance_pupil_diameter_mm: float


def entrance_pupil_diameter_mm(lens_cfg: LensConfig) -> float:
    """Entrance pupil diameter D = f / N."""
    return lens_cfg.focal_length_mm / lens_cfg.f_number


def hyperfocal_distance_m(lens_cfg: LensConfig, sensor_width_mm: float) -> float:
    """Hyperfocal distance H = f^2 / (N * c) + f, with circle-of-confusion
    `c` taken from the lens spec (sensor-referred, in mm).
    """
    f = lens_cfg.focal_length_mm
    n = lens_cfg.f_number
    c_mm = lens_cfg.coc_limit_um / 1000.0
    h_mm = (f ** 2) / (n * c_mm) + f
    return h_mm / 1000.0  # -> metres


def depth_of_field(lens_cfg: LensConfig, subject_distance_m: float, sensor_width_mm: float) -> DepthOfFieldResult:
    """Near/far focus limits for a subject at `subject_distance_m`, using
    the standard thin-lens hyperfocal formulae:

        near = H*s / (H + (s - f))
        far  = H*s / (H - (s - f))   (infinity if s >= H)
    """
    h = hyperfocal_distance_m(lens_cfg, sensor_width_mm)
    f_m = lens_cfg.focal_length_mm / 1000.0
    s = max(subject_distance_m, f_m * 1.01)

    near = (h * s) / (h + (s - f_m))
    if s >= h:
        far = float("inf")
    else:
        denom = h - (s - f_m)
        far = (h * s) / denom if denom > 1e-9 else float("inf")

    dof_range = far - near if far != float("inf") else float("inf")

    return DepthOfFieldResult(
        hyperfocal_distance_m=h,
        near_limit_m=max(near, 0.0),
        far_limit_m=far,
        dof_range_m=dof_range,
        entrance_pupil_diameter_mm=entrance_pupil_diameter_mm(lens_cfg),
    )


def aperture_area_mm2(lens_cfg: LensConfig) -> float:
    """Effective clear aperture area, accounting for the polygonal
    (N-blade) iris shape rather than an idealised circle -- more blades
    approach the circular limit.
    """
    import math

    d = entrance_pupil_diameter_mm(lens_cfg)
    r = d / 2.0
    n = max(lens_cfg.aperture_blades, 3)
    # Area of a regular n-gon inscribed in radius r, vs. circle pi*r^2.
    polygon_area = 0.5 * n * (r ** 2) * math.sin(2 * math.pi / n)
    return polygon_area


def relative_illumination_factor(lens_cfg: LensConfig, wide_open_f_number: float) -> float:
    """Light-gathering power relative to the lens's fastest (wide-open)
    setting, scaling as (N_open / N)^2 since illuminance ~ 1/N^2.
    """
    return (wide_open_f_number / lens_cfg.f_number) ** 2
