"""
optics.lens_model
===================
Aggregate lens behaviour: combines lens aberration MTF with the
diffraction MTF (physics.diffraction) into a single system-level optical
transfer function, plus lateral chromatic aberration and geometric
distortion models used by the resolution and signal-processing stages.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from optics import diffraction
from utils.config import LensConfig


@dataclass
class OpticalPerformance:
    mtf50_lp_mm: float
    diffraction_limited: bool
    airy_radius_um: float
    system_mtf_at_nyquist: float
    effective_resolution_factor: float  # 0..1, fraction of sensor resolution actually usable


def lens_aberration_mtf(spatial_freq_lp_mm: np.ndarray, mtf50_lp_mm: float) -> np.ndarray:
    """Simple, well-behaved MTF model for lens aberrations alone: a
    Gaussian roll-off pinned to the manufacturer-style MTF50 spec. This
    reproduces the qualitative shape of real lens MTF curves (near 1.0 at
    DC, ~0.5 at the quoted MTF50 frequency, decaying smoothly beyond)
    without requiring ray-traced wavefront data.
    """
    # Solve sigma such that exp(-0.5*(f50/sigma)^2) == 0.5
    sigma = mtf50_lp_mm / np.sqrt(2.0 * np.log(2.0))
    return np.exp(-0.5 * (spatial_freq_lp_mm / sigma) ** 2)


def system_mtf(spatial_freq_lp_mm: np.ndarray, lens_cfg: LensConfig) -> np.ndarray:
    """Combined optical MTF = lens aberration MTF * diffraction MTF, the
    standard multiplicative cascade for independent, incoherent transfer
    functions in an imaging chain.
    """
    lens_mtf = lens_aberration_mtf(spatial_freq_lp_mm, lens_cfg.lens_mtf50_lp_per_mm)
    diff_mtf = diffraction.diffraction_mtf(spatial_freq_lp_mm, lens_cfg.f_number)
    return lens_mtf * diff_mtf


def evaluate_optical_performance(lens_cfg: LensConfig, pixel_pitch_um: float) -> OpticalPerformance:
    """Compute a scalar performance snapshot for the current lens
    settings at the sensor's pixel pitch: system MTF at the sensor's
    Nyquist frequency, and whether diffraction already limits resolution.
    """
    nyquist_lp_mm = 1000.0 / (2.0 * pixel_pitch_um)  # cycles/mm at Nyquist for this pitch
    freqs = np.linspace(0.0, nyquist_lp_mm, 64)
    mtf_curve = system_mtf(freqs, lens_cfg)

    # locate MTF50 by interpolation
    mtf50 = float(np.interp(0.5, mtf_curve[::-1], freqs[::-1])) if mtf_curve.min() < 0.5 else float(nyquist_lp_mm)
    mtf_at_nyquist = float(mtf_curve[-1])
    diff_limited = diffraction.is_diffraction_limited(lens_cfg.f_number, pixel_pitch_um)

    # Effective resolution factor: how much of the sensor's *pixel-level*
    # resolution the optics can actually deliver, clipped to [0, 1].
    effective_factor = float(np.clip(mtf_at_nyquist / 0.1, 0.0, 1.0)) if mtf_at_nyquist < 0.1 else 1.0
    effective_factor = float(np.clip(mtf50 / nyquist_lp_mm, 0.05, 1.0))

    return OpticalPerformance(
        mtf50_lp_mm=mtf50,
        diffraction_limited=diff_limited,
        airy_radius_um=diffraction.airy_disk_radius_um(lens_cfg.f_number),
        system_mtf_at_nyquist=mtf_at_nyquist,
        effective_resolution_factor=effective_factor,
    )


def lateral_chromatic_shift_px(lens_cfg: LensConfig, normalized_radius: float) -> float:
    """Lateral CA grows roughly linearly with image height; returns the
    R/B channel shift (in pixels) relative to G at a given normalized
    radius (0 at centre, 1 at corner).
    """
    return lens_cfg.chromatic_aberration_px * np.clip(normalized_radius, 0.0, 1.0)


def radial_distortion_map(width: int, height: int, k1: float, k2: float) -> tuple[np.ndarray, np.ndarray]:
    """Build normalized-coordinate distortion displacement fields (dx, dy)
    using the standard Brown-Conrady radial distortion model:

        r_d = r * (1 + k1*r^2 + k2*r^4)

    Positive k -> pincushion, negative k -> barrel (the lens default).
    Returns pixel-space sampling coordinates for use with e.g.
    scipy.ndimage.map_coordinates.
    """
    yy, xx = np.mgrid[0:height, 0:width].astype(np.float64)
    cx, cy = (width - 1) / 2.0, (height - 1) / 2.0
    nx = (xx - cx) / (width / 2.0)
    ny = (yy - cy) / (height / 2.0)
    r2 = nx ** 2 + ny ** 2
    factor = 1.0 + k1 * r2 + k2 * r2 ** 2
    src_x = cx + (nx * factor) * (width / 2.0)
    src_y = cy + (ny * factor) * (height / 2.0)
    return src_y, src_x
