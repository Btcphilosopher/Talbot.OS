"""
optics.diffraction
====================
Diffraction is the hard physical ceiling on resolution: no lens, however
well corrected, can beat it. At 16K pixel pitches (a few microns), the
diffraction limit becomes a first-order design constraint rather than a
theoretical curiosity -- this module makes that constraint explicit.
"""
from __future__ import annotations

import numpy as np

DEFAULT_WAVELENGTH_NM = 550.0  # visible-light centroid


def airy_disk_radius_um(f_number: float, wavelength_nm: float = DEFAULT_WAVELENGTH_NM) -> float:
    """Radius of the first dark ring of the Airy diffraction pattern
    (Rayleigh criterion), in microns:

        r = 1.22 * lambda * N
    """
    wavelength_um = wavelength_nm * 1e-3
    return 1.22 * wavelength_um * f_number


def diffraction_limited_resolution_lp_mm(f_number: float, wavelength_nm: float = DEFAULT_WAVELENGTH_NM) -> float:
    """Diffraction-limited spatial frequency at which MTF reaches zero
    (line pairs per mm), from the classic optics relation:

        f_c = 1 / (lambda * N)
    """
    wavelength_mm = wavelength_nm * 1e-6
    return 1.0 / (wavelength_mm * f_number)


def diffraction_mtf(spatial_freq_lp_mm: np.ndarray, f_number: float, wavelength_nm: float = DEFAULT_WAVELENGTH_NM) -> np.ndarray:
    """Diffraction-limited MTF of a perfect circular aperture, as a
    function of spatial frequency, using the closed-form incoherent OTF
    of a clear circular pupil:

        MTF(f) = (2/pi) * [ acos(f/fc) - (f/fc) * sqrt(1 - (f/fc)^2) ],  f < fc
        MTF(f) = 0,                                                     f >= fc
    """
    fc = diffraction_limited_resolution_lp_mm(f_number, wavelength_nm)
    ratio = np.clip(spatial_freq_lp_mm / fc, 0.0, 1.0)
    mtf = (2.0 / np.pi) * (np.arccos(ratio) - ratio * np.sqrt(np.clip(1.0 - ratio ** 2, 0.0, 1.0)))
    return np.clip(mtf, 0.0, 1.0)


def diffraction_blur_kernel(f_number: float, pixel_pitch_um: float, wavelength_nm: float = DEFAULT_WAVELENGTH_NM, size: int = 9) -> np.ndarray:
    """A small 2D Gaussian kernel approximating the diffraction PSF, sized
    in units of sensor pixels. The Airy pattern's central lobe is
    approximated by a Gaussian of matching standard deviation
    (sigma ~= 0.42 * r_airy), which is accurate enough for convolution-based
    blur simulation without paying for a full Bessel-function PSF.
    """
    r_airy_um = airy_disk_radius_um(f_number, wavelength_nm)
    sigma_um = 0.42 * r_airy_um
    sigma_px = max(sigma_um / pixel_pitch_um, 1e-3)

    ax = np.arange(size) - size // 2
    xx, yy = np.meshgrid(ax, ax)
    kernel = np.exp(-(xx ** 2 + yy ** 2) / (2.0 * sigma_px ** 2))
    kernel /= kernel.sum()
    return kernel


def is_diffraction_limited(f_number: float, pixel_pitch_um: float, wavelength_nm: float = DEFAULT_WAVELENGTH_NM) -> bool:
    """True when the diffraction-limited Airy radius already exceeds the
    pixel pitch, i.e. the sensor resolves finer detail than the optics
    can deliver -- the pixels are "wasted" beyond this f-number. Extremely
    common at 16K, where pixel pitches can be ~1.5-3 um.
    """
    return airy_disk_radius_um(f_number, wavelength_nm) > pixel_pitch_um


def diffraction_limited_f_number(pixel_pitch_um: float, wavelength_nm: float = DEFAULT_WAVELENGTH_NM) -> float:
    """The largest f-number (smallest aperture) at which the Airy disk
    radius still matches the pixel pitch -- stopping down further than
    this purely trades light for no additional real resolution.
    """
    wavelength_um = wavelength_nm * 1e-3
    return pixel_pitch_um / (1.22 * wavelength_um)
