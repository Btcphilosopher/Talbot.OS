"""
optics.focal_geometry
=======================
Field of view, angular resolution, and motion-blur geometry derived from
focal length and sensor format. Also hosts the affine/perspective helpers
used by the motion-simulation workload to project camera movement onto
the image plane.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from utils.config import LensConfig, SensorConfig


@dataclass
class FieldOfView:
    horizontal_deg: float
    vertical_deg: float
    diagonal_deg: float
    crop_factor: float


FULL_FRAME_DIAGONAL_MM = 43.27


def sensor_diagonal_mm(sensor_cfg: SensorConfig) -> float:
    return math.hypot(sensor_cfg.sensor_width_mm, sensor_cfg.sensor_height_mm)


def crop_factor(sensor_cfg: SensorConfig) -> float:
    return FULL_FRAME_DIAGONAL_MM / sensor_diagonal_mm(sensor_cfg)


def field_of_view(lens_cfg: LensConfig, sensor_cfg: SensorConfig) -> FieldOfView:
    """FoV(deg) = 2 * atan(dimension / (2 * focal_length))."""
    f = lens_cfg.focal_length_mm
    h_fov = 2.0 * math.degrees(math.atan(sensor_cfg.sensor_width_mm / (2.0 * f)))
    v_fov = 2.0 * math.degrees(math.atan(sensor_cfg.sensor_height_mm / (2.0 * f)))
    d_fov = 2.0 * math.degrees(math.atan(sensor_diagonal_mm(sensor_cfg) / (2.0 * f)))
    return FieldOfView(
        horizontal_deg=h_fov,
        vertical_deg=v_fov,
        diagonal_deg=d_fov,
        crop_factor=crop_factor(sensor_cfg),
    )


def angular_resolution_arcsec_per_pixel(lens_cfg: LensConfig, sensor_cfg: SensorConfig) -> float:
    """How many arcseconds of scene each pixel subtends -- the imaging
    system's true angular sampling resolution, useful for comparing
    against diffraction/seeing limits (astronomy-style figure of merit).
    """
    fov = field_of_view(lens_cfg, sensor_cfg)
    w_px, _ = sensor_cfg.resolution()
    deg_per_px = fov.horizontal_deg / w_px
    return deg_per_px * 3600.0


def pixel_pitch_to_focal_plane_mm(sensor_cfg: SensorConfig) -> float:
    return sensor_cfg.pixel_pitch_um() / 1000.0


def focal_plane_velocity_mm_s(angular_velocity_deg_s: float, lens_cfg: LensConfig) -> float:
    """Convert an angular camera-pan rate into a linear velocity at the
    focal (sensor) plane, v = f * omega (small-angle / paraxial).
    """
    omega_rad_s = math.radians(angular_velocity_deg_s)
    return lens_cfg.focal_length_mm * omega_rad_s


def motion_blur_extent_px(
    angular_velocity_deg_s: float,
    exposure_time_s: float,
    lens_cfg: LensConfig,
    sensor_cfg: SensorConfig,
) -> float:
    """Motion blur streak length, in pixels, for a pan/rotation-induced
    camera shake at the given angular rate and shutter speed.
    """
    v_mm_s = focal_plane_velocity_mm_s(angular_velocity_deg_s, lens_cfg)
    blur_mm = v_mm_s * exposure_time_s
    pitch_mm = sensor_cfg.pixel_pitch_um() / 1000.0
    return blur_mm / pitch_mm
