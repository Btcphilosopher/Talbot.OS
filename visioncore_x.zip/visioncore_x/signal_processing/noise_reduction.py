"""
signal_processing.noise_reduction
====================================
Edge-aware denoising. Implements a simple bilateral-style filter (blends
Gaussian spatial weighting with a range/intensity weighting so edges are
preserved while flat noisy regions are smoothed) -- the standard
ISP-stage NR building block, applied with strength tied to the
configured `denoise_strength` and (in the full pipeline) to the frame's
actual measured noise level so higher ISO gets proportionally more NR.
"""
from __future__ import annotations

import numpy as np

from signal_processing.sharpening import gaussian_blur


def bilateral_filter(image: np.ndarray, spatial_sigma: float = 2.0, range_sigma: float = 0.08, iterations: int = 1) -> np.ndarray:
    """A lightweight approximate bilateral filter: for each iteration,
    blend the pixel with a spatially-blurred version, weighted down where
    the local intensity difference is large (i.e. near edges), so edges
    resist smoothing while flat noisy regions get averaged down.
    """
    out = image.astype(np.float64).copy()
    for _ in range(max(iterations, 1)):
        blurred = gaussian_blur(out, spatial_sigma)
        diff = out - blurred
        range_weight = np.exp(-(diff ** 2) / (2.0 * range_sigma ** 2))
        out = range_weight * out + (1.0 - range_weight) * blurred
    return out


def denoise(image: np.ndarray, strength: float, measured_noise_std: float | None = None) -> np.ndarray:
    """Apply noise reduction with an overall `strength` in [0, 1], which
    maps to filter parameters. If `measured_noise_std` is supplied (e.g.
    from photon_noise / sensor readout at the current ISO), scale the
    spatial sigma up for noisier frames so NR keeps pace with ISO.
    """
    strength = float(np.clip(strength, 0.0, 1.0))
    if strength <= 1e-6:
        return image.copy()

    base_sigma = 0.5 + 3.0 * strength
    if measured_noise_std is not None:
        base_sigma *= float(np.clip(1.0 + measured_noise_std * 4.0, 1.0, 3.0))

    range_sigma = 0.03 + 0.25 * strength
    return bilateral_filter(image, spatial_sigma=base_sigma, range_sigma=range_sigma, iterations=1)


def estimate_noise_std(image: np.ndarray) -> float:
    """Fast noise-level estimator using the median absolute deviation of
    the high-pass (Laplacian-like) residual -- robust to real image
    structure, standard technique for automatic NR tuning.
    """
    if image.ndim == 3:
        luminance = image.mean(axis=2)
    else:
        luminance = image
    laplacian = (
        -4 * luminance
        + np.roll(luminance, 1, axis=0)
        + np.roll(luminance, -1, axis=0)
        + np.roll(luminance, 1, axis=1)
        + np.roll(luminance, -1, axis=1)
    )
    mad = np.median(np.abs(laplacian - np.median(laplacian)))
    sigma = mad / 0.6745 / 6.0  # normalise for the Laplacian kernel's gain
    return float(max(sigma, 0.0))
