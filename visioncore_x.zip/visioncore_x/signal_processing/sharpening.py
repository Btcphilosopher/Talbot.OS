"""
signal_processing.sharpening
==============================
Unsharp masking: blur the image, subtract the blur from the original to
get a "detail" layer, then add a scaled copy of that detail layer back.
Standard ISP sharpening stage; over-application reintroduces noise
amplitude (since noise lives in exactly the same high-frequency band
sharpening targets), which is why sharpening amount and denoise strength
are handled together at the pipeline level.
"""
from __future__ import annotations

import numpy as np


def _gaussian_kernel1d(sigma: float, radius: int) -> np.ndarray:
    x = np.arange(-radius, radius + 1)
    k = np.exp(-(x ** 2) / (2.0 * sigma ** 2))
    return k / k.sum()


def gaussian_blur(image: np.ndarray, sigma: float) -> np.ndarray:
    """Separable Gaussian blur, numpy-only (no scipy dependency)."""
    if sigma <= 0:
        return image.copy()
    radius = max(int(3 * sigma), 1)
    kernel = _gaussian_kernel1d(sigma, radius)

    def conv1d(arr: np.ndarray, axis: int) -> np.ndarray:
        pad_width = [(0, 0)] * arr.ndim
        pad_width[axis] = (radius, radius)
        padded = np.pad(arr, pad_width, mode="reflect")
        out = np.zeros_like(arr, dtype=np.float64)
        for i, w in enumerate(kernel):
            sl = [slice(None)] * arr.ndim
            sl[axis] = slice(i, i + arr.shape[axis])
            out += w * padded[tuple(sl)]
        return out

    blurred = conv1d(image.astype(np.float64), axis=0)
    blurred = conv1d(blurred, axis=1)
    return blurred


def unsharp_mask(image: np.ndarray, amount: float = 0.35, radius_px: float = 1.2, threshold: float = 0.0) -> np.ndarray:
    """Apply unsharp masking:

        detail = image - blur(image, radius)
        output = image + amount * detail   (only where |detail| > threshold)
    """
    blurred = gaussian_blur(image, radius_px)
    detail = image.astype(np.float64) - blurred

    if threshold > 0:
        mask = np.abs(detail) >= threshold
        detail = detail * mask

    sharpened = image.astype(np.float64) + amount * detail
    return sharpened


def edge_energy(image: np.ndarray) -> float:
    """Rough sharpness proxy: mean absolute gradient magnitude, usable to
    quantify the effect of sharpening/denoise/compression trade-offs in
    the performance report.
    """
    if image.ndim == 3:
        luminance = image.mean(axis=2)
    else:
        luminance = image
    gy, gx = np.gradient(luminance.astype(np.float64))
    return float(np.mean(np.sqrt(gx ** 2 + gy ** 2)))
