"""
signal_processing.hdr_pipeline
================================
Multi-exposure HDR fusion: captures a small exposure bracket (e.g.
[-2EV, 0EV, +2EV]), weights each exposure by how well-exposed each pixel
is in that frame (a simplified Mertens-style well-exposedness weight),
blends them into a single high-dynamic-range linear image, then tone-maps
back down for display/encode using sensor.dynamic_range.reinhard_tone_map.
"""
from __future__ import annotations

from typing import Sequence

import numpy as np

from sensor.dynamic_range import reinhard_tone_map


def well_exposedness_weight(image: np.ndarray, sigma: float = 0.2) -> np.ndarray:
    """Per-pixel weight peaking at mid-grey (0.5) and falling off towards
    both shadows and highlights, following Mertens et al.'s exposure
    fusion weighting.
    """
    return np.exp(-((image - 0.5) ** 2) / (2.0 * sigma ** 2))


def contrast_weight(image: np.ndarray) -> np.ndarray:
    """Local contrast weight via a simple Laplacian magnitude -- rewards
    detail-rich regions in the fused result.
    """
    if image.ndim == 3:
        luminance = image.mean(axis=2)
    else:
        luminance = image
    lap = (
        -4 * luminance
        + np.roll(luminance, 1, axis=0)
        + np.roll(luminance, -1, axis=0)
        + np.roll(luminance, 1, axis=1)
        + np.roll(luminance, -1, axis=1)
    )
    w = np.abs(lap)
    if image.ndim == 3:
        w = np.repeat(w[..., None], image.shape[2], axis=2)
    return w


def fuse_exposure_bracket(exposures: Sequence[np.ndarray], stops: Sequence[float]) -> np.ndarray:
    """Fuse a bracket of differently-exposed captures of the same scene
    into a single HDR-ish linear image.

    Each input frame is first normalised back to a common linear-light
    scale by dividing out its relative exposure factor (2**stop), then
    blended using well-exposedness * contrast weights, matching the
    exposure-fusion family of algorithms (Mertens et al., 2007) without
    the full multi-resolution pyramid (kept single-scale for speed at
    16K-representative resolutions).
    """
    if len(exposures) != len(stops):
        raise ValueError("exposures and stops must be the same length")

    weighted_sum = np.zeros_like(exposures[0], dtype=np.float64)
    weight_total = np.zeros(exposures[0].shape[:2] + ((1,) if exposures[0].ndim == 3 else ()), dtype=np.float64)

    for frame, stop in zip(exposures, stops):
        linear_frame = frame.astype(np.float64) / (2.0 ** stop)
        w = well_exposedness_weight(frame) * (0.2 + contrast_weight(frame))
        if frame.ndim == 3:
            w_scalar = w.mean(axis=2, keepdims=True)
        else:
            w_scalar = w[..., None] if w.ndim == 2 else w
        weighted_sum += linear_frame * (w if frame.ndim == 3 else w[..., None])
        weight_total += w_scalar

    weight_total = np.clip(weight_total, 1e-6, None)
    fused = weighted_sum / weight_total
    return fused


def hdr_pipeline(exposures: Sequence[np.ndarray], stops: Sequence[float], white_point: float = 2.0) -> np.ndarray:
    """Full bracket -> fused HDR -> tone-mapped display image pipeline."""
    fused_linear = fuse_exposure_bracket(exposures, stops)
    return np.clip(reinhard_tone_map(fused_linear, white_point=white_point), 0.0, 1.0)
