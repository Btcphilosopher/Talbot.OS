"""VISIONCORE-X :: resolution package."""
