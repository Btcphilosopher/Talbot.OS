"""
resolution.resolution_engine
==============================
The bridge between the *true* 16K sensor specification and the
*practically simulatable* preview array. Also computes the "effective
resolution" metric the whole platform reports: the true sensor pixel
count degraded by everything that actually limits resolving power --
optical MTF, diffraction, aliasing, and noise -- because the constraint
list explicitly forbids assuming resolution is a free, constant number.
"""
from __future__ import annotations

from dataclasses import dataclass

from optics.lens_model import OpticalPerformance
from utils.config import CameraConfig, RESOLUTION_PRESETS


@dataclass
class PreviewGrid:
    true_width: int
    true_height: int
    preview_width: int
    preview_height: int
    scale: float


@dataclass
class EffectiveResolutionReport:
    nominal_megapixels: float
    optical_factor: float
    noise_factor: float
    aliasing_factor: float
    effective_megapixels: float
    effective_factor: float


def build_preview_grid(cam_cfg: CameraConfig) -> PreviewGrid:
    """Compute the downsampled array size actually used for numpy-based
    ISP/visualisation stages, derived from the true 16K sensor resolution
    and the configured preview_scale. Enforces a sane minimum so tiny
    scales don't degenerate to 0-sized arrays.
    """
    true_w, true_h = cam_cfg.sensor.resolution()
    scale = cam_cfg.simulation.preview_scale
    preview_w = max(int(round(true_w * scale)), 32)
    preview_h = max(int(round(true_h * scale)), 18)
    return PreviewGrid(
        true_width=true_w,
        true_height=true_h,
        preview_width=preview_w,
        preview_height=preview_h,
        scale=scale,
    )


def snr_to_resolution_factor(snr_db: float) -> float:
    """Empirical mapping from per-pixel SNR (dB) to a resolution-retention
    factor in [0, 1]: at very low SNR, noise buries fine detail well
    before it clips, effectively erasing resolved spatial frequencies
    (this is why 'more megapixels' in low light delivers *less* real
    detail than the pixel count suggests). Modelled as a smooth logistic
    centred near 20dB (~a commonly cited 'clean' SNR threshold).
    """
    import math

    midpoint_db = 20.0
    slope = 0.18
    return 1.0 / (1.0 + math.exp(-slope * (snr_db - midpoint_db)))


def compute_effective_resolution(
    cam_cfg: CameraConfig,
    optical_perf: OpticalPerformance,
    mean_snr_db: float,
    aliasing_severity: float,
) -> EffectiveResolutionReport:
    """Combine independent degradation factors multiplicatively to get an
    overall effective-resolution estimate relative to the sensor's
    nominal pixel count. `aliasing_severity` in [0, 1] (0 = none).
    """
    nominal_mp = cam_cfg.sensor.megapixels()
    optical_factor = optical_perf.effective_resolution_factor
    noise_factor = snr_to_resolution_factor(mean_snr_db)
    aliasing_factor = 1.0 - 0.5 * max(min(aliasing_severity, 1.0), 0.0)

    combined = optical_factor * noise_factor * aliasing_factor
    return EffectiveResolutionReport(
        nominal_megapixels=nominal_mp,
        optical_factor=optical_factor,
        noise_factor=noise_factor,
        aliasing_factor=aliasing_factor,
        effective_megapixels=nominal_mp * combined,
        effective_factor=combined,
    )


def list_resolution_presets() -> dict:
    return dict(RESOLUTION_PRESETS)
