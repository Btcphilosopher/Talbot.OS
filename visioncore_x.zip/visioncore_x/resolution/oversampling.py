"""
resolution.oversampling
=========================
Pixel binning: trading spatial resolution for per-site sensitivity and
noise performance by summing/averaging NxN neighbourhoods of photosites
into one output sample. At 16K, binning down to an "8K" or "4K" output is
a common real-world operating mode for low light or high frame rate, and
this module quantifies exactly what that trade costs and buys.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class BinningResult:
    bin_factor: int
    output_width: int
    output_height: int
    resolution_retained_pct: float
    snr_improvement_db: float
    full_well_effective_e: float


def bin_electrons(electron_array: np.ndarray, bin_factor: int) -> np.ndarray:
    """Sum bin_factor x bin_factor neighbourhoods of a per-pixel electron
    array (analog binning: charge is summed *before* read noise is
    added once per bin, which is why binning improves SNR beyond simple
    resolution averaging).
    """
    if bin_factor <= 1:
        return electron_array.copy()

    h, w = electron_array.shape[:2]
    h_trim = (h // bin_factor) * bin_factor
    w_trim = (w // bin_factor) * bin_factor
    trimmed = electron_array[:h_trim, :w_trim]

    if trimmed.ndim == 3:
        reshaped = trimmed.reshape(h_trim // bin_factor, bin_factor, w_trim // bin_factor, bin_factor, trimmed.shape[2])
        return reshaped.sum(axis=(1, 3))
    reshaped = trimmed.reshape(h_trim // bin_factor, bin_factor, w_trim // bin_factor, bin_factor)
    return reshaped.sum(axis=(1, 3))


def analyze_binning(
    sensor_width_px: int,
    sensor_height_px: int,
    bin_factor: int,
    full_well_capacity_e: float,
    read_noise_e: float,
) -> BinningResult:
    """Compute the resolution / SNR trade-off for a given binning factor.

    Resolution scales down by bin_factor^2 in pixel count (bin_factor in
    each linear dimension). SNR improves because N summed photosites'
    shot noise combines as sqrt(N) while signal grows as N, and read
    noise is only paid once per output bin rather than once per input
    pixel -- both favour binning in read-noise-limited (low light)
    conditions.
    """
    out_w = sensor_width_px // bin_factor
    out_h = sensor_height_px // bin_factor
    n = bin_factor ** 2

    resolution_pct = 100.0 * (out_w * out_h) / (sensor_width_px * sensor_height_px)

    # SNR improvement modelled at a representative mid-signal point:
    # unbinned SNR ~ S / sqrt(S + rn^2); binned signal = N*S,
    # binned noise^2 = N*S + rn^2 (one read per bin).
    s = full_well_capacity_e * 0.25  # representative operating signal level
    unbinned_snr = s / np.sqrt(s + read_noise_e ** 2)
    binned_signal = n * s
    binned_noise = np.sqrt(n * s + read_noise_e ** 2)
    binned_snr = binned_signal / binned_noise
    snr_gain_db = 20.0 * np.log10(binned_snr / unbinned_snr) if unbinned_snr > 0 else 0.0

    return BinningResult(
        bin_factor=bin_factor,
        output_width=out_w,
        output_height=out_h,
        resolution_retained_pct=resolution_pct,
        snr_improvement_db=float(snr_gain_db),
        full_well_effective_e=full_well_capacity_e * n,
    )


def recommend_binning_for_lowlight(mean_scene_electrons: float, full_well_capacity_e: float) -> int:
    """Simple heuristic: as the scene gets darker relative to full well,
    recommend progressively more aggressive binning to recover SNR at
    the cost of resolution -- mirrors how real 16K cinema sensors offer
    selectable pixel-binning capture modes.
    """
    fraction = mean_scene_electrons / max(full_well_capacity_e, 1e-6)
    if fraction > 0.15:
        return 1
    if fraction > 0.04:
        return 2
    if fraction > 0.01:
        return 3
    return 4
