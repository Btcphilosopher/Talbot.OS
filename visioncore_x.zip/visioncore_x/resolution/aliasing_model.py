"""
resolution.aliasing_model
===========================
Nyquist-frequency analysis and aliasing (moire) estimation. Real cameras
almost never carry an optical low-pass filter at 16K (the pixel pitch is
already near/below the diffraction limit, see optics.diffraction), so
regular high-frequency scene content can alias against the pixel grid.
This module estimates how severe that aliasing is likely to be, given
the ratio of scene detail frequency to sensor Nyquist frequency.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from utils.config import SensorConfig


@dataclass
class AliasingReport:
    nyquist_freq_lp_mm: float
    dominant_scene_freq_lp_mm: float
    freq_ratio: float
    aliasing_severity: float  # 0..1


def nyquist_frequency_lp_mm(sensor_cfg: SensorConfig) -> float:
    """Sensor Nyquist frequency: half the sampling frequency, sampling
    frequency being 1 / pixel_pitch.
    """
    pitch_mm = sensor_cfg.pixel_pitch_um() / 1000.0
    sampling_freq = 1.0 / pitch_mm
    return sampling_freq / 2.0


def estimate_dominant_frequency_lp_mm(image_2d: np.ndarray, sensor_width_mm: float) -> float:
    """Estimate the dominant spatial frequency present in a (grayscale)
    preview frame via its 2D power spectrum's radially-averaged peak,
    scaled from cycles/preview-pixel to line-pairs/mm using the true
    sensor's physical width.
    """
    h, w = image_2d.shape
    spectrum = np.abs(np.fft.fftshift(np.fft.fft2(image_2d - image_2d.mean())))
    power = spectrum ** 2

    yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
    cy, cx = h / 2.0, w / 2.0
    radius = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    r_int = radius.astype(np.int64)

    max_r = int(min(h, w) // 2)
    radial_power = np.zeros(max_r + 1)
    for r in range(max_r + 1):
        m = r_int == r
        if np.any(m):
            radial_power[r] = power[m].mean()

    # Ignore DC and the first couple bins (dominated by low-frequency
    # shading), find the peak of the remaining spectrum.
    if max_r < 4:
        return 0.0
    search = radial_power[3:]
    peak_r = int(np.argmax(search)) + 3

    cycles_per_preview_px = peak_r / (2.0 * max_r) if max_r > 0 else 0.0
    preview_px_per_mm = w / sensor_width_mm
    return cycles_per_preview_px * preview_px_per_mm


def analyze_aliasing(image_2d: np.ndarray, sensor_cfg: SensorConfig) -> AliasingReport:
    nyquist = nyquist_frequency_lp_mm(sensor_cfg)
    dominant = estimate_dominant_frequency_lp_mm(image_2d, sensor_cfg.sensor_width_mm)
    ratio = dominant / nyquist if nyquist > 0 else 0.0

    # Aliasing severity ramps up sharply as scene detail approaches and
    # exceeds Nyquist (ratio -> 1 and beyond); negligible well below it.
    severity = float(np.clip((ratio - 0.5) / 0.5, 0.0, 1.0))

    return AliasingReport(
        nyquist_freq_lp_mm=nyquist,
        dominant_scene_freq_lp_mm=dominant,
        freq_ratio=ratio,
        aliasing_severity=severity,
    )


def synthesize_moire_test_pattern(height: int, width: int, frequency_cycles_per_px: float) -> np.ndarray:
    """Generate a radial chirp / zone-plate style test pattern classically
    used to visualise aliasing and resolution limits.
    """
    yy, xx = np.mgrid[0:height, 0:width].astype(np.float64)
    cy, cx = height / 2.0, width / 2.0
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    pattern = 0.5 + 0.5 * np.cos(2.0 * np.pi * frequency_cycles_per_px * r ** 2 / max(height, width))
    return pattern
