"""
sensor.cmos_model
===================
Physical model of the 16K CMOS sensor die itself: pixel geometry,
quantum efficiency, thermal behaviour and power. At 16K, pixel pitch
shrinks into the 1.5-3um range for a full-frame-sized die, which drives
every other constraint in the system (full well capacity collapses,
diffraction becomes limiting, heat density rises) -- this module is the
single place those consequences are computed from first principles.
"""
from __future__ import annotations

from dataclasses import dataclass

from utils.config import SensorConfig


@dataclass
class SensorDieProfile:
    pixel_pitch_um: float
    pixel_area_um2: float
    pixel_area_m2: float
    total_pixels: int
    megapixels: float
    photodiode_area_um2: float          # after fill-factor loss
    full_well_capacity_e: float
    die_power_w: float
    die_temperature_c: float
    thermal_noise_penalty_factor: float


def pixel_area_m2(pixel_pitch_um: float) -> float:
    pitch_m = pixel_pitch_um * 1e-6
    return pitch_m ** 2


def photodiode_area_um2(sensor_cfg: SensorConfig) -> float:
    pitch = sensor_cfg.pixel_pitch_um()
    return (pitch ** 2) * sensor_cfg.fill_factor


def estimate_die_power_w(sensor_cfg: SensorConfig, frame_rate_fps: float) -> float:
    """Power scales with pixel count (parallel analog readout paths) and
    with readout speed (frame rate); modelled as a base thermal design
    power scaled by a normalized activity factor. This is intentionally
    a simple, monotonic proxy rather than a transistor-level power model.
    """
    w_px, h_px = sensor_cfg.resolution()
    reference_mp = 33.2  # ~8K reference point used to anchor the TDP spec
    mp_scale = (w_px * h_px / 1_000_000.0) / reference_mp
    fps_scale = frame_rate_fps / 24.0
    return sensor_cfg.thermal_design_power_w * mp_scale * fps_scale


def estimate_die_temperature_c(sensor_cfg: SensorConfig, die_power_w: float, thermal_resistance_c_per_w: float = 4.2) -> float:
    """Steady-state die temperature above ambient, using a lumped
    thermal-resistance model: dT = P * R_th.
    """
    return sensor_cfg.ambient_temp_c + die_power_w * thermal_resistance_c_per_w


def thermal_noise_penalty(die_temperature_c: float, reference_temp_c: float = 25.0) -> float:
    """Dark current (and hence thermal noise) roughly doubles every ~6-8C
    for silicon photodiodes. Returns a multiplicative penalty factor
    applied to the configured dark-current spec.
    """
    doubling_interval_c = 6.5
    delta_t = die_temperature_c - reference_temp_c
    return 2.0 ** (delta_t / doubling_interval_c)


def build_die_profile(sensor_cfg: SensorConfig, frame_rate_fps: float) -> SensorDieProfile:
    pitch = sensor_cfg.pixel_pitch_um()
    w_px, h_px = sensor_cfg.resolution()
    total_px = w_px * h_px

    power = estimate_die_power_w(sensor_cfg, frame_rate_fps)
    temp = estimate_die_temperature_c(sensor_cfg, power)
    thermal_penalty = thermal_noise_penalty(temp)

    # Full well capacity is fundamentally area-limited: as pitch shrinks,
    # available charge storage volume shrinks roughly with area (~pitch^2),
    # scaled from the configured spec (assumed calibrated at this pitch).
    fwc = sensor_cfg.full_well_capacity_e

    return SensorDieProfile(
        pixel_pitch_um=pitch,
        pixel_area_um2=pitch ** 2,
        pixel_area_m2=pixel_area_m2(pitch),
        total_pixels=total_px,
        megapixels=total_px / 1_000_000.0,
        photodiode_area_um2=photodiode_area_um2(sensor_cfg),
        full_well_capacity_e=fwc,
        die_power_w=power,
        die_temperature_c=temp,
        thermal_noise_penalty_factor=thermal_penalty,
    )


def effective_quantum_efficiency(sensor_cfg: SensorConfig) -> float:
    """QE combined with fill factor gives the *effective* fraction of
    incident photons that generate a collected electron.
    """
    return sensor_cfg.quantum_efficiency * sensor_cfg.fill_factor
