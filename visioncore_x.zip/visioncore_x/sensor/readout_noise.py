"""
sensor.readout_noise
======================
Rolling-shutter readout timing and its consequences: full-frame readout
duration at true 16K resolution, per-row skew, and the resulting
geometric "shear/wobble" distortion on fast-moving subjects or fast pans.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from utils.config import SensorConfig


@dataclass
class ReadoutProfile:
    rows: int
    row_readout_time_ns: float
    full_frame_readout_time_ms: float
    max_rolling_shutter_skew_ms: float
    theoretical_max_fps: float


def full_frame_readout_time_ms(sensor_cfg: SensorConfig) -> float:
    """Time to shift out every row of the *true* 16K sensor, in
    milliseconds. This is the fundamental readout-bandwidth bottleneck
    that -- independent of ISP or storage -- upper-bounds achievable fps.
    """
    _, rows = sensor_cfg.resolution()
    return rows * sensor_cfg.row_readout_time_ns * 1e-6


def rolling_shutter_skew_ms(sensor_cfg: SensorConfig) -> float:
    """Time delay between the first row exposed/read and the last -- the
    source of rolling-shutter "jello" distortion on fast motion. For a
    simple row-sequential rolling shutter this equals the full readout
    time.
    """
    return full_frame_readout_time_ms(sensor_cfg)


def theoretical_max_fps(sensor_cfg: SensorConfig, overhead_factor: float = 1.08) -> float:
    """Upper bound on frame rate set purely by sensor readout bandwidth
    (ignoring ISP/compression/storage, which are modelled separately in
    performance.frame_rate). `overhead_factor` accounts for blanking
    intervals / vertical sync overhead beyond raw pixel-row shifting.
    """
    t_ms = full_frame_readout_time_ms(sensor_cfg) * overhead_factor
    if t_ms <= 0:
        return 0.0
    return 1000.0 / t_ms


def build_readout_profile(sensor_cfg: SensorConfig) -> ReadoutProfile:
    _, rows = sensor_cfg.resolution()
    return ReadoutProfile(
        rows=rows,
        row_readout_time_ns=sensor_cfg.row_readout_time_ns,
        full_frame_readout_time_ms=full_frame_readout_time_ms(sensor_cfg),
        max_rolling_shutter_skew_ms=rolling_shutter_skew_ms(sensor_cfg),
        theoretical_max_fps=theoretical_max_fps(sensor_cfg),
    )


def apply_rolling_shutter_shear(
    image: np.ndarray,
    horizontal_velocity_px_per_frame: float,
) -> np.ndarray:
    """Apply a per-row horizontal shear proportional to row index,
    approximating rolling-shutter skew for a horizontally-panning scene.
    Each row is shifted according to how much later in the readout
    sequence it was captured relative to row 0.
    """
    h, w = image.shape[:2]
    out = np.empty_like(image)
    row_fraction = np.linspace(0.0, 1.0, h)
    shifts = (row_fraction * horizontal_velocity_px_per_frame).astype(np.int64)
    for y in range(h):
        out[y] = np.roll(image[y], shifts[y], axis=0)
    return out


def read_noise_total_e(sensor_cfg: SensorConfig, adc_noise_e: float) -> float:
    """Total read-chain noise (analog read noise + ADC quantisation
    noise) combined in quadrature.
    """
    return float(np.sqrt(sensor_cfg.read_noise_e ** 2 + adc_noise_e ** 2))
