"""VISIONCORE-X :: sensor package."""
