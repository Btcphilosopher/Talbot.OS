"""
sensor.pixel_array
====================
The PixelArray owns the actual numpy state of the (preview-resolution)
photosite grid. A real 16K sensor is a Bayer (or similar) mosaic sensor:
each physical photosite samples exactly *one* colour channel. This class
therefore models a single-channel (H, W) electron grid -- the raw mosaic
-- consistent with imaging.colour_filter_array (which selects one
channel per site from the incoming photon map) and signal_processing
.demosaic (which reconstructs full RGB from exactly this kind of grid).

Resolution note: array sites here represent *sparse samples* of true
16K photosites spread across the full sensor area, each simulated with
the sensor's true (small) pixel-physics constants -- pitch, full well,
QE, noise -- so per-pixel saturation/SNR/noise numbers stay directly
comparable to the analytical true-16K figures reported elsewhere (see
resolution.resolution_engine for the full rationale).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from physics import photon_noise
from sensor import cmos_model
from utils.config import SensorConfig


@dataclass
class PixelArray:
    height: int
    width: int
    sensor_cfg: SensorConfig
    electrons: np.ndarray = field(init=False)
    saturated_mask: np.ndarray = field(init=False)

    def __post_init__(self) -> None:
        self.electrons = np.zeros((self.height, self.width), dtype=np.float64)
        self.saturated_mask = np.zeros((self.height, self.width), dtype=bool)

    def reset(self) -> None:
        self.electrons[...] = 0.0
        self.saturated_mask[...] = False

    def capture(
        self,
        photon_map_mosaic: np.ndarray,
        exposure_time_s: float,
        die_temperature_c: float,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Single-channel raw photon map (photons/pixel, already CFA-
        sampled -- see imaging.colour_filter_array.mosaic) -> stochastic
        electron count per pixel, including shot noise, dark current and
        full-well clipping. Returns the resulting electron array.
        """
        rng = rng or np.random.default_rng()
        qe = cmos_model.effective_quantum_efficiency(self.sensor_cfg)

        noisy_photons = photon_noise.sample_shot_noise(photon_map_mosaic, rng)
        photoelectrons = noisy_photons * qe

        dark_penalty = cmos_model.thermal_noise_penalty(die_temperature_c)
        dark_electrons_mean = self.sensor_cfg.dark_current_e_per_s_25c * dark_penalty * exposure_time_s
        dark_electrons = rng.poisson(max(dark_electrons_mean, 0.0), size=photoelectrons.shape).astype(np.float64)

        total_electrons = photoelectrons + dark_electrons

        fwc = self.sensor_cfg.full_well_capacity_e
        self.saturated_mask = total_electrons >= fwc
        total_electrons = np.clip(total_electrons, 0.0, fwc)

        self.electrons = total_electrons
        return self.electrons

    def saturation_fraction(self) -> float:
        return float(np.mean(self.saturated_mask))

    def mean_electrons(self) -> float:
        return float(np.mean(self.electrons))

    def to_digital(self, analog_gain_linear: float, adc_noise_e: float, rng: np.random.Generator | None = None) -> np.ndarray:
        """Apply analog gain then quantise to the sensor's configured bit
        depth, including read noise and ADC quantisation noise.
        """
        rng = rng or np.random.default_rng()
        fwc = self.sensor_cfg.full_well_capacity_e
        read_noise = rng.normal(0.0, self.sensor_cfg.read_noise_e, size=self.electrons.shape)
        adc_noise = rng.normal(0.0, adc_noise_e, size=self.electrons.shape)

        signal_e = self.electrons + read_noise + adc_noise
        signal_e = np.clip(signal_e, 0.0, None)

        gained = signal_e * analog_gain_linear
        max_code = (2 ** self.sensor_cfg.pixel_bit_depth) - 1
        # Normalise against the unity-gain full well so digital codes
        # stay in range as analog_gain_linear scales with ISO.
        normalizer = fwc
        digital = (gained / normalizer) * max_code
        digital = np.clip(np.round(digital), 0, max_code)
        return digital.astype(np.uint16 if self.sensor_cfg.pixel_bit_depth <= 16 else np.uint32)
