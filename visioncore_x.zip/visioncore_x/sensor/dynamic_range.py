"""
sensor.dynamic_range
======================
Dynamic range: the ratio between the brightest signal the sensor can
record without clipping (full well capacity) and the noise floor it can
resolve above (read + dark noise). Reported in both linear ratio,
decibels and photographic stops -- and folded into a tone-mapping helper
used by the HDR pipeline.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from sensor import readout_noise
from utils.config import SensorConfig


@dataclass
class DynamicRangeReport:
    full_well_e: float
    noise_floor_e: float
    dynamic_range_linear: float
    dynamic_range_db: float
    dynamic_range_stops: float


def compute_dynamic_range(sensor_cfg: SensorConfig, adc_noise_e: float, dark_noise_e: float = 0.0) -> DynamicRangeReport:
    read_total = readout_noise.read_noise_total_e(sensor_cfg, adc_noise_e)
    noise_floor = float(np.sqrt(read_total ** 2 + dark_noise_e ** 2))
    noise_floor = max(noise_floor, 1e-6)

    dr_linear = sensor_cfg.full_well_capacity_e / noise_floor
    dr_db = 20.0 * np.log10(dr_linear)
    dr_stops = np.log2(dr_linear)

    return DynamicRangeReport(
        full_well_e=sensor_cfg.full_well_capacity_e,
        noise_floor_e=noise_floor,
        dynamic_range_linear=dr_linear,
        dynamic_range_db=dr_db,
        dynamic_range_stops=dr_stops,
    )


def reinhard_tone_map(hdr_linear: np.ndarray, white_point: float = 1.0) -> np.ndarray:
    """Simple global Reinhard operator compressing high dynamic range
    linear radiance into a displayable [0, 1] range:

        L_out = L * (1 + L / Lwhite^2) / (1 + L)
    """
    hdr_linear = np.clip(hdr_linear, 0.0, None)
    numerator = hdr_linear * (1.0 + hdr_linear / (white_point ** 2))
    return numerator / (1.0 + hdr_linear)


def stops_of_headroom(mean_signal_fraction: float, dr_report: DynamicRangeReport) -> float:
    """Given the mean signal as a fraction of full well (0..1), how many
    stops of highlight headroom remain before clipping.
    """
    mean_signal_fraction = max(mean_signal_fraction, 1e-6)
    return float(np.log2(1.0 / mean_signal_fraction))
