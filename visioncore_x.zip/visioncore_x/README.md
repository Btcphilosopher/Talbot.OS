# VISIONCORE-X

**16K Camera System Simulator & Photonic Imaging Prototyper**

A modular, end-to-end digital twin of a next-generation 16K digital camera
system: optics -> sensor -> exposure -> ISP -> compression -> storage,
with physically-grounded noise, bandwidth, and performance modelling
throughout. ~4,900 lines of Python across 15 subsystems, 58 passing tests.

```
Light Scene -> Lens Optics -> Sensor Array -> Signal Conversion ->
Image Processing -> Compression -> Storage / Output
```

## Why this exists

16K (15360x8640, ~133 effective megapixels) is not "4K but bigger." At
that pixel count, pixel pitch shrinks into the 1-3 micron range on a
full-frame-sized die, which drags several once-theoretical constraints
into the centre of the design:

- **Diffraction becomes the resolution limit**, not the lens or the
  sensor alone (`optics/diffraction.py`).
- **Full-well capacity collapses** with pixel area, so dynamic range and
  noise floor become tight, ISO-sensitive budgets
  (`sensor/dynamic_range.py`, `sensor/cmos_model.py`).
- **Sensor readout time and heat** scale with pixel count and frame
  rate, capping achievable fps before ISP/codec/storage even enter the
  picture (`sensor/readout_noise.py`, `sensor/cmos_model.py`).
- **Compression and storage bandwidth** become the practical ceiling on
  sustained capture: a single uncompressed 16K frame is hundreds of MB
  (`compression/`, `storage/`).

VISIONCORE-X makes every one of those trade-offs an explicit, computed
number instead of an assumption -- per the project constraint: *no fake
constant-resolution assumptions; resolution degrades realistically under
real constraints.*

## Architecture

```
visioncore_x/
├── core/                 engine.py, simulation_loop.py, frame_clock.py
├── optics/                lens_model, diffraction, aperture_sim, focal_geometry
├── sensor/                cmos_model, pixel_array, readout_noise, dynamic_range
├── imaging/                exposure, iso_gain, white_balance, colour_filter_array
├── signal_processing/    demosaic, sharpening, noise_reduction, hdr_pipeline
├── resolution/            resolution_engine, aliasing_model, oversampling
├── compression/            image_codec, encoder_16k, bandwidth_model
├── storage/                buffer_manager, write_pipeline
├── physics/                light_transport, photon_noise
├── workload/                scene_generator, motion_simulation
├── performance/            frame_rate, latency, data_rate
├── optimisation/            exposure_optimizer, compression_optimizer
├── visualization/            image_viewer, sensor_heatmap, optical_flow, dashboard
├── utils/                    logging, config
├── main.py
└── tests/                    58 tests across 8 files
```

> **Note on `16k_encoder.py`:** Python module names cannot start with a
> digit, so the architecture's `compression/16k_encoder.py` is
> implemented as `compression/encoder_16k.py` (`import
> compression.encoder_16k`). Everything else follows the brief's layout
> exactly.

## The two-resolution model (read this first)

A real 16K frame is ~133 megapixels x 3 channels x 4 bytes (float) =
**over 1.5 GB per frame** as a raw numpy array. Simulating every pixel
of every frame numerically would make this simulator unusable on a
laptop. VISIONCORE-X resolves that with a deliberate split:

- **Analytical layer** (timing, bandwidth, dynamic range, readout,
  power/heat, compression ratio): computed directly from the *true* 16K
  `SensorConfig` -- these numbers are always for the real sensor
  specification, never scaled down.
- **Array layer** (scene rendering, sensor capture, demosaic, ISP,
  visualisation): runs on a **preview grid**, downscaled from the true
  sensor resolution by `SimulationConfig.preview_scale` (default
  1/40th per side). Each preview site simulates one *true-sized*
  photosite (same pitch, full well, QE, and noise as the real 16K
  sensor) sampled sparsely across the sensor area -- so per-pixel
  saturation/SNR/noise numbers on the array side stay directly
  comparable to the analytical true-sensor numbers. See
  `resolution/resolution_engine.py` for the full rationale and
  `core/engine.py`'s module docstring for how kernel sizes (diffraction
  blur, motion blur) are converted between the two scales.

Every report the CLI prints states which regime a number belongs to.

## Installation

```bash
pip install -r requirements.txt
```

Only **numpy** is a hard requirement -- every formula in the engine core
is pure numpy + stdlib. `scipy` and `matplotlib` are optional and
degrade gracefully: `signal_processing/demosaic.py` falls back to a
numpy-only convolution if scipy is absent, and the entire
`visualization/` package raises a clear `RuntimeError` (not an import
crash) if matplotlib is missing, only when you actually try to render.

## Quick start

```bash
# Default run: 16K FUHD sensor, 30 frames, studio scene
python main.py

# A more interesting run: dim scene, wide aperture, visualise everything
python main.py --frames 60 --scene low_light --f-number 1.4 --iso 3200 --visualize

# Compare 8K vs 16K bandwidth/fps reality
python main.py --resolution 8K_UHD --frames 24 --quiet
python main.py --resolution 16K_FUHD --frames 24 --quiet

# Save/load a camera configuration
python main.py --save-config my_camera.json
python main.py --config my_camera.json --frames 100

# Export per-frame telemetry for external analysis
python main.py --frames 120 --metrics-csv run_metrics.csv
```

Run `python main.py --help` for the full flag list (resolution preset,
lens/exposure/codec/storage overrides, scene and motion type, preview
scale, random seed, etc).

## What one run reports

```
VISIONCORE-X CameraConfig: 15360x8640 (132.7 MP), 50mm f/2.8, ISO 400, ...
========================================================================
VISIONCORE-X SIMULATION SUMMARY
========================================================================
  Frames simulated:            30
  Nominal sensor resolution:   132.7 MP (true 16K)
  Mean effective resolution:   45.4 MP (34.2% of nominal)   <- optics+noise+aliasing derated
  Mean SNR:                    36.5 dB
  Mean dynamic range:          11.7 stops
  Mean achievable frame rate:  6.78 fps                     <- bottlenecked by ISP/encode, see below
  Mean compressed frame size:  116.1 MB
  Mean compression ratio:      5.7x
  Total data written:          3.4 GB
  Dropped frames:              0
  Latency p50/p95/p99 (ms):    250.0 / 273.6 / 283.7
  Mean sensor die temperature: 134.1 C                       <- flags an unsustainable thermal design
========================================================================
```

That die-temperature figure is not a typo or a display bug -- it is the
simulator correctly reporting that a naive 16K/24fps sensor spec, scaled
up from an 8K thermal-design-power reference point with a simple lumped
thermal-resistance model, is **not thermally viable** without a
materially better cooling/power design. That is the intended behaviour:
the constraint list explicitly forbids hiding limits like this.

## Visualisation (`--visualize`)

Writes to `<output-dir>/visualizations/`:

- `frame_XXXX_final.png` -- final ISP output preview
- `frame_XXXX_pipeline.png` -- raw Bayer mosaic vs. final output, side by side
- `frame_XXXX_heatmap.png` -- per-pixel electron-count heatmap (sensor lab view)
- `frame_XXXX_saturation.png` -- magenta overlay marking clipped (full-well) pixels
- `lens_distortion.png` -- barrel/pincushion distortion grid overlay
- `rolling_shutter_skew.png` -- per-row capture-time skew from rolling shutter readout
- `latency_dashboard.png` -- per-stage pipeline latency breakdown + end-to-end percentile histogram
- `compression_tradeoff.png` -- rate/distortion curve swept across the codec's quality range

## Testing

```bash
pytest tests/ -q      # 58 tests: unit tests per subsystem + full end-to-end engine smoke tests
```

The smoke tests in `tests/test_engine_smoke.py` run the *actual*
`VisionCoreEngine` pipeline end to end (not mocks) and assert on
physically-sane relationships: low light -> lower SNR, slow storage ->
dropped frames, all-finite pixel output, etc.

## Design notes / where the physics comes from

- **Diffraction**: Rayleigh Airy-disk radius and the closed-form
  circular-aperture diffraction MTF.
- **Exposure**: classic EV = log2(N^2/t) triangle; ISO modelled as
  analog gain up to a configurable ceiling, spilling into a
  more-heavily-penalised digital gain beyond it.
- **Noise**: Poisson shot noise sampled directly from the photon domain,
  dark current scaled by an Arrhenius-like doubling-per-6.5C rule,
  read/ADC noise in quadrature, full photon-transfer SNR model.
- **Demosaicing**: bilinear and Malvar-He-Cutler gradient-corrected
  Bayer reconstruction.
- **HDR**: Mertens-style well-exposedness + contrast-weighted exposure
  fusion, Reinhard tone mapping.
- **Compression**: a calibrated rate-distortion *model* (not a bit-exact
  codec) with per-profile bpp/quality curves for raw, lossless,
  ProRes-like, and HEVC-like presets, plus tile-parallel encode-time
  estimation.
- **Performance**: pipeline bottleneck = max(sensor readout, ISP,
  encode, write) per frame, all computed analytically at true 16K
  resolution.

## Known limitations (by design)

- The compression model is a rate/distortion approximation, not a
  bit-exact encoder -- there is no decodable bitstream.
- The optical model is a simplified radiometric chain (Lambertian
  scene, paraxial lens), calibrated for realistic *relative* behaviour
  rather than absolute photometric accuracy.
- Default constants (thermal resistance, ISP throughput, encode
  throughput) are documented estimates, not measurements from real
  hardware -- override them via `--config` / `CameraConfig` for your own
  reference points.
