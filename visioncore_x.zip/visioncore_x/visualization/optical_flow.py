"""
visualization.optical_flow
============================
Visual overlays for geometric/motion effects: lens distortion grid,
rolling-shutter skew arrows, and a simple sparse motion-vector field for
the workload.motion_simulation camera-motion profile.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from visualization.image_viewer import _HAS_MPL, _require_mpl

if _HAS_MPL:
    import matplotlib.pyplot as plt


def plot_distortion_grid(width: int, height: int, k1: float, k2: float, path: str | Path, grid_step: int = 10) -> str:
    """Visualise geometric lens distortion by rendering an undistorted
    regular grid alongside its distorted counterpart (optics.lens_model's
    radial_distortion_map).
    """
    _require_mpl()
    from optics.lens_model import radial_distortion_map

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    src_y, src_x = radial_distortion_map(width, height, k1, k2)

    fig, ax = plt.subplots(figsize=(6, 4), dpi=140)
    for gy in range(0, height, max(height // grid_step, 1)):
        ax.plot(src_x[gy, :], src_y[gy, :], color="#3b82f6", linewidth=0.6)
    for gx in range(0, width, max(width // grid_step, 1)):
        ax.plot(src_x[:, gx], src_y[:, gx], color="#3b82f6", linewidth=0.6)

    ax.invert_yaxis()
    ax.set_aspect("equal")
    ax.set_title(f"Lens Distortion Overlay (k1={k1:.4f}, k2={k2:.4f})", fontsize=10)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def plot_motion_vector_field(height: int, width: int, pan_deg_s: float, tilt_deg_s: float, path: str | Path, density: int = 14) -> str:
    """Render a uniform motion-vector field representing pure camera
    pan/tilt -- every point in the frame moves with the same vector under
    a rotation-only camera motion model (small-angle approximation).
    """
    _require_mpl()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    ys = np.linspace(0, height - 1, density)
    xs = np.linspace(0, width - 1, density)
    xx, yy = np.meshgrid(xs, ys)

    # Uniform translation field scaled from pan/tilt rates for visual
    # clarity (arrow length is illustrative, not metrically calibrated
    # here -- see optics.focal_geometry for the calibrated pixel figure).
    u = np.full_like(xx, pan_deg_s)
    v = np.full_like(yy, tilt_deg_s)

    fig, ax = plt.subplots(figsize=(6, 4), dpi=140)
    ax.quiver(xx, yy, u, v, color="#ef4444", angles="xy", scale_units="xy", scale=1.0)
    ax.set_xlim(0, width)
    ax.set_ylim(height, 0)
    ax.set_title(f"Camera Motion Field (pan={pan_deg_s:.1f}°/s, tilt={tilt_deg_s:.1f}°/s)", fontsize=10)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def plot_rolling_shutter_skew(height: int, skew_ms: float, path: str | Path) -> str:
    """Simple diagram of per-row capture-time delay across a rolling-
    shutter readout, to visualise where "jello" distortion comes from.
    """
    _require_mpl()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    rows = np.arange(height)
    row_time_ms = (rows / max(height - 1, 1)) * skew_ms

    fig, ax = plt.subplots(figsize=(6, 3.5), dpi=140)
    ax.plot(row_time_ms, rows, color="#22c55e")
    ax.invert_yaxis()
    ax.set_xlabel("Row capture time offset (ms)")
    ax.set_ylabel("Row index")
    ax.set_title(f"Rolling Shutter Skew ({skew_ms:.2f} ms full-frame)", fontsize=10)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)
