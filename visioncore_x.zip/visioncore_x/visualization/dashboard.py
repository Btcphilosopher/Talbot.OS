"""
visualization.dashboard
=========================
Higher-level "engineering lab" dashboards that summarise a whole
simulation run rather than a single frame: the frame-pipeline latency
breakdown (per-stage bar chart + end-to-end percentile summary) and the
compression rate/distortion sweep. These are the two multi-frame charts
called out explicitly in the project brief's visualisation layer.
"""
from __future__ import annotations

from pathlib import Path
from typing import List

import numpy as np

from compression.image_codec import CompressionConfig, estimate_frame_size_bytes, estimate_quality_score
from performance.latency import LatencyTracker
from utils.config import SensorConfig
from visualization.image_viewer import _HAS_MPL, _require_mpl

if _HAS_MPL:
    import matplotlib.pyplot as plt


def plot_latency_dashboard(tracker: LatencyTracker, path: str | Path) -> str:
    """Two-panel dashboard: mean per-stage duration (bar chart) alongside
    the distribution of end-to-end per-frame latency with p50/p95/p99
    markers -- the standard "where is the frame pipeline spending its
    time, and how bad is the tail" view.
    """
    _require_mpl()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    stage_breakdown = tracker.stage_breakdown_ms()
    totals = tracker.all_total_latencies_ms()
    percentiles = tracker.percentiles()

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.2), dpi=130)

    stages = list(stage_breakdown.keys())
    values = [stage_breakdown[s] for s in stages]
    colors = plt.cm.viridis(np.linspace(0.15, 0.85, len(stages))) if stages else []
    ax1.bar(stages, values, color=colors)
    ax1.set_ylabel("Mean stage duration (ms)")
    ax1.set_title("Pipeline Stage Breakdown", fontsize=10)
    ax1.tick_params(axis="x", rotation=25)

    if totals.size:
        ax2.hist(totals, bins=min(20, max(len(totals), 1)), color="#3b82f6", alpha=0.8)
        for label, color in (("p50", "#22c55e"), ("p95", "#f59e0b"), ("p99", "#ef4444")):
            ax2.axvline(percentiles[label], color=color, linestyle="--", label=f"{label}={percentiles[label]:.1f}ms")
        ax2.legend(fontsize=8)
    ax2.set_xlabel("End-to-end frame latency (ms)")
    ax2.set_ylabel("Frame count")
    ax2.set_title("Latency Distribution", fontsize=10)

    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def sweep_compression_quality(sensor_cfg: SensorConfig, codec: str, n_points: int = 12):
    """Sweep the quality dial for a codec profile and return
    (qualities, sizes_mb, scores) -- the raw data behind the rate/
    distortion curve plotted below.
    """
    qualities = np.linspace(0.02, 1.0, n_points)
    sizes_mb: List[float] = []
    scores: List[float] = []
    for q in qualities:
        cfg = CompressionConfig(codec=codec, quality=float(q))
        size_bytes = estimate_frame_size_bytes(sensor_cfg, cfg, channels=3)
        sizes_mb.append(size_bytes / (1024 * 1024))
        scores.append(estimate_quality_score(cfg))
    return list(qualities), sizes_mb, scores


def plot_compression_sweep(sensor_cfg: SensorConfig, codec: str, path: str | Path, n_points: int = 12) -> str:
    """Convenience wrapper: sweep + plot in one call, reusing
    visualization.sensor_heatmap.plot_compression_tradeoff for rendering.
    """
    from visualization.sensor_heatmap import plot_compression_tradeoff

    qualities, sizes_mb, scores = sweep_compression_quality(sensor_cfg, codec, n_points)
    return plot_compression_tradeoff(qualities, sizes_mb, scores, path)
