"""
visualization.image_viewer
============================
Frame preview rendering and saving. Matplotlib is used only if installed
(guarded import) -- the simulator's numeric core never depends on it, so
headless / minimal environments can still run the full pipeline and just
skip visual output.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

try:
    import matplotlib

    matplotlib.use("Agg")  # headless-safe backend
    import matplotlib.pyplot as plt

    _HAS_MPL = True
except ImportError:  # pragma: no cover - environment dependent
    _HAS_MPL = False


def _require_mpl() -> None:
    if not _HAS_MPL:
        raise RuntimeError(
            "matplotlib is not installed; visualization.image_viewer requires it "
            "(`pip install matplotlib`). The simulation itself does not need it."
        )


def normalize_for_display(image: np.ndarray, percentile_clip: float = 99.5) -> np.ndarray:
    """Percentile-clip and rescale a linear/float image to [0, 1] for
    display, robust to a few blown-out highlight pixels dominating the
    scale.
    """
    img = image.astype(np.float64)
    hi = np.percentile(img, percentile_clip)
    hi = max(hi, 1e-6)
    normalized = np.clip(img / hi, 0.0, 1.0)
    return normalized


def save_frame_png(image: np.ndarray, path: str | Path, title: str | None = None) -> str:
    """Save a preview frame to a PNG for visual inspection."""
    _require_mpl()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    display_img = normalize_for_display(image)
    fig, ax = plt.subplots(figsize=(8, 4.5), dpi=140)
    # vmin/vmax pinned explicitly: matplotlib's default autoscale maps a
    # perfectly uniform array (e.g. a fully-saturated frame) to the
    # bottom of the colormap regardless of its actual value, which would
    # silently render a blown-out-white frame as solid black.
    if display_img.ndim == 3:
        ax.imshow(display_img, vmin=0.0, vmax=1.0)
    else:
        ax.imshow(display_img, cmap="gray", vmin=0.0, vmax=1.0)
    ax.set_axis_off()
    if title:
        ax.set_title(title, fontsize=10)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def save_side_by_side(images: list, titles: list, path: str | Path) -> str:
    """Save a row of preview frames (e.g. raw vs. demosaiced vs. final)
    for pipeline-stage comparison.
    """
    _require_mpl()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    n = len(images)
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 4.2), dpi=130)
    if n == 1:
        axes = [axes]
    for ax, img, title in zip(axes, images, titles):
        disp = normalize_for_display(img)
        if disp.ndim == 3:
            ax.imshow(disp, vmin=0.0, vmax=1.0)
        else:
            ax.imshow(disp, cmap="gray", vmin=0.0, vmax=1.0)
        ax.set_title(title, fontsize=9)
        ax.set_axis_off()
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)
