"""
visualization.sensor_heatmap
==============================
Sensor-level diagnostic visualisations: pixel-intensity heatmap,
per-pixel noise-standard-deviation map, and saturation/clipping overlay.
These read straight off sensor.pixel_array state and are the "lab
instrument" view of the simulator, as opposed to image_viewer's
"photographic" preview.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from visualization.image_viewer import _HAS_MPL, _require_mpl

if _HAS_MPL:
    import matplotlib.pyplot as plt


def plot_intensity_heatmap(electron_array: np.ndarray, path: str | Path, title: str = "Sensor Pixel Intensity (e-)") -> str:
    _require_mpl()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    if electron_array.ndim == 3:
        data = electron_array.mean(axis=2)
    else:
        data = electron_array

    fig, ax = plt.subplots(figsize=(7, 4), dpi=140)
    im = ax.imshow(data, cmap="inferno")
    ax.set_title(title, fontsize=10)
    ax.set_axis_off()
    fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02, label="electrons")
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def plot_noise_map(before: np.ndarray, after: np.ndarray, path: str | Path, window: int = 8) -> str:
    """Local standard-deviation map (windowed) of the residual between two
    frames -- used to visualise, e.g., the effect of denoising on
    spatially-varying noise, or shot-noise texture at high ISO.
    """
    _require_mpl()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    residual = (after.astype(np.float64) - before.astype(np.float64))
    if residual.ndim == 3:
        residual = residual.mean(axis=2)

    h, w = residual.shape
    h_trim, w_trim = (h // window) * window, (w // window) * window
    trimmed = residual[:h_trim, :w_trim]
    blocks = trimmed.reshape(h_trim // window, window, w_trim // window, window)
    local_std = blocks.std(axis=(1, 3))

    fig, ax = plt.subplots(figsize=(7, 4), dpi=140)
    im = ax.imshow(local_std, cmap="magma")
    ax.set_title("Local Noise Std. Dev. Map", fontsize=10)
    ax.set_axis_off()
    fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def plot_saturation_overlay(image: np.ndarray, saturated_mask: np.ndarray, path: str | Path) -> str:
    _require_mpl()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    from visualization.image_viewer import normalize_for_display

    disp = normalize_for_display(image)
    overlay = disp.copy()
    mask_2d = saturated_mask.any(axis=2) if saturated_mask.ndim == 3 else saturated_mask
    overlay[mask_2d] = [1.0, 0.0, 1.0]  # magenta clipping indicator

    fig, ax = plt.subplots(figsize=(7, 4), dpi=140)
    ax.imshow(overlay)
    ax.set_title(f"Saturation Overlay ({100*mask_2d.mean():.2f}% clipped)", fontsize=10)
    ax.set_axis_off()
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def plot_compression_tradeoff(qualities: list, sizes_mb: list, scores: list, path: str | Path) -> str:
    """Dual-axis chart of compressed size vs. quality-score across a
    swept quality range -- the classic rate-distortion curve.
    """
    _require_mpl()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    fig, ax1 = plt.subplots(figsize=(7, 4.2), dpi=140)
    ax1.plot(qualities, sizes_mb, color="#3b82f6", marker="o", label="Frame size (MB)")
    ax1.set_xlabel("Quality setting")
    ax1.set_ylabel("Frame size (MB)", color="#3b82f6")

    ax2 = ax1.twinx()
    ax2.plot(qualities, scores, color="#ef4444", marker="s", label="Quality score")
    ax2.set_ylabel("Quality score (0-100)", color="#ef4444")

    ax1.set_title("Compression Rate/Distortion Trade-off", fontsize=10)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)
