"""
physics.photon_noise
=====================
Fundamental (shot) noise arising from the quantised, stochastic nature of
light. Photon arrivals follow a Poisson process, so any real capture of a
mean photon count ``lambda`` has an irreducible standard deviation of
``sqrt(lambda)`` -- this is the noise floor no amount of sensor
engineering can remove, and it dominates the noise budget at low ISO /
bright scenes, while read/dark noise dominate at high ISO / dim scenes.
"""
from __future__ import annotations

import numpy as np


def sample_shot_noise(mean_photons: np.ndarray, rng: np.random.Generator | None = None) -> np.ndarray:
    """Draw a Poisson-distributed photon count for each site given its
    expected value. Falls back to a Gaussian approximation for very large
    means (numerically identical in distribution, much faster).
    """
    rng = rng or np.random.default_rng()
    mean_photons = np.clip(mean_photons, 0.0, None)
    out = np.empty_like(mean_photons, dtype=np.float64)

    large = mean_photons > 1e5
    if np.any(large):
        out[large] = rng.normal(mean_photons[large], np.sqrt(mean_photons[large]))
    small = ~large
    if np.any(small):
        # np.random.Generator.poisson requires lam < 2**63 and works well
        # up to ~1e5-1e6; safe here since `large` already peeled those off.
        out[small] = rng.poisson(mean_photons[small]).astype(np.float64)
    return np.clip(out, 0.0, None)


def shot_noise_std(mean_photons: np.ndarray | float) -> np.ndarray | float:
    """Analytic shot-noise standard deviation, sqrt(N)."""
    return np.sqrt(np.clip(mean_photons, 0.0, None))


def photon_transfer_snr(mean_electrons: np.ndarray | float, read_noise_e: float, dark_noise_e: float) -> np.ndarray | float:
    """Signal-to-noise ratio combining shot noise, read noise and dark
    (thermal) noise in quadrature -- the standard photon-transfer model:

        SNR = S / sqrt(S + read_noise^2 + dark_noise^2)

    where S is the mean signal in electrons.
    """
    mean_electrons = np.clip(mean_electrons, 1e-9, None)
    total_noise = np.sqrt(mean_electrons + read_noise_e ** 2 + dark_noise_e ** 2)
    return mean_electrons / total_noise


def snr_db(snr_linear: np.ndarray | float) -> np.ndarray | float:
    return 20.0 * np.log10(np.clip(snr_linear, 1e-9, None))
