"""
physics.light_transport
========================
Radiometric / photometric plumbing that converts a scene description into
photon flux arriving at the sensor plane, through the lens.

Chain modelled:

    scene luminance (cd/m^2)
        -> scene illuminance at lens entrance (lux), via solid angle
        -> irradiance at sensor plane (W/m^2), via aperture + transmission
        -> photon flux density (photons / s / m^2), via photon energy
        -> photons per pixel per exposure, via pixel area + exposure time

This is deliberately a simplified radiometric model (Lambertian scene,
paraxial lens) -- adequate for driving realistic *relative* behaviour
(more light -> more electrons -> less noise; smaller aperture -> less
light; vignetting -> corner falloff) without requiring a full spectral
renderer.
"""
from __future__ import annotations

import numpy as np

PLANCK_H = 6.62607015e-34       # J*s
SPEED_OF_LIGHT = 2.99792458e8   # m/s
LUMINOUS_EFFICACY = 683.0       # lm/W at 555nm, used for lux<->radiometric conversion
DEFAULT_WAVELENGTH_NM = 555.0   # green, photopic peak


def photon_energy_j(wavelength_nm: float = DEFAULT_WAVELENGTH_NM) -> float:
    """Energy of a single photon at the given wavelength, in Joules."""
    wavelength_m = wavelength_nm * 1e-9
    return PLANCK_H * SPEED_OF_LIGHT / wavelength_m


def scene_luminance_to_illuminance(
    luminance_cd_m2: np.ndarray | float,
    solid_angle_sr: float = np.pi,
) -> np.ndarray | float:
    """Convert Lambertian scene luminance to illuminance at the lens (lux).

    A simple flat-scene approximation: E = L * omega, with omega the
    effective collecting solid angle (pi sr for a diffuse hemisphere,
    reduced by the lens field of view in practice).
    """
    return luminance_cd_m2 * solid_angle_sr


def illuminance_to_irradiance_w_m2(illuminance_lux: np.ndarray | float) -> np.ndarray | float:
    """Photometric (lux) -> radiometric (W/m^2) using the luminous efficacy
    constant. Approximate but standard for camera-exposure modelling.
    """
    return illuminance_lux / LUMINOUS_EFFICACY


def lens_transmitted_irradiance(
    irradiance_w_m2: np.ndarray | float,
    f_number: float,
    transmission: float,
) -> np.ndarray | float:
    """Irradiance reaching the sensor plane after the lens aperture and
    optical transmission losses.

    The classic photographic exposure relation states that image-plane
    illuminance scales as 1 / N^2 (N = f-number) relative to scene
    illuminance, for a fixed scene luminance and lens transmission tau:

        E_sensor = (pi / 4) * tau * L / N^2   (in appropriate units)

    Here we already folded L into `irradiance_w_m2` via the caller, so we
    just apply the 1/N^2 falloff and transmission loss directly.
    """
    return irradiance_w_m2 * transmission / (f_number ** 2)


def apply_vignetting(
    irradiance_map: np.ndarray,
    strength: float = 0.35,
) -> np.ndarray:
    """Apply a cos^4-law-like radial illumination falloff (natural
    vignetting), parameterised by relative corner darkening `strength`
    (0 = none, 1 = fully black corners).
    """
    h, w = irradiance_map.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
    cy, cx = (h - 1) / 2.0, (w - 1) / 2.0
    r = np.sqrt(((yy - cy) / (h / 2.0)) ** 2 + ((xx - cx) / (w / 2.0)) ** 2)
    r = np.clip(r, 0.0, np.sqrt(2.0))
    falloff = 1.0 - strength * (r ** 2) / 2.0
    falloff = np.clip(falloff, 0.0, 1.0)
    if irradiance_map.ndim == 3:
        falloff = falloff[..., None]
    return irradiance_map * falloff


def irradiance_to_photon_flux(
    irradiance_w_m2: np.ndarray | float,
    wavelength_nm: float = DEFAULT_WAVELENGTH_NM,
) -> np.ndarray | float:
    """Convert irradiance (W/m^2) to photon flux density (photons / s / m^2)."""
    return irradiance_w_m2 / photon_energy_j(wavelength_nm)


def photons_per_pixel(
    photon_flux_density: np.ndarray | float,
    pixel_area_m2: float,
    exposure_time_s: float,
) -> np.ndarray | float:
    """Total photon count collected by a pixel of given area over the
    exposure interval.
    """
    return photon_flux_density * pixel_area_m2 * exposure_time_s


def scene_to_photon_map(
    scene_luminance: np.ndarray,
    f_number: float,
    transmission: float,
    vignetting_strength: float,
    pixel_area_m2: float,
    exposure_time_s: float,
) -> np.ndarray:
    """End-to-end helper: scene luminance map -> expected photon count map
    at the sensor, before quantum efficiency / photon noise are applied.
    """
    illum = scene_luminance_to_illuminance(scene_luminance)
    irr = illuminance_to_irradiance_w_m2(illum)
    irr = lens_transmitted_irradiance(irr, f_number, transmission)
    irr = apply_vignetting(irr, vignetting_strength)
    flux = irradiance_to_photon_flux(irr)
    return photons_per_pixel(flux, pixel_area_m2, exposure_time_s)
