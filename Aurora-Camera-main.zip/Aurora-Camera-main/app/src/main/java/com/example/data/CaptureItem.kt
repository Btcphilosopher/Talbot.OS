package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "captures")
data class CaptureItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val timestamp: Long = System.currentTimeMillis(),
    val mode: String, // "PHOTO", "VIDEO", "SPATIAL", "3D_SCAN"
    val focalLength: Float, // e.g. 50f
    val iso: Int,
    val shutterSpeed: String, // e.g. "1/250"
    val aperture: Float, // e.g. 1.4f
    val style: String, // "NATURAL", "CINEMATIC", "MONOCHROME", "NEUTRAL"
    val hasDepth: Boolean,
    val hasRaw: Boolean,
    val latitude: Double? = null,
    val longitude: Double? = null,
    
    // Non-destructive editing parameters
    val editExposure: Float = 0.0f, // -3.0f to +3.0f
    val editContrast: Float = 1.0f, // 0.5f to 2.0f
    val editSharpness: Float = 1.0f, // 0.0f to 2.0f
    val editDepthBlur: Float = 0.0f, // 0.0f to 5.0f (portrait blur)
    val editSaturation: Float = 1.0f, // 0.0f to 2.0f
    val editPerspective: Float = 0.0f, // correction factor
    val editDistortion: Float = 0.0f,
    
    val processingHistory: String = "Multi-Frame HDR | Raw Calibration | Noise Reduction"
) : Serializable
