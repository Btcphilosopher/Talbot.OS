package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "camera_settings")
data class CameraSettings(
    @PrimaryKey val id: Int = 1,
    val preferredMode: String = "PHOTO",
    val preferredFocalLength: Float = 50f, // 50mm is 1x
    val iso: Int = 100, // 0 means Auto
    val shutterSpeed: String = "1/125", // "AUTO" or fractional shutter
    val whiteBalance: String = "AUTO", // "AUTO", "5600K", "3200K", "6500K"
    val formatPreference: String = "BALANCED", // "RAW", "RAW+JPEG", "BALANCED", "HEIF"
    val videoFps: Int = 24, // 24, 30, 60, 120
    val videoResolution: String = "4K_LOG", // "4K", "8K", "4K_LOG", "RAW_CINE"
    val imageStyle: String = "NATURAL", // "NATURAL", "CINEMATIC", "MONOCHROME", etc.
    val dynamicRangePreset: String = "HDR_MAX", // "HDR_MAX", "BALANCED", "STANDARD"
    val stabilizationMode: String = "OPTICAL_ACTIVE", // "OPTICAL_ACTIVE", "CINEMATIC_GLIDE", "OFF"
    
    // Auxiliary overlays enabled by default or saved state
    val showHistogram: Boolean = true,
    val showZebra: Boolean = false,
    val showPeaking: Boolean = false,
    val showFalseColor: Boolean = false,
    val thermalThrottlingLevel: Int = 0 // 0 = Cool, 1 = Warning (re-route pipeline), 2 = Throttled
)
