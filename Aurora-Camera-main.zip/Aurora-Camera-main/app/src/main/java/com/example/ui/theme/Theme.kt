package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AuroraColorScheme = darkColorScheme(
    primary = TechnicalTeal,
    onPrimary = ObsidianBlack,
    primaryContainer = ObsidianDark,
    onPrimaryContainer = PureWhite,
    secondary = WarmOrange,
    onSecondary = ObsidianBlack,
    secondaryContainer = ObsidianSurface,
    onSecondaryContainer = PureWhite,
    tertiary = HighResYellow,
    background = ObsidianBlack,
    onBackground = PureWhite,
    surface = ObsidianDark,
    onSurface = PureWhite,
    surfaceVariant = ObsidianSurface,
    onSurfaceVariant = MutedSlate,
    outline = BorderGrey
)

@Composable
fun AuroraTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AuroraColorScheme,
        typography = Typography,
        content = content
    )
}
