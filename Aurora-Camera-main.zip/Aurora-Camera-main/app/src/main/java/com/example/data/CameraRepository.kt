package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CameraRepository(private val cameraDao: CameraDao) {
    val allCaptures: Flow<List<CaptureItem>> = cameraDao.getAllCaptures()
    val cameraSettings: Flow<CameraSettings> = cameraDao.getCameraSettings().map { it ?: CameraSettings() }

    suspend fun getCaptureById(id: Long): CaptureItem? {
        return cameraDao.getCaptureById(id)
    }

    suspend fun insertCapture(capture: CaptureItem): Long {
        return cameraDao.insertCapture(capture)
    }

    suspend fun updateCapture(capture: CaptureItem) {
        cameraDao.updateCapture(capture)
    }

    suspend fun deleteCapture(capture: CaptureItem) {
        cameraDao.deleteCapture(capture)
    }

    suspend fun saveSettings(settings: CameraSettings) {
        cameraDao.insertOrUpdateSettings(settings)
    }
}
