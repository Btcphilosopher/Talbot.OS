package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.StateFlow
import com.example.data.PhotographicStyle
import com.example.ui.CameraEngineViewModel
import com.example.ui.theme.*

@Composable
fun ControlsSection(
    viewModel: CameraEngineViewModel,
    modifier: Modifier = Modifier
) {
    // Collect settings and parameters
    val selectedFocalLength by viewModel.selectedFocalLength.collectAsState()
    val selectedZoom by viewModel.selectedZoom.collectAsState()
    val selectedIso by viewModel.selectedIso.collectAsState()
    val selectedShutter by viewModel.selectedShutter.collectAsState()
    val selectedAperture by viewModel.selectedAperture.collectAsState()
    val selectedWB by viewModel.selectedWB.collectAsState()
    val selectedStyle by viewModel.selectedStyle.collectAsState()

    val isHdrOn by viewModel.isHdrOn.collectAsState()
    val isDenoiseOn by viewModel.isDenoiseOn.collectAsState()
    val isSuperResOn by viewModel.isSuperResOn.collectAsState()

    val showHist by viewModel.showHistogram.collectAsState()
    val showWave by viewModel.showWaveform.collectAsState()
    val showZebra by viewModel.showZebra.collectAsState()
    val showFC by viewModel.showFalseColor.collectAsState()
    val showPeak by viewModel.showFocusPeaking.collectAsState()

    val audioL by viewModel.audioLvlL.collectAsState()
    val audioR by viewModel.audioLvlR.collectAsState()

    var activeControlTab by remember { mutableStateOf("LENS") } // "LENS", "EXPOSURE", "FOCUS", "PIPELINE", "OVERLAYS"

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(ObsidianDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Tab Selection Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ControlTabButton("LENS", activeControlTab == "LENS") { activeControlTab = "LENS" }
            ControlTabButton("EXPOSURE", activeControlTab == "EXPOSURE") { activeControlTab = "EXPOSURE" }
            ControlTabButton("FOCUS", activeControlTab == "FOCUS") { activeControlTab = "FOCUS" }
            ControlTabButton("PIPELINE", activeControlTab == "PIPELINE") { activeControlTab = "PIPELINE" }
            ControlTabButton("MONITORS", activeControlTab == "OVERLAYS") { activeControlTab = "OVERLAYS" }
        }

        // Expanded Control Panel depending on active tab
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(ObsidianSurface)
                .border(0.5.dp, BorderGrey, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            when (activeControlTab) {
                "LENS" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "LENS SELECTOR & OPTICAL SWITCHING",
                            color = HighResYellow,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            LensButton("0.5×", "13mm", selectedFocalLength == 13f) { viewModel.setFocalLength(13f) }
                            LensButton("1.0×", "24mm", selectedFocalLength == 24f) { viewModel.setFocalLength(24f) }
                            LensButton("2.0×", "50mm", selectedFocalLength == 50f) { viewModel.setFocalLength(50f) }
                            LensButton("3.0×", "85mm", selectedFocalLength == 85f) { viewModel.setFocalLength(85f) }
                            LensButton("5.0×", "135mm", selectedFocalLength == 135f) { viewModel.setFocalLength(135f) }
                            LensButton("10.0×", "260mm", selectedFocalLength == 260f) { viewModel.setFocalLength(260f) }
                        }
                        
                        // Continuous micro-zoom slider
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "CONTINUOUS DIGITAL ROTARY DIAL", color = MutedSlate, fontSize = 9.sp)
                                Text(text = "${"%.1f".format(selectedZoom)}x", color = TechnicalTeal, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Slider(
                                value = selectedZoom,
                                onValueChange = { viewModel.setZoom(it) },
                                valueRange = 1.0f..10.0f,
                                colors = SliderDefaults.colors(
                                    thumbColor = TechnicalTeal,
                                    activeTrackColor = TechnicalTeal,
                                    inactiveTrackColor = BorderGrey
                                ),
                                modifier = Modifier.testTag("lens_dial")
                            )
                        }
                    }
                }

                "EXPOSURE" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "MANUAL GAIN & TIMING INDEX",
                            color = HighResYellow,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        // ISO Selector Scroll
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "ISO", color = MutedSlate, fontSize = 10.sp, modifier = Modifier.width(36.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(50, 100, 200, 400, 800, 1600, 3200, 6400).forEach { value ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (selectedIso == value) TechnicalTeal else BorderGrey)
                                            .clickable { viewModel.setIso(value) }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = value.toString(),
                                            color = if (selectedIso == value) ObsidianBlack else PureWhite,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // Shutter Selector Scroll
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "SHR", color = MutedSlate, fontSize = 10.sp, modifier = Modifier.width(36.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("1/1000", "1/500", "1/250", "1/125", "1/60", "1/30", "1s", "4s").forEach { value ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (selectedShutter == value) TechnicalTeal else BorderGrey)
                                            .clickable { viewModel.setShutter(value) }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = value,
                                            color = if (selectedShutter == value) ObsidianBlack else PureWhite,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // Aperture Control
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "APT", color = MutedSlate, fontSize = 10.sp, modifier = Modifier.width(36.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(1.2f, 1.4f, 1.8f, 2.8f, 4.0f, 5.6f, 8.0f).forEach { value ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (selectedAperture == value) TechnicalTeal else BorderGrey)
                                            .clickable { viewModel.setAperture(value) }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "f/$value",
                                            color = if (selectedAperture == value) ObsidianBlack else PureWhite,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                "FOCUS" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "COHERENT AF / MANUAL FOCAL PLANE",
                                color = HighResYellow,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Red.copy(alpha = 0.2f))
                                    .border(0.5.dp, Color.Red, RoundedCornerShape(4.dp))
                                    .clickable { viewModel.toggleFocusPeaking() }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "PEAKING ${if (showPeak) "ON" else "OFF"}",
                                    color = Color.Red,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Focus Pullers (Automatic preset transits)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { viewModel.initiateFocusPull(0.3f) },
                                colors = ButtonDefaults.buttonColors(containerColor = BorderGrey),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Macro (0.3m)", color = PureWhite, fontSize = 9.sp)
                            }
                            Button(
                                onClick = { viewModel.initiateFocusPull(2.0f) },
                                colors = ButtonDefaults.buttonColors(containerColor = BorderGrey),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Portrait (2m)", color = PureWhite, fontSize = 9.sp)
                            }
                            Button(
                                onClick = { viewModel.initiateFocusPull(10.0f) },
                                colors = ButtonDefaults.buttonColors(containerColor = BorderGrey),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Infinity", color = PureWhite, fontSize = 9.sp)
                            }
                        }

                        // Manual Slider
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "MANUAL FOCUS DISTANCE", color = MutedSlate, fontSize = 9.sp)
                                Text(
                                    text = if (viewModel.simulationEngine.focusDistance > 9.0f) "INFINITY (∞)" else "${"%.2f".format(viewModel.simulationEngine.focusDistance)}m",
                                    color = TechnicalTeal,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Slider(
                                value = viewModel.simulationEngine.focusDistance,
                                onValueChange = {
                                    viewModel.simulationEngine.focusDistance = it
                                    viewModel.simulationEngine.manualFocusState = it
                                },
                                valueRange = 0.2f..10.0f,
                                colors = SliderDefaults.colors(
                                    thumbColor = TechnicalTeal,
                                    activeTrackColor = TechnicalTeal,
                                    inactiveTrackColor = BorderGrey
                                )
                            )
                        }
                    }
                }

                "PIPELINE" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "COMPUTATIONAL CO-PROCESSORS (DSP / ISP)",
                            color = HighResYellow,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        // Switches for algorithms
                        PipelineToggleRow(
                            title = "Exposure Fusion (Multi-frame HDR)",
                            desc = "Fuses short/medium/long bracket frames without haloing",
                            checked = viewModel.isHdrOn,
                            onCheckedChange = { viewModel.isHdrOn.value = it; viewModel.simulationEngine.isHdrEnabled = it }
                        )

                        PipelineToggleRow(
                            title = "Temporal Denoise (8-Frame Statistics)",
                            desc = "Filters sensor noise dynamically under low illumination",
                            checked = viewModel.isDenoiseOn,
                            onCheckedChange = { viewModel.isDenoiseOn.value = it; viewModel.simulationEngine.isLowLightDenoiseEnabled = it }
                        )

                        PipelineToggleRow(
                            title = "Multi-Frame Super-Resolution",
                            desc = "Extracts true structural detail through sub-pixel offsets",
                            checked = viewModel.isSuperResOn,
                            onCheckedChange = { viewModel.isSuperResOn.value = it; viewModel.simulationEngine.isSuperResolutionEnabled = it }
                        )
                    }
                }

                "OVERLAYS" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "SIGNAL ANALYSERS & PHOTOGRAPHY STYLES",
                            color = HighResYellow,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        // Grid of overlay options
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OverlayIndicatorCard("HIST", viewModel.showHistogram, Icons.Default.BarChart) { viewModel.toggleHistogram() }
                            OverlayIndicatorCard("WAVE", viewModel.showWaveform, Icons.Default.Timeline) { viewModel.toggleWaveform() }
                            OverlayIndicatorCard("ZEBRA", viewModel.showZebra, Icons.Default.Warning) { viewModel.toggleZebra() }
                            OverlayIndicatorCard("FALSE", viewModel.showFalseColor, Icons.Default.Palette) { viewModel.toggleFalseColor() }
                        }

                        // Style profiles curves selection
                        Text(
                            text = "REPRODUCIBLE MATHEMATICAL PROFILES",
                            color = MutedSlate,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            PhotographicStyle.values().forEach { style ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selectedStyle == style) TechnicalTeal else BorderGrey)
                                        .clickable { viewModel.setStyle(style) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = style.displayName,
                                            color = if (selectedStyle == style) ObsidianBlack else PureWhite,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Con: ${style.contrastScale}x | Sat: ${style.saturationScale}x",
                                            color = if (selectedStyle == style) ObsidianDark.copy(alpha = 0.7f) else MutedSlate,
                                            fontSize = 8.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Professional Audio Stereo Monitor Meter
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(ObsidianSurface)
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.Mic, contentDescription = "Mic", tint = TechnicalTeal, modifier = Modifier.size(12.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                AudioBar(level = audioL, label = "L")
                AudioBar(level = audioR, label = "R")
            }
            Text(
                text = "${"-%.1f".format(35 * (1 - audioL))} dB",
                color = MutedSlate,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun ControlTabButton(text: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (active) TechnicalTeal else Color.Transparent)
            .border(1.dp, if (active) Color.Transparent else BorderGrey, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = if (active) ObsidianBlack else PureWhite,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun LensButton(label: String, equiv: String, active: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (active) TechnicalTeal else BorderGrey)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            color = if (active) ObsidianBlack else PureWhite,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = equiv,
            color = if (active) ObsidianDark.copy(alpha = 0.8f) else MutedSlate,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun PipelineToggleRow(
    title: String,
    desc: String,
    checked: StateFlow<Boolean>,
    onCheckedChange: (Boolean) -> Unit
) {
    val state by checked.collectAsState()
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(text = desc, color = MutedSlate, fontSize = 9.sp)
        }
        Switch(
            checked = state,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = TechnicalTeal,
                checkedTrackColor = TechnicalTeal.copy(alpha = 0.3f),
                uncheckedThumbColor = MutedSlate,
                uncheckedTrackColor = BorderGrey
            )
        )
    }
}

@Composable
fun OverlayIndicatorCard(
    label: String,
    checked: StateFlow<Boolean>,
    icon: ImageVector,
    onClick: () -> Unit
) {
    val state by checked.collectAsState()
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (state) TechnicalTeal.copy(alpha = 0.15f) else Color.Transparent)
            .border(1.dp, if (state) TechnicalTeal else BorderGrey, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (state) TechnicalTeal else MutedSlate,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = label,
                color = if (state) TechnicalTeal else PureWhite,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun AudioBar(level: Float, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(text = label, color = MutedSlate, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(BorderGrey)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(level)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (level > 0.85f) HeatRed else GlowGreen)
            )
        }
    }
}
