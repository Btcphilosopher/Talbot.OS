package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CaptureItem
import com.example.ui.CameraEngineViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GallerySection(
    viewModel: CameraEngineViewModel,
    onOpenEditor: () -> Unit,
    modifier: Modifier = Modifier
) {
    val captures by viewModel.capturesList.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedItem by remember { mutableStateOf<CaptureItem?>(null) }

    // Parse and search using metadata rather than semantic AI as requested:
    // "50 mm photographs", "RAW captures", "Night photographs", etc.
    val filteredCaptures = remember(captures, searchQuery) {
        if (searchQuery.isBlank()) {
            captures
        } else {
            val q = searchQuery.lowercase(Locale.getDefault())
            captures.filter { item ->
                val nameMatch = item.title.lowercase().contains(q)
                val modeMatch = item.mode.lowercase().contains(q)
                val styleMatch = item.style.lowercase().contains(q)
                val flMatch = "${item.focalLength.toInt()}mm".contains(q) || "${item.focalLength.toInt()} mm".contains(q)
                val rawMatch = q == "raw" && item.hasRaw
                val depthMatch = q == "depth" && item.hasDepth
                val nightMatch = q == "night" && item.iso >= 800

                nameMatch || modeMatch || styleMatch || flMatch || rawMatch || depthMatch || nightMatch
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Search bar with suggestions
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Filter by metadata (e.g. '50mm', 'RAW', 'MONOCHROME')", color = MutedSlate, fontSize = 11.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("metadata_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = PureWhite,
                    unfocusedTextColor = PureWhite,
                    focusedBorderColor = TechnicalTeal,
                    unfocusedBorderColor = BorderGrey,
                    focusedContainerColor = ObsidianDark,
                    unfocusedContainerColor = ObsidianDark
                ),
                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TechnicalTeal, modifier = Modifier.size(16.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = MutedSlate, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            )

            // Suggestions row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SuggestionTag("50mm") { searchQuery = "50mm" }
                SuggestionTag("RAW") { searchQuery = "RAW" }
                SuggestionTag("MONOCHROME") { searchQuery = "MONOCHROME" }
                SuggestionTag("VIDEO") { searchQuery = "VIDEO" }
            }
        }

        // Selected Capture Calibration Detail Board
        selectedItem?.let { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calibration_detail_board"),
                colors = CardDefaults.cardColors(containerColor = ObsidianDark),
                border = BorderStroke(1.dp, BorderGrey)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = item.title, color = TechnicalTeal, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(text = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(item.timestamp)), color = MutedSlate, fontSize = 9.sp)
                        }
                        IconButton(onClick = { selectedItem = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = MutedSlate)
                        }
                    }

                    Divider(color = BorderGrey)

                    // Diagnostic info grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            MetadataLabel("FOCAL EQUIV", "${item.focalLength.toInt()}mm")
                            MetadataLabel("APERTURE", "f/${item.aperture}")
                            MetadataLabel("SENSITIVITY", "ISO ${item.iso}")
                            MetadataLabel("SHUTTER", item.shutterSpeed)
                        }
                        Column {
                            MetadataLabel("IMAGE MODE", item.mode)
                            MetadataLabel("COMPUTATION", if (item.hasRaw) "10-bit RAW Stack" else "8-bit ToneMapped")
                            MetadataLabel("STYLE", item.style)
                            MetadataLabel("GPS", "${"%.4f".format(item.latitude)}, ${"%.4f".format(item.longitude)}")
                        }
                    }

                    Text(
                        text = "PROCESSING PIPELINE RECORD:\n${item.processingHistory}",
                        color = GlowGreen,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.selectActiveEditItem(item)
                                onOpenEditor()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TechnicalTeal),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_editor_button")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = ObsidianBlack, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("PRO POST-PROCESSOR", color = ObsidianBlack, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                viewModel.deleteCapture(item)
                                selectedItem = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = HeatRed),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = PureWhite, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Library grid of thumbnails
        if (filteredCaptures.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = "Empty", tint = BorderGrey, modifier = Modifier.size(48.dp))
                    Text("NO SPECIFIED CAPTURES RECORDED", color = MutedSlate, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text("Capture images using different lens and ISO dials above.", color = MutedSlate, fontSize = 10.sp)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredCaptures) { item ->
                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(ObsidianDark)
                            .border(
                                1.dp,
                                if (selectedItem?.id == item.id) TechnicalTeal else BorderGrey,
                                RoundedCornerShape(8.dp)
                            )
                            .combinedClickable(
                                onClick = { selectedItem = item },
                                onLongClick = {
                                    viewModel.selectActiveEditItem(item)
                                    onOpenEditor()
                                }
                            )
                            .testTag("gallery_thumbnail_${item.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = when (item.mode) {
                                    "VIDEO" -> Icons.Default.Videocam
                                    "SPATIAL" -> Icons.Default.ViewInAr
                                    "3D_SCAN" -> Icons.Default.CropRotate
                                    else -> Icons.Default.Image
                                },
                                contentDescription = "Thumb",
                                tint = if (selectedItem?.id == item.id) TechnicalTeal else PureWhite,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = item.title,
                                color = PureWhite,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${item.focalLength.toInt()}mm ISO ${item.iso}",
                                color = MutedSlate,
                                fontSize = 7.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Format tags
                        if (item.hasRaw) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .background(HighResYellow, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 3.dp, vertical = 1.dp)
                            ) {
                                Text("RAW", color = ObsidianBlack, fontSize = 6.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SuggestionTag(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(ObsidianDark)
            .border(0.5.dp, BorderGrey, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(text = label, color = TechnicalTeal, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun MetadataLabel(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 2.dp)) {
        Text(text = label, color = MutedSlate, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
