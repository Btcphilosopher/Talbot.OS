package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CaptureItem
import com.example.ui.CameraEngineViewModel
import com.example.ui.theme.*

@Composable
fun EditingSection(
    viewModel: CameraEngineViewModel,
    onCloseEditor: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeItem by viewModel.activeEditingItem.collectAsState()

    // Editor sliders collected
    val exp by viewModel.editExposure.collectAsState()
    val con by viewModel.editContrast.collectAsState()
    val sat by viewModel.editSaturation.collectAsState()
    val blur by viewModel.editBlur.collectAsState()
    val pers by viewModel.editPerspective.collectAsState()

    // Live rendered preview bitmap reflecting adjustments
    var liveEditedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Re-render edited preview whenever parameters modify
    LaunchedEffect(activeItem, exp, con, sat, blur, pers) {
        val item = activeItem ?: return@LaunchedEffect
        // Run downscaled fast render in coroutine background
        val processed = viewModel.simulationEngine.drawSyntheticFrame(
            width = 300,
            height = 300,
            isCapturing = true,
            exposureAdjustment = exp,
            contrastAdjustment = con,
            selectiveBlurRadius = blur
        )
        liveEditedBitmap = processed
    }

    if (activeItem == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(ObsidianBlack),
            contentAlignment = Alignment.Center
        ) {
            Text("NO IMAGE LOADED FOR CORRECTION", color = MutedSlate, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(12.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Editor Header bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Tune, contentDescription = "Edit", tint = TechnicalTeal)
                Text(
                    text = "REVERSIBLE NON-DESTRUCTIVE DESK",
                    color = PureWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            IconButton(onClick = onCloseEditor, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = MutedSlate)
            }
        }

        // Live Preview Canvas with guidelines
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.2f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black)
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            liveEditedBitmap?.let { bmp ->
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "Live post-processed preview",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } ?: CircularProgressIndicator(color = TechnicalTeal, modifier = Modifier.align(Alignment.Center))

            // Calibration crosshairs overlay representing precision engineering
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(0.5.dp, BorderGrey.copy(alpha = 0.3f))
            ) {
                // Draw elegant thin grid lines
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().border(0.2.dp, BorderGrey.copy(alpha = 0.2f)))
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().border(0.2.dp, BorderGrey.copy(alpha = 0.2f)))
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().border(0.2.dp, BorderGrey.copy(alpha = 0.2f)))
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "RAW DATA SECURE",
                    color = HighResYellow,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Calibration parameter sliders
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianDark),
            border = BorderStroke(1.dp, BorderGrey)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Exposure EV
                AdjustmentSlider(
                    label = "EXPOSURE COMPENSATION",
                    value = exp,
                    range = -3.0f..3.0f,
                    valueText = "${if (exp >= 0) "+" else ""}${"%.2f".format(exp)} EV",
                    onValueChange = { viewModel.editExposure.value = it },
                    testTag = "edit_exposure_slider"
                )

                // 2. Contrast scale
                AdjustmentSlider(
                    label = "OPTICAL CONTRAST COEFFICIENT",
                    value = con,
                    range = 0.5f..2.0f,
                    valueText = "${"%.2f".format(con)}x",
                    onValueChange = { viewModel.editContrast.value = it },
                    testTag = "edit_contrast_slider"
                )

                // 3. Saturation index
                AdjustmentSlider(
                    label = "CHROMA CHROMINANCE SATURATION",
                    value = sat,
                    range = 0.0f..2.0f,
                    valueText = "${"%.2f".format(sat)}x",
                    onValueChange = { viewModel.editSaturation.value = it },
                    testTag = "edit_saturation_slider"
                )

                // 4. Portrait depth defocus blur (BOKEH)
                AdjustmentSlider(
                    label = "COMPUTATIONAL PORTRAIT BOKEH BLUR",
                    value = blur,
                    range = 0.0f..5.0f,
                    valueText = "${"%.1f".format(blur)} R",
                    onValueChange = { viewModel.editBlur.value = it },
                    testTag = "edit_blur_slider"
                )

                // 5. Lens Perspective tilt
                AdjustmentSlider(
                    label = "GEOMETRIC DISTORTION CORRECTION",
                    value = pers,
                    range = -45.0f..45.0f,
                    valueText = "${"%.1f".format(pers)}°",
                    onValueChange = { viewModel.editPerspective.value = it },
                    testTag = "edit_perspective_slider"
                )
            }
        }

        // Action Buttons: Apply or Reset
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    viewModel.resetEditsToActiveItem()
                },
                colors = ButtonDefaults.buttonColors(containerColor = BorderGrey),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Revert", tint = PureWhite, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("REVERT ORIGINAL RAW", color = PureWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    viewModel.applyEditsToActiveItem()
                    onCloseEditor()
                },
                colors = ButtonDefaults.buttonColors(containerColor = TechnicalTeal),
                modifier = Modifier
                    .weight(1f)
                    .testTag("apply_edits_button")
            ) {
                Icon(Icons.Default.Save, contentDescription = "Save", tint = ObsidianBlack, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("APPLY NON-DESTRUCTIVE", color = ObsidianBlack, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AdjustmentSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onValueChange: (Float) -> Unit,
    testTag: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, color = MutedSlate, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(text = valueText, color = TechnicalTeal, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = TechnicalTeal,
                activeTrackColor = TechnicalTeal,
                inactiveTrackColor = BorderGrey
            ),
            modifier = Modifier
                .height(24.dp)
                .testTag(testTag)
        )
    }
}
