package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.log10
import kotlin.math.sin
import kotlin.random.Random

sealed class UIState {
    object Idle : UIState()
    object Capturing : UIState()
    class Success(val item: CaptureItem) : UIState()
    class Error(val message: String) : UIState()
}

class CameraEngineViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = CameraRepository(database.cameraDao())

    // Simulated Camera Core Engine
    val simulationEngine = CameraSimulationEngine()

    // Flow representing captured assets in the Room database
    val capturesList: StateFlow<List<CaptureItem>> = repository.allCaptures
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Flow for persistent camera settings Memory
    val cameraSettings: StateFlow<CameraSettings> = repository.cameraSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CameraSettings())

    // Reactive Viewfinder State
    private val _viewfinderBitmap = MutableStateFlow<Bitmap?>(null)
    val viewfinderBitmap: StateFlow<Bitmap?> = _viewfinderBitmap.asStateFlow()

    // Operational metrics and technical values
    private val _processingStatus = MutableStateFlow<String>("IDLE (RAW Stream Nominal)")
    val processingStatus: StateFlow<String> = _processingStatus.asStateFlow()

    private val _uiState = MutableStateFlow<UIState>(UIState.Idle)
    val uiState: StateFlow<UIState> = _uiState.asStateFlow()

    // Interactive overlays toggled in UI
    val showHistogram = MutableStateFlow<Boolean>(true)
    val showWaveform = MutableStateFlow<Boolean>(false)
    val showZebra = MutableStateFlow<Boolean>(false)
    val showFalseColor = MutableStateFlow<Boolean>(false)
    val showFocusPeaking = MutableStateFlow<Boolean>(false)

    // Manual Pro controls
    val activeScene = MutableStateFlow<SimulatedScene>(SimulatedScene.SUNSET_VALLEY)
    val selectedFocalLength = MutableStateFlow<Float>(50f)
    val selectedZoom = MutableStateFlow<Float>(1.0f)
    val selectedIso = MutableStateFlow<Int>(100)
    val selectedShutter = MutableStateFlow<String>("1/125")
    val selectedAperture = MutableStateFlow<Float>(1.8f)
    val selectedWB = MutableStateFlow<String>("AUTO")
    val selectedStyle = MutableStateFlow<PhotographicStyle>(PhotographicStyle.NATURAL)
    val selectedMode = MutableStateFlow<String>("PHOTO") // "PHOTO", "VIDEO", "SPATIAL", "3D_SCAN"

    // Multi-frame algorithm toggles
    val isHdrOn = MutableStateFlow<Boolean>(true)
    val isDenoiseOn = MutableStateFlow<Boolean>(true)
    val isSuperResOn = MutableStateFlow<Boolean>(true)

    // Dynamic measurements
    val computedHistogram = MutableStateFlow<FloatArray>(FloatArray(256))
    val computedWaveform = MutableStateFlow<FloatArray>(FloatArray(128))
    val audioLvlL = MutableStateFlow<Float>(0f)
    val audioLvlR = MutableStateFlow<Float>(0f)
    val deviceTemp = MutableStateFlow<Float>(28.5f) // Degrees C
    val thermalState = MutableStateFlow<Int>(0) // 0=Nominal, 1=Warning, 2=Throttling

    // Editing State (Post-processing non-destructive editor)
    val activeEditingItem = MutableStateFlow<CaptureItem?>(null)
    val editExposure = MutableStateFlow<Float>(0f)
    val editContrast = MutableStateFlow<Float>(1f)
    val editSaturation = MutableStateFlow<Float>(1f)
    val editBlur = MutableStateFlow<Float>(0f)
    val editPerspective = MutableStateFlow<Float>(0f)

    private var viewfinderJob: Job? = null
    private var sceneAnimTimer = 0f

    init {
        // Load initial settings from the Room DB database
        viewModelScope.launch {
            repository.cameraSettings.collectLatest { saved ->
                activeScene.value = SimulatedScene.values().firstOrNull { it.name == saved.imageStyle } ?: SimulatedScene.SUNSET_VALLEY
                selectedFocalLength.value = saved.preferredFocalLength
                selectedIso.value = saved.iso
                selectedShutter.value = saved.shutterSpeed
                selectedWB.value = saved.whiteBalance
                selectedStyle.value = PhotographicStyle.values().firstOrNull { it.id == saved.imageStyle } ?: PhotographicStyle.NATURAL
                selectedMode.value = saved.preferredMode
                showHistogram.value = saved.showHistogram
                showZebra.value = saved.showZebra
                showFalseColor.value = saved.showFalseColor
                showFocusPeaking.value = saved.showPeaking
            }
        }

        // Start Viewfinder refresh ticker loop
        startViewfinderPipeline()
    }

    fun setMode(mode: String) {
        selectedMode.value = mode
        simulationEngine.selectedMode = mode
        simulationEngine.is3DScanMode = (mode == "3D_SCAN")
        simulationEngine.isSpatialStereoEnabled = (mode == "SPATIAL")
        saveCurrentPreferences()
    }

    fun setScene(scene: SimulatedScene) {
        activeScene.value = scene
        simulationEngine.activeScene = scene
    }

    fun setFocalLength(mm: Float) {
        selectedFocalLength.value = mm
        simulationEngine.focalLength = mm
        saveCurrentPreferences()
    }

    fun setZoom(factor: Float) {
        selectedZoom.value = factor
        simulationEngine.zoomFactor = factor
    }

    fun setIso(value: Int) {
        selectedIso.value = value
        simulationEngine.iso = value
        saveCurrentPreferences()
    }

    fun setShutter(value: String) {
        selectedShutter.value = value
        simulationEngine.shutterSpeed = value
        saveCurrentPreferences()
    }

    fun setAperture(value: Float) {
        selectedAperture.value = value
        simulationEngine.aperture = value
    }

    fun setWB(value: String) {
        selectedWB.value = value
        simulationEngine.whiteBalance = value
        saveCurrentPreferences()
    }

    fun setStyle(style: PhotographicStyle) {
        selectedStyle.value = style
        simulationEngine.activeStyle = style
    }

    fun toggleHistogram() {
        showHistogram.value = !showHistogram.value
        saveCurrentPreferences()
    }

    fun toggleWaveform() {
        showWaveform.value = !showWaveform.value
    }

    fun toggleZebra() {
        showZebra.value = !showZebra.value
        saveCurrentPreferences()
    }

    fun toggleFalseColor() {
        showFalseColor.value = !showFalseColor.value
        saveCurrentPreferences()
    }

    fun toggleFocusPeaking() {
        showFocusPeaking.value = !showFocusPeaking.value
        saveCurrentPreferences()
    }

    // Interactive Manual Focus Focus Pull transition trigger
    fun initiateFocusPull(targetDistance: Float, durationMs: Long = 1200L) {
        viewModelScope.launch {
            _processingStatus.value = "PULLING FOCUS (Plane: ${simulationEngine.focusDistance}m -> ${targetDistance}m)"
            val steps = 20
            val delayStep = durationMs / steps
            val startDist = simulationEngine.focusDistance
            val delta = targetDistance - startDist
            for (i in 1..steps) {
                delay(delayStep)
                val currentDist = startDist + (delta * (i.toFloat() / steps))
                simulationEngine.focusDistance = currentDist
                simulationEngine.manualFocusState = currentDist
            }
            _processingStatus.value = "FOCUS LOCKED (${targetDistance}m)"
        }
    }

    private fun startViewfinderPipeline() {
        viewfinderJob?.cancel()
        viewfinderJob = viewModelScope.launch(Dispatchers.Default) {
            val random = Random(42)
            while (true) {
                sceneAnimTimer += 2.5f
                if (simulationEngine.is3DScanMode) {
                    simulationEngine.scanningAngle = (simulationEngine.scanningAngle + 3f) % 360f
                }

                // Simulate ambient environment temperature / thermal warnings
                if (random.nextFloat() > 0.95f) {
                    val tempOffset = (random.nextFloat() - 0.5f) * 1.5f
                    deviceTemp.value = Math.max(22f, Math.min(48f, deviceTemp.value + tempOffset))
                    val currentThermal = when {
                        deviceTemp.value > 45f -> 2 // Extreme throttled
                        deviceTemp.value > 39f -> 1 // Warning
                        else -> 0
                    }
                    if (currentThermal != thermalState.value) {
                        thermalState.value = currentThermal
                        simulationEngine.updateThermalState(currentThermal)
                    }
                }

                // Simulate audio level meters
                val timeFactor = System.currentTimeMillis() / 150.0
                audioLvlL.value = (0.35 * sin(timeFactor) + 0.4 + random.nextDouble() * 0.15).toFloat().coerceIn(0f, 1f)
                audioLvlR.value = (0.35 * sin(timeFactor + 0.8) + 0.4 + random.nextDouble() * 0.15).toFloat().coerceIn(0f, 1f)

                // Render current viewport synthetic sensor frame
                val bmp = simulationEngine.drawSyntheticFrame(
                    width = 400,
                    height = 400,
                    isCapturing = false
                )

                // Real-time statistical analysis
                computeHistogramAndWaveform(bmp)

                // Optional technical overlays mapped to the viewport image
                val processedBmp = applyOverlayFilters(bmp)

                _viewfinderBitmap.value = processedBmp
                delay(60) // Target ~16 FPS simulated previews to avoid container resource overhead
            }
        }
    }

    private fun computeHistogramAndWaveform(bmp: Bitmap) {
        val w = bmp.width
        val h = bmp.height
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)

        val hist = IntArray(256)
        val wave = FloatArray(128)

        // Downsample analysis for real-time responsiveness
        val sampleStep = 4
        for (y in 0 until h step sampleStep) {
            for (x in 0 until w step sampleStep) {
                val pixel = pixels[y * w + x]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luma = (0.2126f * r + 0.7152f * g + 0.0722f * b).toInt().coerceIn(0, 255)
                hist[luma]++

                // Waveform projection
                val waveIdx = (x * 128 / w).coerceIn(0, 127)
                wave[waveIdx] += luma / 255f
            }
        }

        // Normalize
        val maxHistVal = hist.maxOrNull()?.toFloat() ?: 1.0f
        val normHist = FloatArray(256) { hist[it] / maxHistVal }
        computedHistogram.value = normHist

        // Columns average
        val samplesPerColumn = (h / sampleStep)
        val normWave = FloatArray(128) { (wave[it] / samplesPerColumn).coerceIn(0f, 1f) }
        computedWaveform.value = normWave
    }

    private fun applyOverlayFilters(bmp: Bitmap): Bitmap {
        val w = bmp.width
        val h = bmp.height
        
        val showZ = showZebra.value
        val showFC = showFalseColor.value
        val showPeaking = showFocusPeaking.value

        if (!showZ && !showFC && !showPeaking) return bmp

        val processed = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)

        for (y in 0 until h) {
            for (x in 0 until w) {
                val idx = y * w + x
                val orig = pixels[idx]
                val r = (orig shr 16) and 0xFF
                val g = (orig shr 8) and 0xFF
                val b = orig and 0xFF
                val luma = (0.2126f * r + 0.7152f * g + 0.0722f * b).toInt()

                when {
                    showFC -> {
                        // Thermal false color lookup representation
                        pixels[idx] = getFalseColor(luma)
                    }
                    showZ && luma > 235 && (x + y) % 10 < 4 -> {
                        // Draw diagonal zebra stripes over highlight peaks
                        pixels[idx] = Color.BLACK
                    }
                    showPeaking && isEdge(pixels, x, y, w, h, luma) -> {
                        // Highlight high-frequency contrast boundaries
                        pixels[idx] = Color.CYAN
                    }
                    else -> {
                        pixels[idx] = orig
                    }
                }
            }
        }
        processed.setPixels(pixels, 0, w, 0, 0, w, h)
        return processed
    }

    private fun isEdge(pixels: IntArray, x: Int, y: Int, w: Int, h: Int, currentLuma: Int): Boolean {
        if (x < 1 || y < 1 || x >= w - 1 || y >= h - 1) return false
        
        // Quick Laplacian high-pass approximation
        val rightPixel = pixels[y * w + (x + 1)]
        val rightLuma = (0.2126f * ((rightPixel shr 16) and 0xFF) + 0.7152f * ((rightPixel shr 8) and 0xFF) + 0.0722f * (rightPixel and 0xFF)).toInt()
        
        val bottomPixel = pixels[(y + 1) * w + x]
        val bottomLuma = (0.2126f * ((bottomPixel shr 16) and 0xFF) + 0.7152f * ((bottomPixel shr 8) and 0xFF) + 0.0722f * (bottomPixel and 0xFF)).toInt()

        return Math.abs(currentLuma - rightLuma) > 28 || Math.abs(currentLuma - bottomLuma) > 28
    }

    private fun getFalseColor(luma: Int): Int {
        // Red = Highlights (200-255), Green = Midtones (90-199), Blue = Shadows (0-89)
        return when (luma) {
            in 220..255 -> Color.rgb(255, 0, 128) // White-hot magenta
            in 180..219 -> Color.rgb(255, 50, 0) // Overexposed red
            in 120..179 -> Color.rgb(255, 210, 0) // Warm skin yellow
            in 70..119 -> Color.rgb(0, 230, 100) // Cool green
            in 30..69 -> Color.rgb(0, 50, 200) // Deep blue
            else -> Color.rgb(10, 10, 40) // Near-black dark blue
        }
    }

    // Trigger deterministic computational capture pipeline
    fun captureCurrentFrame() {
        val mode = selectedMode.value
        val scene = activeScene.value
        val fl = selectedFocalLength.value
        val isoVal = selectedIso.value
        val shutterVal = selectedShutter.value
        val style = selectedStyle.value.id

        viewModelScope.launch(Dispatchers.Default) {
            _uiState.value = UIState.Capturing

            // Perform Multi-exposure sequencing (Short -> Medium -> Long frames)
            _processingStatus.value = "ALIGNED SENSOR FRAME SYNC..."
            delay(350)
            
            if (isHdrOn.value && thermalState.value < 2) {
                _processingStatus.value = "FUSING EXPOSURE HDR BRACKETS..."
                delay(300)
            }

            if (isDenoiseOn.value && isoVal > 100 && thermalState.value < 2) {
                _processingStatus.value = "TEMPORAL NOISE ANALYSIS OVER 8 FRAMES..."
                delay(400)
            }

            if (isSuperResOn.value && fl > 100f && thermalState.value < 2) {
                _processingStatus.value = "RECONSTRUCTING SUPER-RESOLUTION SUB-PIXELS..."
                delay(400)
            }

            // Synthesize the actual permanent Captured Frame
            _processingStatus.value = "FINALISING 10-BIT RAW CALIBRATION..."
            delay(150)

            // Save the item in the Room local Database
            val item = CaptureItem(
                title = "AURORA_${System.currentTimeMillis() % 100000}",
                mode = mode,
                focalLength = fl,
                iso = isoVal,
                shutterSpeed = shutterVal,
                aperture = selectedAperture.value,
                style = style,
                hasDepth = (mode == "SPATIAL" || mode == "3D_SCAN"),
                hasRaw = (mode == "PHOTO"),
                latitude = 51.5074, // London coordinate simulation
                longitude = -0.1278,
                processingHistory = when {
                    isHdrOn.value && isSuperResOn.value -> "Multi-Sensor HDR fusion | Super-Res reconstruction | Spatial Profile"
                    isHdrOn.value -> "Continuous Exposure bracketing | High dynamic range mapper"
                    else -> "Direct 10-bit Raw calibration | Zero temporal compression"
                }
            )

            val id = repository.insertCapture(item)
            val savedItem = item.copy(id = id)

            _processingStatus.value = "NOMINAL (RAW Stream Online)"
            _uiState.value = UIState.Success(savedItem)
        }
    }

    // Dynamic post-processing edit updates (Non-destructive)
    fun selectActiveEditItem(item: CaptureItem?) {
        activeEditingItem.value = item
        if (item != null) {
            editExposure.value = item.editExposure
            editContrast.value = item.editContrast
            editSaturation.value = item.editSaturation
            editBlur.value = item.editDepthBlur
            editPerspective.value = item.editPerspective
        }
    }

    fun applyEditsToActiveItem() {
        val active = activeEditingItem.value ?: return
        viewModelScope.launch {
            val updated = active.copy(
                editExposure = editExposure.value,
                editContrast = editContrast.value,
                editSaturation = editSaturation.value,
                editDepthBlur = editBlur.value,
                editPerspective = editPerspective.value,
                processingHistory = active.processingHistory + " | Re-calibrated ${System.currentTimeMillis() % 100}"
            )
            repository.updateCapture(updated)
            activeEditingItem.value = updated
        }
    }

    fun resetEditsToActiveItem() {
        val active = activeEditingItem.value ?: return
        viewModelScope.launch {
            val updated = active.copy(
                editExposure = 0f,
                editContrast = 1f,
                editSaturation = 1f,
                editDepthBlur = 0f,
                editPerspective = 0f
            )
            repository.updateCapture(updated)
            activeEditingItem.value = updated
            editExposure.value = 0f
            editContrast.value = 1f
            editSaturation.value = 1f
            editBlur.value = 0f
            editPerspective.value = 0f
        }
    }

    fun deleteCapture(item: CaptureItem) {
        viewModelScope.launch {
            repository.deleteCapture(item)
            if (activeEditingItem.value?.id == item.id) {
                activeEditingItem.value = null
            }
        }
    }

    private fun saveCurrentPreferences() {
        viewModelScope.launch {
            val currentSettings = CameraSettings(
                preferredMode = selectedMode.value,
                preferredFocalLength = selectedFocalLength.value,
                iso = selectedIso.value,
                shutterSpeed = selectedShutter.value,
                whiteBalance = selectedWB.value,
                imageStyle = selectedStyle.value.id,
                showHistogram = showHistogram.value,
                showZebra = showZebra.value,
                showFalseColor = showFalseColor.value,
                showPeaking = showFocusPeaking.value
            )
            repository.saveSettings(currentSettings)
        }
    }
}
