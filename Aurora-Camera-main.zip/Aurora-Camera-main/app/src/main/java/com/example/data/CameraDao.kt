package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CameraDao {
    @Query("SELECT * FROM captures ORDER BY timestamp DESC")
    fun getAllCaptures(): Flow<List<CaptureItem>>

    @Query("SELECT * FROM captures WHERE id = :id")
    suspend fun getCaptureById(id: Long): CaptureItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCapture(capture: CaptureItem): Long

    @Update
    suspend fun updateCapture(capture: CaptureItem)

    @Delete
    suspend fun deleteCapture(capture: CaptureItem)

    @Query("SELECT * FROM camera_settings WHERE id = 1")
    fun getCameraSettings(): Flow<CameraSettings?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSettings(settings: CameraSettings)
}
