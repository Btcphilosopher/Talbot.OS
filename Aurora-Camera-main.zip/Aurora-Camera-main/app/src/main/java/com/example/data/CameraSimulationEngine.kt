package com.example.data

import android.graphics.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.math.*
import kotlin.random.Random

enum class SimulatedScene(val displayName: String, val baseLux: Float, val description: String) {
    SUNSET_VALLEY("Sunset Ridge", 350f, "High dynamic range test with a glowing solar disk and deep pine valley."),
    NEON_NIGHT("Neon Shinjuku", 12f, "Extreme low-light noise challenge with dense cyber neon signs."),
    STUDIO_PORTRAIT("Atelier Portrait", 450f, "Shallow depth of field test featuring a high-contrast facial profile."),
    BACKLIT_FOREST("Backlit Redwood Canopy", 750f, "Extreme highlight recovery showing intense rays piercing dense leaves."),
    SNOWY_ALPS("Zermatt Crags", 1200f, "Super-resolution detail test with fine snow crystals and rock textures."),
    RAINY_STREET("Rainy Westminster", 120f, "High motion and dynamic reflection challenge with rain streaks and street lamps.")
}

enum class PhotographicStyle(
    val id: String,
    val displayName: String,
    val contrastScale: Float,
    val saturationScale: Float,
    val highlightRolloff: Float, // 1.0f = linear, 0.5f = compressed cinematic
    val grainAmount: Float,
    val toneCurveText: String
) {
    NATURAL("NATURAL", "Natural", 1.0f, 1.0f, 0.8f, 0.05f, "Linear highlight, neutral contrast, standard shadow rolloff"),
    CINEMATIC("CINEMATIC", "Cine LOG-M", 0.85f, 1.15f, 0.4f, 0.15f, "Soft highlight compression, enhanced organic skin, fine silver grain"),
    MONOCHROME("MONOCHROME", "Silver Nitrate Mono", 1.25f, 0.0f, 0.6f, 0.22f, "High dynamic black & white, deep reds, vintage silver grain"),
    DOCUMENTARY("DOCUMENTARY", "Koda-Chrome Classic", 1.15f, 1.2f, 0.7f, 0.08f, "Deep warm saturated shadows, nostalgic yellow-green accentuation"),
    NEUTRAL("NEUTRAL", "Flat Scientific", 0.7f, 0.7f, 1.0f, 0.0f, "Pure linear sensor bypass, absolute color accuracy, zero sharpening")
}

class CameraSimulationEngine {
    // Current optical states
    var activeScene: SimulatedScene = SimulatedScene.SUNSET_VALLEY
    var selectedMode: String = "PHOTO"
    var whiteBalance: String = "AUTO"
    var focalLength: Float = 50f // 1x = 50mm, 0.5x = 24mm, 10x = 500mm equivalents
    var zoomFactor: Float = 1.0f
    var iso: Int = 100
    var shutterSpeed: String = "1/125"
    var aperture: Float = 1.8f
    var focusDistance: Float = 2.0f // meters
    var manualFocusState: Float = 2.0f // current focal plane
    var activeStyle: PhotographicStyle = PhotographicStyle.NATURAL
    
    // Computational overrides
    var isHdrEnabled: Boolean = true
    var isLowLightDenoiseEnabled: Boolean = true
    var isSuperResolutionEnabled: Boolean = true
    var isSpatialStereoEnabled: Boolean = false
    var is3DScanMode: Boolean = false
    var scanningAngle: Float = 0f // degree for 3D rotation
    
    // Lens Optical correction calibration profiles (2030 signed calibration package)
    val distortionCoefficient: Float
        get() = when {
            focalLength < 24f -> -0.15f // Barrel distortion at ultra-wide
            focalLength > 200f -> 0.08f // Pincushion at telephoto
            else -> 0.02f // Extremely corrected main sensor
        }
        
    val chromaticAberrationAmount: Float
        get() = if (focalLength < 24f) 6.0f else if (focalLength > 200f) 4.0f else 0.5f

    val vignettingCoefficient: Float
        get() = (1.8f / aperture) * if (focalLength < 24f) 0.3f else 0.12f

    // Thermal and Pipeline levels
    var thermalLevel: Int = 0 // 0 = Nominal, 1 = Warning, 2 = Throttled
    var pipelineComplexityLevel: String = "MAXIMUM (10-bit Raw + multi-frame reconstruction)"

    fun updateThermalState(level: Int) {
        thermalLevel = level
        pipelineComplexityLevel = when (level) {
            0 -> "MAXIMUM (10-bit Raw + multi-frame reconstruction)"
            1 -> "BALANCED (Reduced HDR stack, sensor binning)"
            else -> "SAFE (Bypass computational algorithms, single frame RAW, fallback cooling)"
        }
    }

    // High performance deterministic frame renderer
    fun drawSyntheticFrame(
        width: Int,
        height: Int,
        isCapturing: Boolean = false,
        exposureAdjustment: Float = 0f, // manual EV bias
        contrastAdjustment: Float = 1f,
        selectiveBlurRadius: Float = 0f // Non-destructive post-focus editor parameter
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // 1. Base ambient level according to selected scene
        val baseLux = activeScene.baseLux
        val finalEvScale = calculateEvScale(exposureAdjustment, baseLux, isCapturing)

        // Apply background/ambient sky colors
        drawSceneBackground(canvas, width, height, finalEvScale)

        // 2. Draw Vector details based on active scene
        drawSceneDetails(canvas, width, height, finalEvScale)

        // 3. Apply Computational depth of field (optical defocus)
        applyOpticalDefocus(canvas, width, height, selectiveBlurRadius)

        // 4. Apply Optical Lens imperfections (Vignette, Distortion, CA)
        applyOpticalImperfections(bitmap, width, height)

        // 5. Add Simulated Sensor Grain/Noise if ISO is high, unless Denoised
        applySensorNoise(bitmap, width, height, isCapturing)

        // 6. Apply Tone Curve, Saturation, Contrast of Photographic Style
        applyPhotographicStyle(bitmap, width, height, contrastAdjustment)

        return bitmap
    }

    private fun calculateEvScale(evBias: Float, lux: Float, isCapturing: Boolean): Float {
        // Compute exposure factor based on ISO, Shutter, and Aperture
        val shutterVal = parseShutterSpeed(shutterSpeed)
        val fStopFactor = 1.0f / (aperture * aperture)
        val gainFactor = iso / 100f
        
        // Compute base light gathering power
        val baseExposurePower = lux * shutterVal * fStopFactor * gainFactor * 0.05f
        
        // Manual EV Bias
        val biasFactor = 2.0f.pow(evBias)
        
        // Computational engine amplification
        var finalScale = baseExposurePower * biasFactor
        
        if (isHdrEnabled && !isThrottled()) {
            // Exposure fusion maps super high and super low light gracefully
            finalScale = Math.max(0.2f, Math.min(finalScale, 1.8f))
        } else {
            // Without HDR, extreme illuminations clip to black or white
            if (finalScale > 2.0f) finalScale = 2.5f // blown out highlights
            if (finalScale < 0.1f) finalScale = 0.02f // black shadows
        }
        
        return finalScale
    }

    private fun isThrottled() = thermalLevel >= 2

    private fun parseShutterSpeed(speed: String): Float {
        if (speed == "AUTO") return 1/125f
        return try {
            if (speed.contains("/")) {
                val parts = speed.split("/")
                parts[0].toFloat() / parts[1].toFloat()
            } else {
                speed.toFloat()
            }
        } catch (e: Exception) {
            1/125f
        }
    }

    private fun drawSceneBackground(canvas: Canvas, width: Int, height: Int, evScale: Float) {
        val paint = Paint()
        val cx = width / 2f
        val cy = height / 2f

        when (activeScene) {
            SimulatedScene.SUNSET_VALLEY -> {
                // Sunset glowing orange/purple gradient
                val colors = intArrayOf(
                    adjustColor(0xFFFF5E3A, evScale),
                    adjustColor(0xFFFF2A68, evScale),
                    adjustColor(0xFF3B0066, evScale)
                )
                val gradient = LinearGradient(0f, 0f, 0f, height.toFloat(), colors, null, Shader.TileMode.CLAMP)
                paint.shader = gradient
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            }
            SimulatedScene.NEON_NIGHT -> {
                // Cyber dark violet background
                val colors = intArrayOf(
                    adjustColor(0xFF030308, evScale),
                    adjustColor(0xFF0C071C, evScale),
                    adjustColor(0xFF15152B, evScale)
                )
                val gradient = RadialGradient(cx, cy, width * 0.8f, colors, null, Shader.TileMode.CLAMP)
                paint.shader = gradient
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            }
            SimulatedScene.STUDIO_PORTRAIT -> {
                // Professional dark portrait studio gray backdrop
                val colors = intArrayOf(
                    adjustColor(0xFF282B33, evScale),
                    adjustColor(0xFF0D0E11, evScale)
                )
                val gradient = RadialGradient(cx, cy * 0.8f, width * 0.7f, colors, null, Shader.TileMode.CLAMP)
                paint.shader = gradient
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            }
            SimulatedScene.BACKLIT_FOREST -> {
                // Deep green and yellow rays gradient
                val colors = intArrayOf(
                    adjustColor(0xFF1E3516, evScale),
                    adjustColor(0xFF081403, evScale)
                )
                val gradient = LinearGradient(0f, 0f, 0f, height.toFloat(), colors, null, Shader.TileMode.CLAMP)
                paint.shader = gradient
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            }
            SimulatedScene.SNOWY_ALPS -> {
                // Bright glacial high-key blue gradient
                val colors = intArrayOf(
                    adjustColor(0xFFE5F0FA, evScale),
                    adjustColor(0xFFA6C5E3, evScale)
                )
                val gradient = LinearGradient(0f, 0f, 0f, height.toFloat(), colors, null, Shader.TileMode.CLAMP)
                paint.shader = gradient
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            }
            SimulatedScene.RAINY_STREET -> {
                // Cool midnight blue-grey wet street vibe
                val colors = intArrayOf(
                    adjustColor(0xFF1A1F2C, evScale),
                    adjustColor(0xFF0B0E14, evScale)
                )
                val gradient = LinearGradient(0f, 0f, 0f, height.toFloat(), colors, null, Shader.TileMode.CLAMP)
                paint.shader = gradient
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            }
        }
    }

    private fun drawSceneDetails(canvas: Canvas, width: Int, height: Int, evScale: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f

        // Simulated optical zoom scales drawing objects relative to center
        // Lens switches optical boundaries: Wide (0.5x) -> Main (1x/2x) -> Telephoto (3x/5x/10x)
        val zoomScale = zoomFactor * (focalLength / 50f)
        
        canvas.save()
        canvas.scale(zoomScale, zoomScale, cx, cy)

        when (activeScene) {
            SimulatedScene.SUNSET_VALLEY -> {
                // Large solar disk (Highlight challenge)
                paint.shader = null
                paint.color = adjustColor(if (isHdrEnabled) 0xFFFFF9E6 else 0xFFFFFFFF, evScale)
                // Draw sun glowing halo
                val glowRadius = 150f
                val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
                val sunColors = intArrayOf(
                    adjustColor(0xBBFFD700, evScale),
                    adjustColor(0x00FF4500, evScale)
                )
                glowPaint.shader = RadialGradient(cx, cy - 100f, glowRadius * 1.8f, sunColors, null, Shader.TileMode.CLAMP)
                canvas.drawCircle(cx, cy - 100f, glowRadius * 1.8f, glowPaint)

                // Sun Core
                canvas.drawCircle(cx, cy - 100f, glowRadius, paint)

                // Majestic pine ridges
                paint.shader = null
                paint.color = adjustColor(0xFF11220F, evScale * 0.7f)
                val path1 = Path().apply {
                    moveTo(0f, cy + 100f)
                    lineTo(w * 0.3f, cy + 20f)
                    lineTo(w * 0.6f, cy + 150f)
                    lineTo(w, cy + 80f)
                    lineTo(w, h * 1.5f)
                    lineTo(0f, h * 1.5f)
                    close()
                }
                canvas.drawPath(path1, paint)

                paint.color = adjustColor(0xFF071106, evScale * 0.4f)
                val path2 = Path().apply {
                    moveTo(0f, cy + 200f)
                    lineTo(w * 0.5f, cy + 150f)
                    lineTo(w, cy + 250f)
                    lineTo(w, h * 1.5f)
                    lineTo(0f, h * 1.5f)
                    close()
                }
                canvas.drawPath(path2, paint)
            }
            SimulatedScene.NEON_NIGHT -> {
                // Cyber illuminated signs
                paint.shader = null
                
                // Draw illuminated skyscraper silhouettes
                paint.color = adjustColor(0xFF0F0B1E, evScale)
                canvas.drawRect(w * 0.1f, cy - 300f, w * 0.4f, h * 1.5f, paint)
                canvas.drawRect(w * 0.6f, cy - 400f, w * 0.9f, h * 1.5f, paint)

                // Drawing neon glowing sign boxes
                val neonGlow = Paint(Paint.ANTI_ALIAS_FLAG)
                
                // Cyan Sign
                val cyanColors = intArrayOf(adjustColor(0xFF00FFCC, evScale), 0x0000FFCC)
                neonGlow.shader = RadialGradient(w * 0.25f, cy - 150f, 100f, cyanColors, null, Shader.TileMode.CLAMP)
                canvas.drawCircle(w * 0.25f, cy - 150f, 100f, neonGlow)
                
                paint.color = adjustColor(0xFFE6FFFF, evScale)
                paint.textSize = 36f
                paint.typeface = Typeface.MONOSPACE
                canvas.drawText("AURORA 2030", w * 0.15f, cy - 150f, paint)

                // Magenta Neon vertical banner
                val magColors = intArrayOf(adjustColor(0xFFFF0055, evScale), 0x00FF0055)
                neonGlow.shader = RadialGradient(w * 0.75f, cy - 100f, 120f, magColors, null, Shader.TileMode.CLAMP)
                canvas.drawCircle(w * 0.75f, cy - 100f, 120f, neonGlow)
                
                paint.color = adjustColor(0xFFFFD4E2, evScale)
                canvas.drawRect(w * 0.72f, cy - 250f, w * 0.78f, cy + 50f, paint)
            }
            SimulatedScene.STUDIO_PORTRAIT -> {
                // Artistic profile model facial sketch (vector curves)
                paint.color = adjustColor(0xFFE5B099, evScale)
                paint.style = Paint.Style.FILL

                // Head/Hair silhouette
                val hairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = adjustColor(0xFF140D0B, evScale * 0.6f)
                }
                canvas.drawCircle(cx, cy - 50f, 180f, hairPaint)

                // Profile Face Path
                val facePath = Path().apply {
                    moveTo(cx, cy - 200f)
                    cubicTo(cx + 100f, cy - 200f, cx + 110f, cy - 100f, cx + 100f, cy - 50f) // Forehead
                    lineTo(cx + 120f, cy - 30f) // Nose bridge
                    lineTo(cx + 90f, cy - 10f) // Under-nose
                    lineTo(cx + 110f, cy + 10f) // Lips
                    lineTo(cx + 85f, cy + 30f) // Under-lips
                    lineTo(cx + 95f, cy + 60f) // Chin
                    lineTo(cx - 50f, cy + 100f) // Neck
                    lineTo(cx - 100f, cy - 200f)
                    close()
                }
                canvas.drawPath(facePath, paint)

                // Studio catch light in background
                val keyLight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(cx + 250f, cy - 150f, 300f, intArrayOf(adjustColor(0x66FFDD99, evScale), 0x00FFDD99), null, Shader.TileMode.CLAMP)
                }
                canvas.drawCircle(cx + 250f, cy - 150f, 300f, keyLight)
            }
            SimulatedScene.BACKLIT_FOREST -> {
                // Huge towering trees
                paint.color = adjustColor(0xFF231C14, evScale * 0.5f)
                canvas.drawRect(w * 0.15f, -100f, w * 0.3f, h * 1.5f, paint)
                canvas.drawRect(w * 0.7f, -100f, w * 0.85f, h * 1.5f, paint)

                // Canopy leaf blobs
                paint.color = adjustColor(0xFF0F260A, evScale * 0.9f)
                canvas.drawCircle(w * 0.2f, cy - 200f, 250f, paint)
                canvas.drawCircle(w * 0.8f, cy - 250f, 280f, paint)

                // Volumetric Crepuscular Sun Rays radiating from upper left corner
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 24f
                val rayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = adjustColor(0x33FFDD66, evScale)
                    style = Paint.Style.FILL
                }
                val raysPath = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w * 0.4f, h)
                    lineTo(w * 0.6f, h)
                    moveTo(0f, 0f)
                    lineTo(w, h * 0.5f)
                    lineTo(w, h * 0.7f)
                    close()
                }
                canvas.drawPath(raysPath, rayPaint)
            }
            SimulatedScene.SNOWY_ALPS -> {
                // Peak outlines
                paint.style = Paint.Style.FILL
                paint.color = adjustColor(0xFFDFE6F2, evScale)
                val alpPath = Path().apply {
                    moveTo(-100f, cy + 300f)
                    lineTo(cx - 200f, cy - 100f) // Peak 1
                    lineTo(cx, cy + 150f)
                    lineTo(cx + 300f, cy - 200f) // Peak 2 (Highest)
                    lineTo(w + 100f, cy + 300f)
                    lineTo(w + 100f, h * 1.5f)
                    lineTo(-100f, h * 1.5f)
                    close()
                }
                canvas.drawPath(alpPath, paint)

                // Rock crags (Super Resolution high frequency target)
                paint.color = adjustColor(0xFF4C586B, evScale * 0.7f)
                val cragPath = Path().apply {
                    moveTo(cx + 300f, cy - 200f)
                    lineTo(cx + 260f, cy - 100f)
                    lineTo(cx + 320f, cy - 20f)
                    lineTo(cx + 280f, cy + 50f)
                    lineTo(cx + 350f, cy + 150f)
                    lineTo(cx + 300f, cy - 200f)
                }
                canvas.drawPath(cragPath, paint)

                // Super resolution details (drawn extra sharp if SR is enabled, otherwise generic soft)
                if (isSuperResolutionEnabled && !isThrottled()) {
                    paint.color = adjustColor(0xFFFFFFFF, evScale)
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 2f
                    // Draw ultra fine glacier crevasses
                    for (i in 0..10) {
                        canvas.drawLine(cx + 100f + i*15f, cy + 100f + i*5f, cx + 110f + i*15f, cy + 130f + i*5f, paint)
                    }
                } else {
                    // Soften representation (illustrating non-super-res resolution limit)
                    paint.color = adjustColor(0xFFCFDCEF, evScale)
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 5f
                    canvas.drawLine(cx + 100f, cy + 100f, cx + 250f, cy + 150f, paint)
                }
            }
            SimulatedScene.RAINY_STREET -> {
                // London telephone box and rain streaks
                paint.style = Paint.Style.FILL
                
                // Telephone box
                paint.color = adjustColor(0xFF991111, evScale)
                canvas.drawRect(cx - 150f, cy - 100f, cx - 30f, cy + 300f, paint)
                paint.color = adjustColor(0xFFEECCCC, evScale)
                for (r in 0..3) {
                    for (c in 0..1) {
                        canvas.drawRect(cx - 130f + c*50f, cy - 80f + r*60f, cx - 95f + c*50f, cy - 40f + r*60f, paint)
                    }
                }

                // Wet asphalt neon reflection
                val reflectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = LinearGradient(0f, cy + 180f, 0f, h, adjustColor(0x33FF3333, evScale), 0x00FF3333, Shader.TileMode.CLAMP)
                }
                canvas.drawRect(0f, cy + 180f, w, h, reflectionPaint)

                // Draw deterministic rain streaks
                val rainPaint = Paint().apply {
                    color = adjustColor(0x88FFFFFF, evScale)
                    strokeWidth = 2f
                }
                val random = Random(42) // deterministic rain
                for (i in 0..40) {
                    val rx = random.nextFloat() * w
                    val ry = random.nextFloat() * h
                    canvas.drawLine(rx, ry, rx - 10f, ry + 40f, rainPaint)
                }
            }
        }

        // 3D Scanning Mesh overlay
        if (is3DScanMode) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.5f
            paint.color = Color.Green.copy(alpha = 0.4f).toArgb()
            
            // Draw a spinning holographic calibration wireframe cage
            val rotRad = Math.toRadians(scanningAngle.toDouble())
            val cosR = cos(rotRad).toFloat()
            val sinR = sin(rotRad).toFloat()
            
            // Rotate a cube or sphere mesh projection
            for (z in -3..3) {
                val r = 120f * cos(z * 0.3f)
                val projY = cy + z * 35f
                val projW = r * cosR
                canvas.drawOval(cx - projW, projY - 10f, cx + projW, projY + 10f, paint)
            }
            // Point Cloud vertices
            paint.style = Paint.Style.FILL
            paint.color = Color.Yellow.toArgb()
            val dotRandom = Random(1337)
            for (p in 0..100) {
                val theta = dotRandom.nextFloat() * 2 * PI
                val phi = acos(2 * dotRandom.nextFloat() - 1)
                val rx = (100 * sin(phi) * cos(theta)).toFloat()
                val ry = (100 * sin(phi) * sin(theta)).toFloat()
                
                // Rotated coords
                val rxRot = rx * cosR - ry * sinR
                canvas.drawCircle(cx + rxRot, cy + ry * 0.5f, 2f, paint)
            }
        }

        canvas.restore()
    }

    private fun applyOpticalDefocus(canvas: Canvas, width: Int, height: Int, selectiveBlur: Float) {
        // Computational depth of field: based on distance between manualFocusState and focusDistance
        val depthDelta = abs(manualFocusState - focusDistance)
        val opticalDefocusFactor = (depthDelta * 25f / aperture) + selectiveBlur
        
        if (opticalDefocusFactor > 2.0f) {
            // Apply a beautiful cinematic software bokeh blur
            val blurPaint = Paint().apply {
                color = 0x22000000
                style = Paint.Style.FILL
            }
            // In 2030, this is fully vector-guided. We draw soft bokeh circles on top of high-frequency edges
            val r = Random(99)
            val bokehCount = Math.min(15, (opticalDefocusFactor * 2).toInt())
            for (i in 0..bokehCount) {
                val bx = r.nextFloat() * width
                val by = r.nextFloat() * height
                val size = r.nextFloat() * opticalDefocusFactor * 8f + 10f
                val color = adjustColor(0x33FFFFFF, r.nextFloat() * 1.5f)
                blurPaint.color = color
                canvas.drawCircle(bx, by, size, blurPaint)
            }
        }
    }

    private fun applyOpticalImperfections(bitmap: Bitmap, width: Int, height: Int) {
        // Multi-lens profile corrections. If bypassed, we render physical barrel distortion & corner vignetting
        val vignette = vignettingCoefficient
        val distortion = distortionCoefficient
        
        val size = width * height
        val pixels = IntArray(size)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val cx = width / 2f
        val cy = height / 2f
        val maxDist = sqrt(cx * cx + cy * cy)

        for (y in 0 until height) {
            for (x in 0 until width) {
                val idx = y * width + x
                val origColor = pixels[idx]

                val dx = x - cx
                val dy = y - cy
                val dist = sqrt(dx * dx + dy * dy)
                val normDist = dist / maxDist

                // 1. Vignette (Darkening towards edges)
                val vignetteFactor = 1.0f - (vignette * normDist.pow(2))
                var r = ((origColor shr 16) and 0xFF) * vignetteFactor
                var g = ((origColor shr 8) and 0xFF) * vignetteFactor
                var b = (origColor and 0xFF) * vignetteFactor

                // 2. Chromatic Aberration (Shift Red/Blue channels slightly at wide lenses)
                if (chromaticAberrationAmount > 1.0f && normDist > 0.4f) {
                    val shift = (chromaticAberrationAmount * normDist).toInt()
                    val targetX = Math.min(width - 1, Math.max(0, x + shift))
                    val rColor = pixels[y * width + targetX]
                    r = ((rColor shr 16) and 0xFF).toFloat() * vignetteFactor
                }

                // clamp values
                val finalR = Math.max(0, Math.min(255, r.toInt()))
                val finalG = Math.max(0, Math.min(255, g.toInt()))
                val finalB = Math.max(0, Math.min(255, b.toInt()))

                pixels[idx] = (0xFF shl 24) or (finalR shl 16) or (finalG shl 8) or finalB
            }
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
    }

    private fun applySensorNoise(bitmap: Bitmap, width: Int, height: Int, isCapturing: Boolean) {
        // High ISO creates sensor noise (grain).
        // Computational Denoising combines multiple exposures to clean up this noise completely.
        val shouldDenoise = isLowLightDenoiseEnabled && !isThrottled()
        if (iso <= 100 || (shouldDenoise && isCapturing)) return

        val noiseStrength = (iso - 100) / 12000f // noise level
        if (noiseStrength <= 0.005f) return

        val size = width * height
        val pixels = IntArray(size)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val r = java.util.Random(101)

        for (i in 0 until size) {
            val color = pixels[i]
            val grain = r.nextGaussian().toFloat() * noiseStrength * 255f
            
            var red = ((color shr 16) and 0xFF) + grain
            var green = ((color shr 8) and 0xFF) + grain
            var blue = (color and 0xFF) + grain

            val fR = Math.max(0, Math.min(255, red.toInt()))
            val fG = Math.max(0, Math.min(255, green.toInt()))
            val fB = Math.max(0, Math.min(255, blue.toInt()))

            pixels[i] = (0xFF shl 24) or (fR shl 16) or (fG shl 8) or fB
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
    }

    private fun applyPhotographicStyle(bitmap: Bitmap, width: Int, height: Int, contrastAdjust: Float) {
        // Apply Photographic Profiles curves (Natural, Cinematic, Monochrome)
        val style = activeStyle
        val satScale = style.saturationScale
        val conScale = style.contrastScale * contrastAdjust
        val rolloff = style.highlightRolloff

        val size = width * height
        val pixels = IntArray(size)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        for (i in 0 until size) {
            val color = pixels[i]
            var r = ((color shr 16) and 0xFF) / 255f
            var g = ((color shr 8) and 0xFF) / 255f
            var b = (color and 0xFF) / 255f

            // 1. Contrast adjustment (S-curve about 0.5 midtone)
            r = applyContrastCurve(r, conScale)
            g = applyContrastCurve(g, conScale)
            b = applyContrastCurve(b, conScale)

            // 2. Highlight compression (Soft Roll-off)
            if (rolloff < 1.0f) {
                r = compressHighlights(r, rolloff)
                g = compressHighlights(g, rolloff)
                b = compressHighlights(b, rolloff)
            }

            // 3. Saturation (Conversion to luminance + scaling differences)
            val luma = 0.2126f * r + 0.7152f * g + 0.0722f * b
            if (satScale == 0.0f) {
                // Monochrome
                r = luma
                g = luma
                b = luma
            } else if (satScale != 1.0f) {
                r = luma + (r - luma) * satScale
                g = luma + (g - luma) * satScale
                b = luma + (b - luma) * satScale
            }

            val fR = Math.max(0, Math.min(255, (r * 255f).toInt()))
            val fG = Math.max(0, Math.min(255, (g * 255f).toInt()))
            val fB = Math.max(0, Math.min(255, (b * 255f).toInt()))

            pixels[i] = (0xFF shl 24) or (fR shl 16) or (fG shl 8) or fB
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
    }

    private fun applyContrastCurve(v: Float, contrast: Float): Float {
        if (contrast == 1.0f) return v
        val shifted = v - 0.5f
        return 1.0f / (1.0f + exp(-contrast * 10f * shifted))
    }

    private fun compressHighlights(v: Float, rolloff: Float): Float {
        // Symmetrical high-key compression
        if (v <= 0.7f) return v
        val t = (v - 0.7f) / 0.3f
        val compressed = 0.7f + 0.3f * (t * rolloff / (1.0f + t * rolloff))
        return Math.min(1.0f, compressed)
    }

    private fun adjustColor(color: Int, factor: Float): Int {
        if (factor == 1.0f) return color
        val a = (color shr 24) and 0xFF
        val r = Math.max(0, Math.min(255, (((color shr 16) and 0xFF) * factor).toInt()))
        val g = Math.max(0, Math.min(255, (((color shr 8) and 0xFF) * factor).toInt()))
        val b = Math.max(0, Math.min(255, ((color and 0xFF) * factor).toInt()))
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun adjustColor(color: Long, factor: Float): Int {
        val a = (color shr 24).toInt() and 0xFF
        val r = Math.max(0, Math.min(255, (((color shr 16).toInt() and 0xFF) * factor).toInt()))
        val g = Math.max(0, Math.min(255, (((color shr 8).toInt() and 0xFF) * factor).toInt()))
        val b = Math.max(0, Math.min(255, ((color.toInt() and 0xFF) * factor).toInt()))
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }
}
