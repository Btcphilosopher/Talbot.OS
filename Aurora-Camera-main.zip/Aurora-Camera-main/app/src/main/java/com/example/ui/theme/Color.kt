package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Sophisticated Dark 2030 Photographic Color Palette
val ObsidianBlack = Color(0xFF050505)
val ObsidianDark = Color(0xFF0E0E0E)
val ObsidianSurface = Color(0xFF161616)
val TechnicalTeal = Color(0xFF10B981) // Emerald Green highlights
val WarmOrange = Color(0xFFF97316) // Tailwinds signature orange-500
val HighResYellow = Color(0xFFFACC15) // Tailwind yellow-400
val PureWhite = Color(0xFFFFFFFF)
val MutedSlate = Color(0x99FFFFFF) // 60% white
val BorderGrey = Color(0x1AFFFFFF) // white/10
val GlowGreen = Color(0xFF10B981) // Emerald Green
val ShadowBlack = Color(0xAA000000)
val GlassSurface = Color(0x0DFFFFFF) // white/5
val HeatRed = Color(0xFFEF4444) // Tailwind red-500

