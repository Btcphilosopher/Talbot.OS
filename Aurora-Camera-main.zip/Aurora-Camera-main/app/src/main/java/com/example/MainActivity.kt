package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.example.ui.CameraEngineViewModel
import com.example.ui.UIState
import com.example.ui.components.ControlsSection
import com.example.ui.components.EditingSection
import com.example.ui.components.GallerySection
import com.example.ui.components.ViewfinderSection
import com.example.ui.theme.AuroraTheme
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Safely instantiate the Camera Engine View Model
        val viewModel = ViewModelProvider(this)[CameraEngineViewModel::class.java]

        setContent {
            AuroraTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ObsidianBlack),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ObsidianBlack)
                            .padding(innerPadding)
                    ) {
                        MainCameraLayout(viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun MainCameraLayout(viewModel: CameraEngineViewModel) {
    // Collect states
    val uiState by viewModel.uiState.collectAsState()
    val activeMode by viewModel.selectedMode.collectAsState()
    val captures by viewModel.capturesList.collectAsState()
    val processingStatus by viewModel.processingStatus.collectAsState()

    // Navigation state: "CAMERA" (viewfinder/dials), "GALLERY" (photos/calibration), "EDITOR" (non-destructive)
    var currentViewTab by remember { mutableStateOf("CAMERA") }
    var showSettingsDialog by remember { mutableStateOf(false) }

    // Calibration Matrix Dialog
    if (showSettingsDialog) {
        val hdrState by viewModel.isHdrOn.collectAsState()
        val denoiseState by viewModel.isDenoiseOn.collectAsState()
        val superResState by viewModel.isSuperResOn.collectAsState()
        
        val histState by viewModel.showHistogram.collectAsState()
        val waveState by viewModel.showWaveform.collectAsState()
        val zebraState by viewModel.showZebra.collectAsState()
        val falseColorState by viewModel.showFalseColor.collectAsState()
        val peakingState by viewModel.showFocusPeaking.collectAsState()

        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AURA CALIBRATION MATRIX",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = HighResYellow,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    IconButton(
                        onClick = { showSettingsDialog = false },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = PureWhite.copy(alpha = 0.6f))
                    }
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "MANUAL ISP & CO-PROCESSOR SWITCHBOARD",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = MutedSlate,
                        fontFamily = FontFamily.Monospace
                    )

                    // Switches for co-processors
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.isHdrOn.value = !hdrState }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Multi-Frame HDR Integration", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Merge sub-exposures synchronously", color = MutedSlate, fontSize = 9.sp)
                            }
                            Switch(
                                checked = hdrState,
                                onCheckedChange = { viewModel.isHdrOn.value = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = TechnicalTeal,
                                    checkedTrackColor = TechnicalTeal.copy(alpha = 0.3f),
                                    uncheckedThumbColor = MutedSlate,
                                    uncheckedTrackColor = ObsidianSurface
                                )
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.isDenoiseOn.value = !denoiseState }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("8-Frame Temporal Denoise", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Sub-pixel temporal noise subtraction", color = MutedSlate, fontSize = 9.sp)
                            }
                            Switch(
                                checked = denoiseState,
                                onCheckedChange = { viewModel.isDenoiseOn.value = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = TechnicalTeal,
                                    checkedTrackColor = TechnicalTeal.copy(alpha = 0.3f),
                                    uncheckedThumbColor = MutedSlate,
                                    uncheckedTrackColor = ObsidianSurface
                                )
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.isSuperResOn.value = !superResState }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Super-Resolution synthesis", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Sub-pixel dither detail synthesis", color = MutedSlate, fontSize = 9.sp)
                            }
                            Switch(
                                checked = superResState,
                                onCheckedChange = { viewModel.isSuperResOn.value = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = TechnicalTeal,
                                    checkedTrackColor = TechnicalTeal.copy(alpha = 0.3f),
                                    uncheckedThumbColor = MutedSlate,
                                    uncheckedTrackColor = ObsidianSurface
                                )
                            )
                        }
                    }

                    Divider(color = BorderGrey, thickness = 0.5.dp)

                    Text(
                        text = "VIEWFINDER TELEMETRY HUD OVERLAYS",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = MutedSlate,
                        fontFamily = FontFamily.Monospace
                    )

                    // Horizontal/Vertical grids of chip triggers
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("HISTOGRAM" to histState, "WAVEFORM" to waveState, "ZEBRA" to zebraState).forEach { (label, isChecked) ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isChecked) TechnicalTeal.copy(alpha = 0.15f) else ObsidianSurface)
                                        .border(0.5.dp, if (isChecked) TechnicalTeal else BorderGrey, RoundedCornerShape(6.dp))
                                        .clickable {
                                            when (label) {
                                                "HISTOGRAM" -> viewModel.toggleHistogram()
                                                "WAVEFORM" -> viewModel.toggleWaveform()
                                                "ZEBRA" -> viewModel.toggleZebra()
                                            }
                                        }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isChecked) TechnicalTeal else MutedSlate,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("FALSE COLOR" to falseColorState, "FOCUS PEAKING" to peakingState).forEach { (label, isChecked) ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isChecked) TechnicalTeal.copy(alpha = 0.15f) else ObsidianSurface)
                                        .border(0.5.dp, if (isChecked) TechnicalTeal else BorderGrey, RoundedCornerShape(6.dp))
                                        .clickable {
                                            when (label) {
                                                "FALSE COLOR" -> viewModel.toggleFalseColor()
                                                "FOCUS PEAKING" -> viewModel.toggleFocusPeaking()
                                            }
                                        }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isChecked) TechnicalTeal else MutedSlate,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showSettingsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = TechnicalTeal)
                ) {
                    Text("LOCK MATRIX", color = ObsidianBlack, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = ObsidianDark,
            tonalElevation = 8.dp,
            modifier = Modifier.border(1.dp, BorderGrey, RoundedCornerShape(28.dp))
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. TOP PREMIUM STATUS HEADBOARD (Sophisticated Dark layout)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Brand and pipeline engine version
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "AURA ENGINE v4.2",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.2.sp
                    )
                    
                    // Connected pipeline status dot
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (uiState is UIState.Capturing) WarmOrange else GlowGreen)
                        )
                        Text(
                            text = if (uiState is UIState.Capturing) "BUSY" else "STABLE",
                            color = if (uiState is UIState.Capturing) WarmOrange else GlowGreen,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Standard resolution/encoding + Settings gear trigger
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 8K | RAW Capsule Indicator
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(50))
                            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)), RoundedCornerShape(50))
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "8K",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "|",
                                color = Color.White.copy(alpha = 0.2f),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "RAW",
                                color = WarmOrange,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Settings trigger
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier.size(28.dp).testTag("settings_matrix_trigger")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Aura Matrix Settings",
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            Divider(color = BorderGrey, thickness = 0.5.dp, modifier = Modifier.padding(top = 4.dp))
        }

        // 2. MAIN CENTER WORKSPACE WITH SOLID SLIDE TRANSITIONS
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            when (currentViewTab) {
                "CAMERA" -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Centered 1:1 Viewfinder frame
                        ViewfinderSection(viewModel = viewModel)

                        // Dials and configurations
                        ControlsSection(viewModel = viewModel, modifier = Modifier.weight(1f))
                    }
                }

                "GALLERY" -> {
                    GallerySection(
                        viewModel = viewModel,
                        onOpenEditor = { currentViewTab = "EDITOR" },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                "EDITOR" -> {
                    EditingSection(
                        viewModel = viewModel,
                        onCloseEditor = { currentViewTab = "GALLERY" },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        // 3. CAPTURE TRIGGER PANEL & MODE SELECTORS (Locked to Bottom)
        if (currentViewTab == "CAMERA") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianDark)
                    .padding(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Horizontal scrollable modes carousel with Orange dot selectors
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("PHOTO", "VIDEO", "SPATIAL", "3D_SCAN").forEach { mode ->
                        val isSelected = activeMode == mode
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier
                                .clickable { viewModel.setMode(mode) }
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = mode,
                                color = if (isSelected) WarmOrange else MutedSlate,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Normal,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 0.5.sp
                            )
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(4.dp)
                                        .clip(CircleShape)
                                        .background(WarmOrange)
                                )
                            } else {
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                    }
                }

                // Interactive shutter cluster row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left trigger: Local Gallery Thumbnail
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(ObsidianSurface)
                            .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                            .clickable { currentViewTab = "GALLERY" }
                            .testTag("gallery_drawer_trigger"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = "Library", tint = TechnicalTeal, modifier = Modifier.size(18.dp))
                            Text(
                                text = captures.size.toString(),
                                color = PureWhite,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Center trigger: Shutter button with concentric precision rings
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .border(1.5.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                            .padding(5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(
                                    if (uiState is UIState.Capturing) WarmOrange else PureWhite
                                )
                                .clickable { viewModel.captureCurrentFrame() }
                                .testTag("shutter_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (uiState is UIState.Capturing) {
                                CircularProgressIndicator(
                                    color = ObsidianBlack,
                                    modifier = Modifier.size(32.dp),
                                    strokeWidth = 3.dp
                                )
                            } else {
                                Icon(
                                    imageVector = if (activeMode == "VIDEO") Icons.Default.FiberManualRecord else Icons.Default.Camera,
                                    contentDescription = "Trigger",
                                    tint = if (activeMode == "VIDEO") Color.Red else ObsidianBlack,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }

                    // Right trigger: Focus preset switch shortcut
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(ObsidianSurface)
                            .border(1.dp, BorderGrey, CircleShape)
                            .clickable {
                                // Dynamic instant recalibration preset focus pull trigger
                                viewModel.initiateFocusPull(2.0f, 400L)
                            }
                            .testTag("calibration_preset_shortcut"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Cached, contentDescription = "Recalibrate lens", tint = HighResYellow, modifier = Modifier.size(20.dp))
                    }
                }
            }
        } else {
            // Mode buttons for exiting Gallery or Editor and returning to camera
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianDark)
                    .padding(vertical = 12.dp, horizontal = 24.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { currentViewTab = "CAMERA" },
                    colors = ButtonDefaults.buttonColors(containerColor = TechnicalTeal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("return_to_viewfinder_button")
                ) {
                    Icon(Icons.Default.Camera, contentDescription = "Back", tint = ObsidianBlack)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("OPEN VIEWPORT STREAM", color = ObsidianBlack, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
