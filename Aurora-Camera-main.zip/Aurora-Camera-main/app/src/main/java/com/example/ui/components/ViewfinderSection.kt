package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SimulatedScene
import com.example.ui.CameraEngineViewModel
import com.example.ui.theme.*

@Composable
fun ViewfinderSection(
    viewModel: CameraEngineViewModel,
    modifier: Modifier = Modifier
) {
    val viewfinderBitmap by viewModel.viewfinderBitmap.collectAsState()
    val processingStatus by viewModel.processingStatus.collectAsState()
    val activeScene by viewModel.activeScene.collectAsState()
    val selectedMode by viewModel.selectedMode.collectAsState()
    val focalLength by viewModel.selectedFocalLength.collectAsState()
    val aperture by viewModel.selectedAperture.collectAsState()
    val iso by viewModel.selectedIso.collectAsState()
    val shutterSpeed by viewModel.selectedShutter.collectAsState()
    val wb by viewModel.selectedWB.collectAsState()

    // Overlay visibility states
    val isHistOn by viewModel.showHistogram.collectAsState()
    val isWaveOn by viewModel.showWaveform.collectAsState()
    val isZebraOn by viewModel.showZebra.collectAsState()
    val isFalseOn by viewModel.showFalseColor.collectAsState()
    val isPeakingOn by viewModel.showFocusPeaking.collectAsState()
    val computedHist by viewModel.computedHistogram.collectAsState()
    val computedWave by viewModel.computedWaveform.collectAsState()
    val deviceTemp by viewModel.deviceTemp.collectAsState()
    val thermalState by viewModel.thermalState.collectAsState()

    var showSceneSelector by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f) // Square viewfinder matching premium cinematic standard
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black)
            .border(1.dp, BorderGrey, RoundedCornerShape(16.dp))
            .testTag("viewfinder_container")
    ) {
        // Render Viewfinder Bitmap
        viewfinderBitmap?.let { bmp ->
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Sensor Viewfinder",
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("viewfinder_image"),
                contentScale = ContentScale.Crop
            )
        } ?: Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = TechnicalTeal)
        }

        // Draw Centered Focus Reticle, Guidelines and Corner Alignment Markers
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerX = size.width / 2f
            val centerY = size.height / 2f
            val alphaColor = Color.White.copy(alpha = 0.4f)
            val strokeW = 1.25.dp.toPx()

            // Centered focusing ring (180dp diameter / 90dp radius)
            val radiusPx = 76.dp.toPx()
            drawCircle(
                color = Color.White.copy(alpha = 0.12f),
                radius = radiusPx,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
            )

            // Central crosshairs
            val crossLength = 8.dp.toPx()
            // Horizontal line
            drawLine(
                color = Color.White.copy(alpha = 0.25f),
                start = androidx.compose.ui.geometry.Offset(centerX - crossLength, centerY),
                end = androidx.compose.ui.geometry.Offset(centerX + crossLength, centerY),
                strokeWidth = 1.dp.toPx()
            )
            // Vertical line
            drawLine(
                color = Color.White.copy(alpha = 0.25f),
                start = androidx.compose.ui.geometry.Offset(centerX, centerY - crossLength),
                end = androidx.compose.ui.geometry.Offset(centerX, centerY + crossLength),
                strokeWidth = 1.dp.toPx()
            )

            // Grid corner alignment markers of the reticle box (offset 76.dp from center)
            val boxHalf = 76.dp.toPx()
            val cornerLineLen = 14.dp.toPx()

            // Top-Left corner
            drawLine(color = alphaColor, start = androidx.compose.ui.geometry.Offset(centerX - boxHalf, centerY - boxHalf), end = androidx.compose.ui.geometry.Offset(centerX - boxHalf + cornerLineLen, centerY - boxHalf), strokeWidth = strokeW)
            drawLine(color = alphaColor, start = androidx.compose.ui.geometry.Offset(centerX - boxHalf, centerY - boxHalf), end = androidx.compose.ui.geometry.Offset(centerX - boxHalf, centerY - boxHalf + cornerLineLen), strokeWidth = strokeW)

            // Top-Right corner
            drawLine(color = alphaColor, start = androidx.compose.ui.geometry.Offset(centerX + boxHalf, centerY - boxHalf), end = androidx.compose.ui.geometry.Offset(centerX + boxHalf - cornerLineLen, centerY - boxHalf), strokeWidth = strokeW)
            drawLine(color = alphaColor, start = androidx.compose.ui.geometry.Offset(centerX + boxHalf, centerY - boxHalf), end = androidx.compose.ui.geometry.Offset(centerX + boxHalf, centerY - boxHalf + cornerLineLen), strokeWidth = strokeW)

            // Bottom-Left corner
            drawLine(color = alphaColor, start = androidx.compose.ui.geometry.Offset(centerX - boxHalf, centerY + boxHalf), end = androidx.compose.ui.geometry.Offset(centerX - boxHalf + cornerLineLen, centerY + boxHalf), strokeWidth = strokeW)
            drawLine(color = alphaColor, start = androidx.compose.ui.geometry.Offset(centerX - boxHalf, centerY + boxHalf), end = androidx.compose.ui.geometry.Offset(centerX - boxHalf, centerY + boxHalf - cornerLineLen), strokeWidth = strokeW)

            // Bottom-Right corner
            drawLine(color = alphaColor, start = androidx.compose.ui.geometry.Offset(centerX + boxHalf, centerY + boxHalf), end = androidx.compose.ui.geometry.Offset(centerX + boxHalf - cornerLineLen, centerY + boxHalf), strokeWidth = strokeW)
            drawLine(color = alphaColor, start = androidx.compose.ui.geometry.Offset(centerX + boxHalf, centerY + boxHalf), end = androidx.compose.ui.geometry.Offset(centerX + boxHalf, centerY + boxHalf - cornerLineLen), strokeWidth = strokeW)
        }

        // Zebra Indicator Overlay Text
        if (isZebraOn) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 70.dp, start = 12.dp)
                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                    .border(0.5.dp, WarmOrange, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "ZEBRA ACTIVE (>235 L)",
                    color = WarmOrange,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Highlight/Shadow Clip indicators (Virtual false color guide)
        if (isFalseOn) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(bottom = 36.dp, start = 12.dp)
                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                    .padding(6.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IndicatorLabel("CLIP", HeatRed)
                    IndicatorLabel("MID", GlowGreen)
                    IndicatorLabel("SHAD", Color.Blue)
                }
            }
        }

        // Main Viewfinder Technical Metadata Overlay
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Row 1: Active Lens equivalents + Computational Tag (Top Center) + Scene Selector (Top Right)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                // Left Part of top Row: Stereo Depth label if active
                Box(
                    modifier = Modifier
                        .width(72.dp)
                ) {
                    if (selectedMode == "SPATIAL") {
                        Box(
                            modifier = Modifier
                                .background(Color.Red.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "STEREO DEPTH",
                                color = PureWhite,
                                fontSize = 7.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Center Part of top Row: Lens focal length and dynamic pipeline tag
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "${focalLength.toInt()} mm",
                        color = PureWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Light,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.SansSerif
                    )
                    
                    val activePipelineTag = when {
                        viewModel.isHdrOn.collectAsState().value -> "Multi-Frame HDR"
                        viewModel.isDenoiseOn.collectAsState().value -> "8-Frame Denoise"
                        viewModel.isSuperResOn.collectAsState().value -> "Super-Resolution"
                        else -> "8K ToneMapped"
                    }
                    Box(
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                            .border(0.5.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = activePipelineTag.uppercase(),
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Right Part of top Row: Scene Selector Capsule Trigger
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.5f))
                        .border(0.5.dp, BorderGrey, RoundedCornerShape(6.dp))
                        .clickable { showSceneSelector = !showSceneSelector }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("scene_selector_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Landscape,
                            contentDescription = "Scene Icon",
                            tint = HighResYellow,
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = activeScene.displayName,
                            color = PureWhite,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Middle Section: Left Exposure stacked stats & Right Signal-Sync bars
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left photographic metrics vertical column
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(36.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "ISO", color = PureWhite.copy(alpha = 0.4f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(text = "$iso", color = PureWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "S", color = PureWhite.copy(alpha = 0.4f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(text = shutterSpeed, color = PureWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "EV", color = WarmOrange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(text = "0.0", color = PureWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                // Middle: Waveform / Histogram overlay anchors and Peaking label
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    // Waveform drawing
                    if (isWaveOn) {
                        WaveformOverlay(
                            waveform = computedWave,
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .width(70.dp)
                                .height(120.dp)
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(4.dp)
                        )
                    }

                    // Real-time Histogram drawing
                    if (isHistOn) {
                        HistogramOverlay(
                            histogram = computedHist,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .width(110.dp)
                                .height(50.dp)
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(4.dp)
                        )
                    }

                    // Focus Peaking Label
                    if (isPeakingOn) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                .border(0.5.dp, TechnicalTeal, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "PEAKING",
                                color = TechnicalTeal,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Right Signal-Sync indicator stack
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.width(48.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        // Glowing orange bar
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(14.dp)
                                .clip(RoundedCornerShape(50))
                                .background(WarmOrange)
                        )
                        // Active dim bar
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(14.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.White.copy(alpha = 0.2f))
                        )
                        // Active dim bar
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(14.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.White.copy(alpha = 0.1f))
                        )
                    }
                    Text(
                        text = "SIGNAL-SYNC",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Bottom row: Calibration standards, thermal & pipeline levels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                // Technical Pipeline metrics
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "AURA ENGINE v4.2",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "TEMP: ${"%.1f".format(deviceTemp)}°C | STATUS: CALIBRATED",
                        color = if (thermalState > 0) HeatRed else GlowGreen,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Active aperture and white balance standard metric
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "f/$aperture",
                        color = PureWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${wb}K",
                        color = PureWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Interactive Scene Selection popup drawer
        if (showSceneSelector) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ShadowBlack)
                    .clickable { showSceneSelector = false }
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(12.dp)
                        .clickable(enabled = false) {},
                    colors = CardDefaults.cardColors(containerColor = ObsidianDark),
                    border = BorderStroke(1.dp, BorderGrey)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "OPTICAL SCENE SIMULATION",
                            color = HighResYellow,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        SimulatedScene.values().forEach { scene ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.setScene(scene)
                                        showSceneSelector = false
                                    }
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = scene.displayName,
                                        color = if (activeScene == scene) TechnicalTeal else PureWhite,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = scene.description,
                                        color = MutedSlate,
                                        fontSize = 10.sp
                                    )
                                }
                                if (activeScene == scene) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = TechnicalTeal,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Divider(color = BorderGrey, thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IndicatorLabel(text: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(RoundedCornerShape(50))
                .background(color)
        )
        Text(text = text, color = PureWhite, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun HistogramOverlay(
    histogram: FloatArray,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val barWidth = width / 256f

        // Draw background reference grid
        drawRect(Color.White.copy(alpha = 0.05f))

        // Draw histogram distribution bars
        for (i in 0 until 256) {
            val barHeight = histogram[i] * height
            drawRect(
                color = TechnicalTeal.copy(alpha = 0.7f),
                topLeft = androidx.compose.ui.geometry.Offset(i * barWidth, height - barHeight),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
            )
        }
    }
}

@Composable
fun WaveformOverlay(
    waveform: FloatArray,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val step = width / 128f

        // Draw background reference grid
        drawRect(Color.White.copy(alpha = 0.05f))

        // Draw column-luminance waveform points
        for (i in 0 until 128) {
            val waveVal = waveform[i] * height
            drawCircle(
                color = GlowGreen.copy(alpha = 0.6f),
                radius = 1.2f,
                center = androidx.compose.ui.geometry.Offset(i * step, height - waveVal)
            )
        }
    }
}
